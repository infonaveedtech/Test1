import logging
logger = logging.getLogger(__name__)
import base64
from fastapi import APIRouter, HTTPException
from fastapi.responses import Response
from api.models.schemas import ExportRequest, ExportResponse
from db import sqlite_store as store

router = APIRouter()


@router.post("", response_model=ExportResponse)
def export_report(body: ExportRequest):
    """
    Export a completed run as PDF or DOCX.
    Returns base64-encoded file content.
    """
    run = store.get_run(body.run_id)
    if not run:
        raise HTTPException(status_code=404, detail=f"Run {body.run_id} not found.")
    if run.get("status") not in ("success", "direct"):
        raise HTTPException(
            status_code=400,
            detail=f"Run status is '{run.get('status')}'; can only export successful runs.",
        )

    from reports.generator import build_pdf, build_docx

    try:
        if body.format == "pdf":
            file_bytes = build_pdf(
                run,
                title=body.title,
                generated_by=body.generated_by,
            )
            mime = "application/pdf"
            filename = f"report_{body.run_id[:8]}.pdf"
        else:
            file_bytes = build_docx(
                run,
                title=body.title,
                generated_by=body.generated_by,
            )
            mime = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            filename = f"report_{body.run_id[:8]}.docx"
    except RuntimeError as exc:
        logger.exception("Report export failed for run_id=%s", body.run_id)
        raise HTTPException(status_code=500, detail="Failed to generate report.")

    return ExportResponse(
        run_id=body.run_id,
        format=body.format,
        filename=filename,
        mime=mime,
        file_base64=base64.b64encode(file_bytes).decode("utf-8"),
    )


@router.get("/download/{run_id}")
def download_report(run_id: str, format: str = "pdf"):
    """
    Direct file download endpoint (browser-friendly).
    """
    run = store.get_run(run_id)
    if not run:
        raise HTTPException(status_code=404, detail="Run not found.")

    from reports.generator import build_pdf, build_docx

    if format == "pdf":
        file_bytes = build_pdf(run)
        media_type = "application/pdf"
        filename = f"report_{run_id[:8]}.pdf"
    else:
        file_bytes = build_docx(run)
        media_type = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        filename = f"report_{run_id[:8]}.docx"

    return Response(
        content=file_bytes,
        media_type=media_type,
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )