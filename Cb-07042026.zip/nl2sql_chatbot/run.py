#!/usr/bin/env python3
"""
run.py — Start the NL2SQL Chatbot API server.

Usage:
    python run.py
    python run.py --host 0.0.0.0 --port 8000
    python run.py --reload  (development hot-reload)
"""
import argparse
import uvicorn
from core.config import get_settings

if __name__ == "__main__":
    s = get_settings()

    parser = argparse.ArgumentParser(description="NL2SQL Chatbot API Server")
    parser.add_argument("--host", default=s.API_HOST)
    parser.add_argument("--port", type=int, default=s.API_PORT)
    parser.add_argument("--reload", action="store_true", default=s.API_RELOAD)
    parser.add_argument("--workers", type=int, default=1)
    args = parser.parse_args()

    print(f"""
╔══════════════════════════════════════════════╗
║      NL2SQL Chatbot API  v2.0.0              ║
╠══════════════════════════════════════════════╣
║  Server  : http://{args.host}:{args.port:<24}║
║  Docs    : http://localhost:{args.port}/docs       ║
║  Ollama  : {s.LLM_HOST:<35}║
║  Model   : {s.LLM_MODEL:<35}║
╚══════════════════════════════════════════════╝
""")

    uvicorn.run(
        "api.app:app",
        host=args.host,
        port=args.port,
        reload=args.reload,
        workers=args.workers if not args.reload else 1,
        log_level="info",
    )
