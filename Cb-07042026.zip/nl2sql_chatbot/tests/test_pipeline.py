"""
tests/test_pipeline.py — Integration tests for the full pipeline.

Run with:
    pytest tests/ -v
    pytest tests/test_pipeline.py::test_health -v          # single test
    pytest tests/ -v --tb=short -x                         # stop on first fail
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pytest
from fastapi.testclient import TestClient


# ── Fixtures ─────────────────────────────────────────────────────────────────

@pytest.fixture(scope="session")
def client():
    from api.app import app
    with TestClient(app) as c:
        yield c


@pytest.fixture(scope="session")
def session_id(client):
    """Create a test session once for all tests."""
    resp = client.post("/v1/sessions", json={"title": "Test Session"})
    assert resp.status_code == 201, resp.text
    return resp.json()["session_id"]


# ── Health ────────────────────────────────────────────────────────────────────

def test_health(client):
    resp = client.get("/health")
    assert resp.status_code == 200
    data = resp.json()
    assert data["status"] == "ok"
    print(f"\n  Ollama: {data['ollama']} | Oracle: {data['oracle']} | RAG FS: {data['rag_fewshots']}")


# ── Sessions ──────────────────────────────────────────────────────────────────

def test_create_session(client):
    resp = client.post("/v1/sessions", json={"title": "My Test Chat"})
    assert resp.status_code == 201
    data = resp.json()
    assert "session_id" in data
    assert data["title"] == "My Test Chat"


def test_list_sessions(client):
    resp = client.get("/v1/sessions")
    assert resp.status_code == 200
    data = resp.json()
    assert "sessions" in data
    assert isinstance(data["sessions"], list)


def test_get_session(client, session_id):
    resp = client.get(f"/v1/sessions/{session_id}")
    assert resp.status_code == 200
    assert resp.json()["session_id"] == session_id


def test_get_session_not_found(client):
    resp = client.get("/v1/sessions/nonexistent-id")
    assert resp.status_code == 404


def test_rename_session(client, session_id):
    resp = client.patch(f"/v1/sessions/{session_id}/title", params={"title": "Renamed Session"})
    assert resp.status_code == 200
    assert resp.json()["title"] == "Renamed Session"


# ── Chat: non-DB flows ────────────────────────────────────────────────────────

def test_chat_small_talk(client, session_id):
    """Greetings should not trigger the DB pipeline."""
    resp = client.post("/v1/chat", json={
        "session_id": session_id,
        "message": "Hello! What can you do?",
    })
    assert resp.status_code == 200
    data = resp.json()
    assert data["status"] in ("direct", "success")
    assert data["message"]
    print(f"\n  Intent: {data['intent']} | Status: {data['status']}")


def test_chat_unsafe_query(client, session_id):
    """DML queries should be blocked."""
    resp = client.post("/v1/chat", json={
        "session_id": session_id,
        "message": "DELETE FROM ATS.SYMBOLS WHERE ROWNUM < 100",
    })
    assert resp.status_code == 200
    data = resp.json()
    assert data["status"] == "error"
    assert data["intent"] == "unsafe"


# ── Chat: DB pipeline ─────────────────────────────────────────────────────────

def test_chat_simple_sql_query(client, session_id):
    """Simple aggregation query — should run full pipeline."""
    resp = client.post("/v1/chat", json={
        "session_id": session_id,
        "message": "Show me the top 5 symbols by total turnover in the last 30 days.",
        "row_limit": 5,
    })
    assert resp.status_code == 200
    data = resp.json()
    print(f"\n  Status: {data['status']}")
    print(f"  Intent: {data['intent']}")
    print(f"  SQL: {data.get('verified_sql', '')[:120]}...")
    print(f"  Timing: {data.get('timing_ms', {})}")

    # If oracle is not configured, this will error on DB execution — that's OK
    assert data["status"] in ("success", "error")

    if data["status"] == "success":
        assert data["verified_sql"]
        assert data["message"]


def test_chat_produces_sql(client, session_id):
    """Any DB query should always produce verified SQL even if DB fails."""
    resp = client.post("/v1/chat", json={
        "session_id": session_id,
        "message": "What is the month-over-month turnover for the last 6 months?",
    })
    assert resp.status_code == 200
    data = resp.json()
    assert data["run_id"]
    assert data["session_id"] == session_id


def test_chat_follow_up(client, session_id):
    """Follow-up query should resolve pronouns using session history."""
    # First query
    client.post("/v1/chat", json={
        "session_id": session_id,
        "message": "Show me daily volume by exchange for the last 7 days.",
    })
    # Follow-up — should use context
    resp = client.post("/v1/chat", json={
        "session_id": session_id,
        "message": "Now show the same but only for the top 3 exchanges.",
    })
    assert resp.status_code == 200
    data = resp.json()
    assert data["status"] in ("success", "error", "clarification")
    print(f"\n  Follow-up status: {data['status']} | Intent: {data['intent']}")


# ── Runs ──────────────────────────────────────────────────────────────────────

def test_get_run(client, session_id):
    """After a chat, we should be able to retrieve the run details."""
    # Create a chat first
    chat_resp = client.post("/v1/chat", json={
        "session_id": session_id,
        "message": "How many active symbols are there?",
    })
    assert chat_resp.status_code == 200
    run_id = chat_resp.json()["run_id"]

    run_resp = client.get(f"/v1/runs/{run_id}")
    assert run_resp.status_code == 200
    run_data = run_resp.json()
    assert run_data["run_id"] == run_id
    assert run_data["question"] == "How many active symbols are there?"


def test_list_runs_for_session(client, session_id):
    runs_resp = client.get(f"/v1/runs/session/{session_id}")
    assert runs_resp.status_code == 200
    data = runs_resp.json()
    assert "runs" in data
    assert data["total"] >= 1


# ── Session history ───────────────────────────────────────────────────────────

def test_session_messages(client, session_id):
    resp = client.get(f"/v1/sessions/{session_id}/messages")
    assert resp.status_code == 200
    data = resp.json()
    assert "messages" in data
    assert len(data["messages"]) > 0
    roles = {m["role"] for m in data["messages"]}
    assert "user" in roles
    print(f"\n  Total messages in session: {len(data['messages'])}")


# ── Export ────────────────────────────────────────────────────────────────────

def test_export_requires_successful_run(client, session_id):
    """Export should fail gracefully for non-existent run."""
    resp = client.post("/v1/export", json={
        "run_id": "fake-run-id-00000",
        "format": "pdf",
    })
    assert resp.status_code == 404


def test_export_pdf_from_successful_run(client, session_id):
    """If we have a successful run, PDF export should work."""
    # Get runs for session
    runs_resp = client.get(f"/v1/runs/session/{session_id}")
    runs = runs_resp.json()["runs"]
    successful = [r for r in runs if r["status"] == "success"]

    if not successful:
        pytest.skip("No successful runs to export (Oracle may not be configured)")

    run_id = successful[0]["run_id"]
    export_resp = client.post("/v1/export", json={
        "run_id": run_id,
        "format": "pdf",
        "title": "Test Export",
        "show_sql": False,
    })
    assert export_resp.status_code == 200
    data = export_resp.json()
    assert data["format"] == "pdf"
    assert data["file_base64"]
    assert len(data["file_base64"]) > 100  # should have real content
    print(f"\n  PDF export size: {len(data['file_base64'])} base64 chars")
