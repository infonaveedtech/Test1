"""
tests/test_agents_unit.py — Unit tests for agent utilities (no LLM calls).

Tests JSON extraction, SQL extraction, envelope validation, etc.
Run with: pytest tests/test_agents_unit.py -v
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import pytest


# ── core/ollama.py ────────────────────────────────────────────────────────────

class TestExtractJson:
    def test_direct_json(self):
        from core.ollama import extract_json
        obj = extract_json('{"a": 1, "b": "hello"}')
        assert obj == {"a": 1, "b": "hello"}

    def test_fenced_json(self):
        from core.ollama import extract_json
        obj = extract_json('```json\n{"key": "value"}\n```')
        assert obj == {"key": "value"}

    def test_json_with_prose(self):
        from core.ollama import extract_json
        text = 'Sure! Here is the result:\n{"should_run_pipeline": true, "intent": "sql_query"}\nHope that helps!'
        obj = extract_json(text)
        assert obj["intent"] == "sql_query"

    def test_think_tag_stripped(self):
        from core.ollama import extract_json
        text = '<think>reasoning here...</think>\n{"result": 42}'
        obj = extract_json(text)
        assert obj == {"result": 42}

    def test_returns_none_for_garbage(self):
        from core.ollama import extract_json
        assert extract_json("this is not json at all") is None

    def test_returns_none_for_empty(self):
        from core.ollama import extract_json
        assert extract_json("") is None


# ── agents/agent2_composer.py ─────────────────────────────────────────────────

class TestSqlExtraction:
    def test_bare_select(self):
        from agents.agent2_composer import _extract_sql
        sql = _extract_sql("SELECT * FROM ATS.SYMBOLS FETCH FIRST 10 ROWS ONLY;")
        assert sql is not None
        assert "SELECT" in sql.upper()

    def test_fenced_sql(self):
        from agents.agent2_composer import _extract_sql
        text = "Here is your SQL:\n```sql\nSELECT SYMBOL_ID FROM ATS.SYMBOLS;\n```"
        sql = _extract_sql(text)
        assert sql is not None
        assert "SYMBOL_ID" in sql

    def test_with_cte(self):
        from agents.agent2_composer import _extract_sql
        text = "WITH cte AS (SELECT 1 FROM DUAL) SELECT * FROM cte;"
        sql = _extract_sql(text)
        assert sql is not None
        assert "WITH" in sql.upper()

    def test_returns_none_for_non_sql(self):
        from agents.agent2_composer import _extract_sql
        assert _extract_sql("This is just text.") is None


# ── agents/agent1_planner.py ─────────────────────────────────────────────────

class TestEnvelopeValidation:
    def test_valid_envelope(self):
        from agents.agent1_planner import _validate_envelope
        env = {
            "tables": ["ATS.SYMBOLS"],
            "required_joins_verbatim": ["ATS.SYMBOLS.SYMBOL_ID = ATS.SYMBOL_DAILY_INDICATORS.SYMBOL_ID"],
            "metrics": ["turnover"],
            "grain": "month",
            "date_key": "ATS.SYMBOL_DAILY_INDICATORS.STATS_DATE",
            "row_limit": 100,
        }
        ok, warnings, fixed = _validate_envelope(env)
        assert ok is True
        assert len(warnings) == 0

    def test_fixes_missing_row_limit(self):
        from agents.agent1_planner import _validate_envelope
        env = {
            "tables": ["ATS.SYMBOLS"],
            "required_joins_verbatim": [],
            "metrics": [],
            "grain": "day",
            "date_key": "COL",
        }
        ok, warnings, fixed = _validate_envelope(env)
        assert fixed["row_limit"] == 200

    def test_fixes_invalid_grain(self):
        from agents.agent1_planner import _validate_envelope
        env = {
            "tables": ["T"],
            "date_key": "T.D",
            "grain": "weekly",  # invalid
            "row_limit": 50,
        }
        _, _, fixed = _validate_envelope(env)
        assert fixed["grain"] == "none"

    def test_not_ok_without_tables(self):
        from agents.agent1_planner import _validate_envelope
        env = {"grain": "none", "row_limit": 100}
        ok, _, _ = _validate_envelope(env)
        assert ok is False


# ── db/sqlite_store.py ────────────────────────────────────────────────────────

class TestSQLiteStore:
    def test_create_and_get_session(self, tmp_path, monkeypatch):
        monkeypatch.setenv("SQLITE_PATH", str(tmp_path / "test.db"))
        # Reset the lru_cache so settings pick up the monkeypatch
        from core.config import get_settings
        get_settings.cache_clear()

        from db.sqlite_store import init_db, create_session, get_session
        init_db()
        s = create_session(title="Test")
        assert s["title"] == "Test"

        fetched = get_session(s["session_id"])
        assert fetched["session_id"] == s["session_id"]

    def test_add_and_list_messages(self, tmp_path, monkeypatch):
        monkeypatch.setenv("SQLITE_PATH", str(tmp_path / "test2.db"))
        from core.config import get_settings
        get_settings.cache_clear()

        from db.sqlite_store import init_db, create_session, add_message, get_session_messages
        init_db()
        s = create_session()
        add_message(s["session_id"], "user", "Hello")
        add_message(s["session_id"], "assistant", "Hi there!")

        msgs = get_session_messages(s["session_id"])
        assert len(msgs) == 2
        assert msgs[0]["role"] == "user"
        assert msgs[1]["role"] == "assistant"

    def test_history_for_llm(self, tmp_path, monkeypatch):
        monkeypatch.setenv("SQLITE_PATH", str(tmp_path / "test3.db"))
        from core.config import get_settings
        get_settings.cache_clear()

        from db.sqlite_store import init_db, create_session, add_message, get_history_for_llm
        init_db()
        s = create_session()
        for i in range(15):
            role = "user" if i % 2 == 0 else "assistant"
            add_message(s["session_id"], role, f"message {i}")

        history = get_history_for_llm(s["session_id"], max_turns=5)
        assert len(history) <= 10  # max 2*5

    def test_delete_session_cascades(self, tmp_path, monkeypatch):
        monkeypatch.setenv("SQLITE_PATH", str(tmp_path / "test4.db"))
        from core.config import get_settings
        get_settings.cache_clear()

        from db.sqlite_store import init_db, create_session, add_message, delete_session, get_session_messages
        init_db()
        s = create_session()
        add_message(s["session_id"], "user", "test")
        delete_session(s["session_id"])

        msgs = get_session_messages(s["session_id"])
        assert msgs == []


# ── reports/generator.py ─────────────────────────────────────────────────────

class TestReportGenerator:
    def _sample_run(self):
        return {
            "run_id": "test-run-123",
            "question": "What are the top 5 symbols?",
            "answer_text": "The top 5 symbols by turnover are: AAPL, MSFT, GOOGL, AMZN, TSLA.",
            "answer_summary": "AAPL leads with highest turnover.",
            "answer_key_facts": ["AAPL has highest turnover", "Tech dominates top 5"],
            "db_columns": ["SYMBOL", "TURNOVER"],
            "db_rows": [["AAPL", 1000000], ["MSFT", 900000]],
            "db_row_count": 2,
            "verified_sql": "SELECT SYMBOL, TURNOVER FROM ATS.SYMBOLS FETCH FIRST 5 ROWS ONLY;",
            "timing_ms": {"agent0": 100, "agent1": 500, "total": 2500},
        }

    def test_pdf_generates(self):
        from reports.generator import build_pdf
        run = self._sample_run()
        pdf_bytes = build_pdf(run, title="Test Report", show_sql=False)
        assert isinstance(pdf_bytes, bytes)
        assert len(pdf_bytes) > 1000  # PDF has real content
        assert pdf_bytes[:4] == b"%PDF"  # valid PDF header

    def test_docx_generates(self):
        from reports.generator import build_docx
        run = self._sample_run()
        docx_bytes = build_docx(run, title="Test Report", show_sql=False)
        assert isinstance(docx_bytes, bytes)
        assert len(docx_bytes) > 1000
        # DOCX is a ZIP — check magic bytes
        assert docx_bytes[:2] == b"PK"
