# from fastapi import APIRouter, HTTPException
# from api.models.schemas import (
#     CreateSessionRequest,
#     SessionResponse,
#     SessionListResponse,
# )
# from db import sqlite_store as store

# router = APIRouter()


# def _to_resp(s: dict) -> SessionResponse:
#     return SessionResponse(
#         session_id=s["session_id"],
#         title=s["title"],
#         created_at=s["created_at"],
#         updated_at=s["updated_at"],
#     )


# @router.post("", response_model=SessionResponse, status_code=201)
# def create_session(body: CreateSessionRequest):
#     """Create a new conversation session."""
#     s = store.create_session(title=body.title)
#     return _to_resp(s)


# @router.get("", response_model=SessionListResponse)
# def list_sessions(limit: int = 50):
#     """List all sessions, newest first."""
#     sessions = store.list_sessions(limit=limit)
#     return SessionListResponse(
#         sessions=[_to_resp(s) for s in sessions],
#         total=len(sessions),
#     )


# @router.get("/{session_id}", response_model=SessionResponse)
# def get_session(session_id: str):
#     s = store.get_session(session_id)
#     if not s:
#         raise HTTPException(status_code=404, detail=f"Session {session_id} not found.")
#     return _to_resp(s)


# @router.patch("/{session_id}/title", response_model=SessionResponse)
# def rename_session(session_id: str, title: str):
#     s = store.get_session(session_id)
#     if not s:
#         raise HTTPException(status_code=404, detail=f"Session {session_id} not found.")

#     store.update_session_title(session_id, title)
#     updated = store.get_session(session_id)
#     if not updated:
#         raise HTTPException(status_code=404, detail=f"Session {session_id} not found.")

#     return _to_resp(updated)


# @router.delete("/{session_id}", status_code=204)
# def delete_session(session_id: str):
#     s = store.get_session(session_id)
#     if not s:
#         raise HTTPException(status_code=404, detail=f"Session {session_id} not found.")
#     store.delete_session(session_id)
#     return None


# @router.get("/{session_id}/messages")
# def get_session_messages(session_id: str, limit: int = 100):
#     """Return full chat message history for a session."""
#     s = store.get_session(session_id)
#     if not s:
#         raise HTTPException(status_code=404, detail=f"Session {session_id} not found.")

#     messages = store.get_session_messages(session_id, limit=limit)
#     return {
#         "session_id": session_id,
#         "messages": messages,
#         "total": len(messages),
#     }

from fastapi import APIRouter, HTTPException

from api.models.schemas import (
    CreateSessionRequest,
    SessionResponse,
    SessionListResponse,
    SetSessionStarRequest,
)
from db import sqlite_store as store

router = APIRouter()


def _to_resp(s: dict) -> SessionResponse:
    return SessionResponse(
        session_id=s["session_id"],
        title=s["title"],
        created_at=s["created_at"],
        updated_at=s["updated_at"],
        starred=s.get("starred", False),
    )


@router.post("", response_model=SessionResponse, status_code=201)
def create_session(body: CreateSessionRequest):
    """Create a new conversation session."""
    s = store.create_session(title=body.title)
    return _to_resp(s)


@router.get("", response_model=SessionListResponse)
def list_sessions(limit: int = 50):
    """List all sessions, newest first."""
    sessions = store.list_sessions(limit=limit)
    return SessionListResponse(
        sessions=[_to_resp(s) for s in sessions],
        total=len(sessions),
    )


@router.get("/{session_id}", response_model=SessionResponse)
def get_session(session_id: str):
    s = store.get_session(session_id)
    if not s:
        raise HTTPException(status_code=404, detail=f"Session {session_id} not found.")
    return _to_resp(s)


@router.patch("/{session_id}/title", response_model=SessionResponse)
def rename_session(session_id: str, title: str):
    s = store.get_session(session_id)
    if not s:
        raise HTTPException(status_code=404, detail=f"Session {session_id} not found.")

    store.update_session_title(session_id, title)
    updated = store.get_session(session_id)
    if not updated:
        raise HTTPException(status_code=404, detail=f"Session {session_id} not found.")

    return _to_resp(updated)


@router.patch("/{session_id}/star", response_model=SessionResponse)
def set_session_star(session_id: str, body: SetSessionStarRequest):
    s = store.get_session(session_id)
    if not s:
        raise HTTPException(status_code=404, detail=f"Session {session_id} not found.")

    store.set_session_starred(session_id, body.starred)
    updated = store.get_session(session_id)
    if not updated:
        raise HTTPException(status_code=404, detail=f"Session {session_id} not found.")

    return _to_resp(updated)


@router.post("/{session_id}/toggle-star", response_model=SessionResponse)
def toggle_session_star(session_id: str):
    updated = store.toggle_session_starred(session_id)
    if not updated:
        raise HTTPException(status_code=404, detail=f"Session {session_id} not found.")
    return _to_resp(updated)


@router.delete("/{session_id}", status_code=204)
def delete_session(session_id: str):
    s = store.get_session(session_id)
    if not s:
        raise HTTPException(status_code=404, detail=f"Session {session_id} not found.")
    store.delete_session(session_id)
    return None


@router.get("/{session_id}/messages")
def get_session_messages(session_id: str, limit: int = 100):
    """Return full chat message history for a session."""
    s = store.get_session(session_id)
    if not s:
        raise HTTPException(status_code=404, detail=f"Session {session_id} not found.")

    messages = store.get_session_messages(session_id, limit=limit)
    return {
        "session_id": session_id,
        "messages": messages,
        "total": len(messages),
    }