from fastapi import APIRouter, HTTPException
from api.models.schemas import RunDetailResponse, RunListResponse
from db import sqlite_store as store

router = APIRouter()


def _to_resp(r: dict) -> RunDetailResponse:
    return RunDetailResponse(
        run_id=r["run_id"],
        session_id=r["session_id"],
        question=r["question"],
        intent=r.get("intent"),
        rephrased_query=r.get("rephrased_query"),
        plan_envelope=r.get("plan_envelope"),
        composed_sql=r.get("composed_sql"),
        verified_sql=r.get("verified_sql"),
        db_columns=r.get("db_columns"),
        db_rows=r.get("db_rows"),
        db_row_count=r.get("db_row_count"),
        answer_text=r.get("answer_text"),
        answer_summary=r.get("answer_summary"),
        answer_key_facts=r.get("answer_key_facts"),
        status=r.get("status", "unknown"),
        error_message=r.get("error_message"),
        timing_ms=r.get("timing_ms"),
        created_at=r["created_at"],
        completed_at=r.get("completed_at"),
    )


@router.get("/{run_id}", response_model=RunDetailResponse)
def get_run(run_id: str):
    """Get full details of a single pipeline run."""
    r = store.get_run(run_id)
    if not r:
        raise HTTPException(status_code=404, detail=f"Run {run_id} not found.")
    return _to_resp(r)


@router.get("/session/{session_id}", response_model=RunListResponse)
def list_runs_for_session(session_id: str, limit: int = 20):
    """List all runs for a session."""
    s = store.get_session(session_id)
    if not s:
        raise HTTPException(status_code=404, detail=f"Session {session_id} not found.")
    runs = store.list_runs(session_id, limit=limit)
    return RunListResponse(runs=[_to_resp(r) for r in runs], total=len(runs))
