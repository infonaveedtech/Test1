from fastapi import APIRouter
from api.models.schemas import HealthResponse

router = APIRouter()


@router.get("/health", response_model=HealthResponse)
def health_check():
    from core.ollama import get_client
    from rag.faiss_store import get_fewshots_store, get_glossary_store

    ollama_ok = False
    try:
        ollama_ok = get_client().health_check()
    except Exception:
        pass

    oracle_ok = False
    try:
        from db.oracle import test_connection
        oracle_ok = test_connection()
    except Exception:
        pass

    return HealthResponse(
        status="ok",
        ollama=ollama_ok,
        oracle=oracle_ok,
        rag_fewshots=get_fewshots_store().is_ready,
        rag_glossary=get_glossary_store().is_ready,
    )
