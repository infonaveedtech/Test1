# """
# api/app.py — FastAPI application factory and lifecycle manager.
# """
# from __future__ import annotations

# import logging
# import time

# from fastapi import FastAPI, Request
# from fastapi.middleware.cors import CORSMiddleware
# from fastapi.responses import JSONResponse

# from core.config import get_settings

# logging.basicConfig(
#     level=logging.INFO,
#     format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
# )
# logger = logging.getLogger(__name__)


# def create_app() -> FastAPI:
#     s = get_settings()

#     app = FastAPI(
#         title="NL2SQL Chatbot API",
#         version="2.0.0",
#         description=(
#             "Financial markets analytics chatbot. "
#             "Translates natural language to Oracle SQL, executes it, "
#             "and returns human-readable insights."
#         ),
#         docs_url="/docs",
#         redoc_url="/redoc",
#     )

#     # ── CORS ──────────────────────────────────────────────────────
#     origins = [o.strip() for o in s.CORS_ORIGINS.split(",")]
#     app.add_middleware(
#         CORSMiddleware,
#         allow_origins=origins,
#         allow_credentials=True,
#         allow_methods=["*"],
#         allow_headers=["*"],
#     )

#     # ── Request timing middleware ─────────────────────────────────
#     @app.middleware("http")
#     async def add_timing_header(request: Request, call_next):
#         t0 = time.perf_counter()
#         response = await call_next(request)
#         elapsed = round((time.perf_counter() - t0) * 1000)
#         response.headers["X-Process-Time-Ms"] = str(elapsed)
#         return response

#     # ── Global exception handler ──────────────────────────────────
#     @app.exception_handler(Exception)
#     async def global_exception_handler(request: Request, exc: Exception):
#         logger.exception("Unhandled exception on %s: %s", request.url, exc)
#         return JSONResponse(
#             status_code=500,
#             content={"detail": "Internal server error"},
#         )

#     # ── Startup / shutdown ─────────────────────────────────────────
#     @app.on_event("startup")
#     async def on_startup():
#         logger.info("=== NL2SQL Chatbot API starting up ===")

#         # Init SQLite schema
#         from db.sqlite_store import init_db
#         init_db()
#         logger.info("SQLite initialized.")

#         # Init RAG indexes
#         try:
#             from rag.faiss_store import initialize_rag
#             initialize_rag()
#             logger.info("RAG indexes ready.")
#         except Exception as exc:
#             logger.warning("RAG initialization failed (non-fatal): %s", exc)

#         # Check Oracle connectivity
#         try:
#             from db.oracle import test_connection
#             if test_connection():
#                 logger.info("Oracle DB connection: OK")
#             else:
#                 logger.warning("Oracle DB connection: FAILED (SQL execution will error)")
#         except Exception as exc:
#             logger.warning("Oracle check skipped: %s", exc)

#         # Check Ollama
#         from core.ollama import get_client
#         if get_client().health_check():
#             logger.info("Ollama LLM server: OK")
#         else:
#             logger.warning("Ollama LLM server: UNREACHABLE — check LLM_HOST in .env")

#         logger.info("=== Startup complete ===")

#     @app.on_event("shutdown")
#     async def on_shutdown():
#         from db.oracle import close_pool
#         close_pool()
#         logger.info("Oracle pool closed. Goodbye.")

#     # ── Routes ────────────────────────────────────────────────────
#     from api.routes import health, sessions, chat, runs, export
#     app.include_router(health.router, tags=["Health"])
#     app.include_router(sessions.router, prefix="/v1/sessions", tags=["Sessions"])
#     app.include_router(chat.router, prefix="/v1/chat", tags=["Chat"])
#     app.include_router(runs.router, prefix="/v1/runs", tags=["Runs"])
#     app.include_router(export.router, prefix="/v1/export", tags=["Export"])

#     return app


# app = create_app()

"""
api/app.py — FastAPI application factory and lifecycle manager.
"""
from __future__ import annotations

import logging
import time

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from core.config import get_settings

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
)
logger = logging.getLogger(__name__)


def create_app() -> FastAPI:
    s = get_settings()

    app = FastAPI(
        title="NL2SQL Chatbot API",
        version="2.0.0",
        description=(
            "Financial markets analytics chatbot. "
            "Translates natural language to Oracle SQL, executes it, "
            "and returns human-readable insights."
        ),
        docs_url="/docs",
        redoc_url="/redoc",
    )

    # ── CORS ──────────────────────────────────────────────────────
    origins = [o.strip() for o in s.CORS_ORIGINS.split(",")]
    app.add_middleware(
        CORSMiddleware,
        allow_origins=origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # ── Request timing middleware ─────────────────────────────────
    @app.middleware("http")
    async def add_timing_header(request: Request, call_next):
        t0 = time.perf_counter()
        response = await call_next(request)
        elapsed = round((time.perf_counter() - t0) * 1000)
        response.headers["X-Process-Time-Ms"] = str(elapsed)
        return response

    # ── Global exception handler ──────────────────────────────────
    @app.exception_handler(Exception)
    async def global_exception_handler(request: Request, exc: Exception):
        logger.exception("Unhandled exception on %s: %s", request.url, exc)
        return JSONResponse(
            status_code=500,
            content={"detail": "Internal server error"},
        )

    # ── Startup / shutdown ────────────────────────────────────────
    @app.on_event("startup")
    async def on_startup():
        logger.info("=== NL2SQL Chatbot API starting up ===")

        # Init chatbot persistence store (now Oracle-backed via db.sqlite_store shim)
        try:
            from db.sqlite_store import init_db
            init_db()
            logger.info("Chatbot persistence store initialized.")
        except Exception as exc:
            logger.exception("Chatbot persistence initialization failed: %s", exc)
            raise

        # Init RAG indexes
        try:
            from rag.faiss_store import initialize_rag
            initialize_rag()
            logger.info("RAG indexes ready.")
        except Exception as exc:
            logger.warning("RAG initialization failed (non-fatal): %s", exc)

        # Check Oracle connectivity
        try:
            from db.oracle import test_connection
            if test_connection():
                logger.info("Oracle DB connection: OK")
            else:
                logger.warning("Oracle DB connection: FAILED (SQL execution will error)")
        except Exception as exc:
            logger.warning("Oracle check skipped: %s", exc)

        # Check Ollama
        try:
            from core.ollama import get_client
            if get_client().health_check():
                logger.info("Ollama LLM server: OK")
            else:
                logger.warning("Ollama LLM server: UNREACHABLE — check LLM_HOST in .env")
        except Exception as exc:
            logger.warning("Ollama check failed: %s", exc)

        logger.info("=== Startup complete ===")

    @app.on_event("shutdown")
    async def on_shutdown():
        try:
            from db.oracle import close_pool
            close_pool()
        except Exception as exc:
            logger.warning("Oracle pool shutdown warning: %s", exc)

        logger.info("Oracle pool closed. Goodbye.")

    # ── Routes ────────────────────────────────────────────────────
    from api.routes import health, sessions, chat, runs, export
    app.include_router(health.router, tags=["Health"])
    app.include_router(sessions.router, prefix="/v1/sessions", tags=["Sessions"])
    app.include_router(chat.router, prefix="/v1/chat", tags=["Chat"])
    app.include_router(runs.router, prefix="/v1/runs", tags=["Runs"])
    app.include_router(export.router, prefix="/v1/export", tags=["Export"])

    return app


app = create_app()