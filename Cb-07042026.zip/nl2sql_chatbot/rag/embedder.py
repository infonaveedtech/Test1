"""
rag/embedder.py — Sentence-transformers embedder (pure Python, no Ollama).

Uses BAAI/bge-small-en-v1.5 by default — the same model from the original project.
Model is downloaded once from HuggingFace and cached in ~/.cache/huggingface/.

Usage:
    from rag.embedder import get_embedder
    embedder = get_embedder()
    vectors = embedder.encode(["text 1", "text 2"])  # List[List[float]]
"""
from __future__ import annotations

import logging
from typing import List, Optional

logger = logging.getLogger(__name__)

_embedder = None   # singleton SentenceTransformer instance


def get_embedder():
    """
    Returns the cached SentenceTransformer instance.
    Loads it on first call (takes ~2-5s to load model from disk).
    """
    global _embedder
    if _embedder is not None:
        return _embedder

    try:
        from sentence_transformers import SentenceTransformer
    except ImportError:
        raise RuntimeError(
            "sentence-transformers is not installed.\n"
            "Run:  pip install sentence-transformers"
        )

    from core.config import get_settings
    model_name = get_settings().EMBEDDING_MODEL

    logger.info("[Embedder] Loading sentence-transformers model: %s", model_name)
    _embedder = SentenceTransformer(model_name)
    logger.info("[Embedder] Model loaded ✓")
    return _embedder


def embed_texts(texts: List[str], batch_size: int = 64) -> List[List[float]]:
    """
    Embed a list of strings. Returns normalized float vectors (cosine-ready).
    Batches automatically to avoid OOM on large lists.
    """
    if not texts:
        return []

    model = get_embedder()
    vectors = model.encode(
        texts,
        batch_size=batch_size,
        normalize_embeddings=True,   # cosine similarity via inner product
        show_progress_bar=len(texts) > 50,
    )
    return [v.tolist() for v in vectors]
