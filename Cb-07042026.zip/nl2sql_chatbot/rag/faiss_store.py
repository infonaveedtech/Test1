"""
rag/faiss_store.py — FAISS-backed vector store for fewshots and glossary.

Loaded ONCE at startup, then queried per request.
Embeddings use sentence-transformers (BAAI/bge-small-en-v1.5 by default).
"""
from __future__ import annotations

import json
import logging
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np

logger = logging.getLogger(__name__)


class FaissStore:
    """
    Wraps a FAISS IndexFlatIP (inner product = cosine on normalized vecs).
    Thread-safe for reads.
    """

    def __init__(self, name: str):
        self.name = name
        self._index = None
        self._metadata: List[Dict[str, Any]] = []
        self._built = False

    # ── Build ────────────────────────────────────────────────────

    def build(
        self,
        documents: List[Dict[str, Any]],
        embed_fn,                   # callable(List[str]) -> List[List[float]]
        text_field: str = "content",
    ) -> None:
        """Embed documents and build the FAISS index."""
        import faiss

        texts = [
            str(d.get(text_field) or d.get("question") or d.get("content") or "")
            for d in documents
        ]
        logger.info("[FAISS:%s] Embedding %d documents…", self.name, len(texts))
        t0 = time.time()
        vectors = embed_fn(texts)
        logger.info("[FAISS:%s] Embedded in %.1fs", self.name, time.time() - t0)

        arr = np.array(vectors, dtype=np.float32)
        # Normalize for cosine similarity via inner product
        norms = np.linalg.norm(arr, axis=1, keepdims=True)
        arr /= np.where(norms == 0, 1.0, norms)

        dim = arr.shape[1]
        index = faiss.IndexFlatIP(dim)
        index.add(arr)

        self._index = index
        self._metadata = list(documents)
        self._built = True
        logger.info("[FAISS:%s] Index built: %d vectors, dim=%d", self.name, index.ntotal, dim)

    # ── Persistence ──────────────────────────────────────────────

    def save(self, directory: str) -> None:
        import faiss
        p = Path(directory)
        p.mkdir(parents=True, exist_ok=True)
        faiss.write_index(self._index, str(p / "index.faiss"))
        (p / "metadata.jsonl").write_text(
            "\n".join(json.dumps(m, ensure_ascii=False) for m in self._metadata),
            encoding="utf-8",
        )
        logger.info("[FAISS:%s] Saved to %s", self.name, directory)

    def load(self, directory: str) -> bool:
        """Load from disk. Returns False if files don't exist."""
        import faiss
        p = Path(directory)
        idx_path = p / "index.faiss"
        meta_path = p / "metadata.jsonl"
        if not idx_path.exists() or not meta_path.exists():
            return False
        self._index = faiss.read_index(str(idx_path))
        self._metadata = [
            json.loads(line)
            for line in meta_path.read_text(encoding="utf-8").splitlines()
            if line.strip()
        ]
        self._built = True
        logger.info("[FAISS:%s] Loaded from %s (%d vectors)",
                    self.name, directory, self._index.ntotal)
        return True

    # ── Search ───────────────────────────────────────────────────

    def search(self, query_vector: List[float], top_k: int = 5) -> List[Dict[str, Any]]:
        if not self._built or self._index is None:
            logger.warning("[FAISS:%s] Index not built — returning empty.", self.name)
            return []

        arr = np.array([query_vector], dtype=np.float32)
        norm = np.linalg.norm(arr)
        if norm > 0:
            arr /= norm

        k = min(top_k, self._index.ntotal)
        scores, indices = self._index.search(arr, k)

        results = []
        for score, idx in zip(scores[0], indices[0]):
            if idx < 0:
                continue
            doc = dict(self._metadata[idx])
            doc["_score"] = float(score)
            results.append(doc)
        return results

    @property
    def is_ready(self) -> bool:
        return self._built and self._index is not None


# ── Singletons ────────────────────────────────────────────────────────────────

_fewshots_store: Optional[FaissStore] = None
_glossary_store: Optional[FaissStore] = None


def get_fewshots_store() -> FaissStore:
    global _fewshots_store
    if _fewshots_store is None:
        _fewshots_store = FaissStore("fewshots")
    return _fewshots_store


def get_glossary_store() -> FaissStore:
    global _glossary_store
    if _glossary_store is None:
        _glossary_store = FaissStore("glossary")
    return _glossary_store


def _load_jsonl(path: str) -> List[Dict[str, Any]]:
    p = Path(path)
    if not p.exists():
        logger.warning("[FAISS] JSONL not found: %s", path)
        return []
    docs = []
    for line in p.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line:
            try:
                docs.append(json.loads(line))
            except Exception:
                pass
    return docs


def initialize_rag(rebuild: bool = False) -> None:
    """
    Called at app startup.
    Tries to load existing indexes from disk.
    If missing or rebuild=True, re-embeds from JSONL using sentence-transformers.
    """
    from core.config import get_settings
    from rag.embedder import embed_texts

    s = get_settings()
    if not s.ENABLE_RAG:
        logger.info("[RAG] Disabled via config (ENABLE_RAG=false).")
        return

    # ── Few-shots ──
    fs_store = get_fewshots_store()
    if not rebuild and fs_store.load(s.FAISS_FEWSHOTS_DIR):
        logger.info("[RAG] Few-shots index loaded from disk ✓")
    else:
        docs = _load_jsonl(s.FEWSHOTS_JSONL)
        if docs:
            fs_store.build(docs, embed_texts, text_field="question")
            fs_store.save(s.FAISS_FEWSHOTS_DIR)
        else:
            logger.warning("[RAG] No few-shot documents at %s", s.FEWSHOTS_JSONL)

    # ── Glossary ──
    gl_store = get_glossary_store()
    if not rebuild and gl_store.load(s.FAISS_GLOSSARY_DIR):
        logger.info("[RAG] Glossary index loaded from disk ✓")
    else:
        docs = _load_jsonl(s.GLOSSARY_JSONL)
        if docs:
            gl_store.build(docs, embed_texts, text_field="content")
            gl_store.save(s.FAISS_GLOSSARY_DIR)
        else:
            logger.warning("[RAG] No glossary documents at %s", s.GLOSSARY_JSONL)
