"""
rag/retriever.py — Retrieves relevant few-shots and glossary items for a query.
Uses sentence-transformers for query embedding (no Ollama dependency).
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List

from core.config import get_settings
from rag.faiss_store import get_fewshots_store, get_glossary_store

logger = logging.getLogger(__name__)


def retrieve_context(query: str) -> Dict[str, Any]:
    """
    Embed the query and retrieve top-K fewshots + glossary items.

    Returns:
        {
            "query": str,
            "fewshots": List[dict],
            "glossary": List[dict],
        }
    """
    s = get_settings()
    if not s.ENABLE_RAG:
        return {"query": query, "fewshots": [], "glossary": []}

    try:
        from rag.embedder import embed_texts
        vectors = embed_texts([query])
    except Exception as exc:
        logger.warning("[RAG] Embedding failed (%s) — returning empty context.", exc)
        return {"query": query, "fewshots": [], "glossary": []}

    if not vectors:
        return {"query": query, "fewshots": [], "glossary": []}

    qvec = vectors[0]
    fewshots = get_fewshots_store().search(qvec, top_k=s.TOP_K_FEWSHOTS)
    glossary = get_glossary_store().search(qvec, top_k=s.TOP_K_GLOSSARY)

    logger.debug("[RAG] Retrieved %d fewshots, %d glossary for: '%s'",
                 len(fewshots), len(glossary), query[:80])

    return {"query": query, "fewshots": fewshots, "glossary": glossary}


def render_fewshots(docs: List[Dict]) -> str:
    """Format few-shot examples for injection into Agent-1 prompt."""
    if not docs:
        return "(no similar examples found)"
    parts = []
    for d in docs:
        title    = d.get("title") or d.get("id") or "Example"
        question = d.get("question") or ""
        sql      = (d.get("sql_text") or "").strip()
        score    = d.get("_score", 0)
        parts.append(
            f"### {title} (similarity={score:.3f})\n"
            f"Question: {question}\n"
            f"SQL:\n{sql}"
        )
    return "\n\n".join(parts)


def render_glossary(docs: List[Dict]) -> str:
    """Format glossary items for injection into Agent-1 prompt."""
    if not docs:
        return "(no glossary items retrieved)"
    parts = []
    for d in docs:
        title   = d.get("title") or d.get("id") or "Term"
        content = d.get("content") or ""
        joins   = d.get("canonical_joins") or d.get("canonical_joins_snippets") or []
        ds      = d.get("date_semantics") or {}
        block   = [f"### {title}", content.strip()]
        if joins:
            block.append("Canonical joins:")
            for j in joins:
                block.append(f"  - {j}")
        if ds:
            grains = ", ".join(ds.get("grains_allowed") or [])
            prim   = ", ".join(ds.get("primary_date_cols") or [])
            block.append(f"Date cols: [{prim}] | Grains: [{grains}]")
        parts.append("\n".join(block))
    return "\n\n".join(parts)
