#!/usr/bin/env python3
"""
ATS Schema Comparison Tool
Compares the golden schema card (ATS owner, Oracle) against the live database.

Usage:
    python compare_schema.py
    python compare_schema.py --dsn 192.168.36.177:1521/sconv --user ATS --password ABC --owner ATS
    python compare_schema.py --output report.md
"""

import argparse
import sys
from datetime import datetime

# ---------------------------------------------------------------------------
# Connection defaults (override via CLI args)
# ---------------------------------------------------------------------------
DEFAULT_DSN      = "192.168.36.96:1521/infotechdb"
DEFAULT_USER     = "ATS"
DEFAULT_PASSWORD = "ABC"
DEFAULT_OWNER    = "ATS"

# ---------------------------------------------------------------------------
# GOLDEN SCHEMA CARD  (parsed from schema_card.md verbatim)
#
# Each column dict:
#   name     : str   – column name exactly as in schema card
#   type     : str   – data type string exactly as written (e.g. NUMBER(14,4))
#   not_null : bool  – True if "NOT NULL" appears in the card for this column
#   notes    : str   – any inline comments / tags (PK, FK, etc.)
#
# Table-level metadata (grain, date_key, notes) is stored for the report.
# ---------------------------------------------------------------------------

SCHEMA_CARD = {
    "SYMBOL_DAILY_INDICATORS": {
        "grain": "symbol_day",
        "date_key": "STATS_DATE",
        "notes": "",
        "columns": [
            {"name": "STATS_DATE",           "type": "DATE",           "not_null": True,  "notes": "PK"},
            {"name": "OPEN_PRICE",           "type": "NUMBER(14,4)",   "not_null": True,  "notes": ""},
            {"name": "CLOSE_PRICE",          "type": "NUMBER(14,4)",   "not_null": True,  "notes": ""},
            {"name": "LOW_PRICE",            "type": "NUMBER(14,4)",   "not_null": True,  "notes": ""},
            {"name": "HIGH_PRICE",           "type": "NUMBER(14,4)",   "not_null": True,  "notes": ""},
            {"name": "TURNOVER",             "type": "NUMBER(10,0)",   "not_null": True,  "notes": ""},
            {"name": "TURNOVER_VALUE",       "type": "NUMBER(20,4)",   "not_null": False, "notes": ""},
            {"name": "TRADES_COUNT",         "type": "NUMBER(10,0)",   "not_null": True,  "notes": ""},
            {"name": "AVERAGE_PRICE",        "type": "NUMBER(14,4)",   "not_null": True,  "notes": ""},
            {"name": "CHANGE_PRICE",         "type": "NUMBER(14,4)",   "not_null": True,  "notes": ""},
            {"name": "PERCENTAGE_CHANGE",    "type": "NUMBER(9,4)",    "not_null": False, "notes": ""},
            {"name": "MARKET_ID",            "type": "NUMBER(4,0)",    "not_null": True,  "notes": "PK, FK→ATS.MARKETS(MARKET_ID)"},
            {"name": "SYMBOL_ID",            "type": "NUMBER(15,0)",   "not_null": True,  "notes": "PK, FK→ATS.SYMBOLS(SYMBOL_ID)"},
            {"name": "EXCHANGE_ID",          "type": "NUMBER(4,0)",    "not_null": True,  "notes": "PK, FK→ATS.EXCHANGES(EXCHANGE_ID)"},
            {"name": "OPEN_PRICE_YIELD",     "type": "NUMBER(15,4)",   "not_null": False, "notes": ""},
            {"name": "YIELD",                "type": "NUMBER(15,4)",   "not_null": False, "notes": ""},
        ]
    },
    "SYMBOL_INDICATORS": {
        "grain": "symbol_timestamp",
        "date_key": "ENTRY_DATETIME",
        "notes": "",
        "columns": [
            {"name": "ENTRY_DATETIME",    "type": "TIMESTAMP(6)",  "not_null": True,  "notes": ""},
            {"name": "OPEN",              "type": "NUMBER(14,4)",  "not_null": True,  "notes": ""},
            {"name": "HIGH",              "type": "NUMBER(14,4)",  "not_null": True,  "notes": ""},
            {"name": "LOW",               "type": "NUMBER(14,4)",  "not_null": True,  "notes": ""},
            {"name": "CLOSE",             "type": "NUMBER(14,4)",  "not_null": True,  "notes": ""},
            {"name": "AVG",               "type": "NUMBER(14,4)",  "not_null": True,  "notes": ""},
            {"name": "VOLUME",            "type": "NUMBER(10,0)",  "not_null": True,  "notes": ""},
            {"name": "VALUE",             "type": "NUMBER(15,4)",  "not_null": False, "notes": ""},
            {"name": "SYMBOL_ID",         "type": "NUMBER(15,0)",  "not_null": True,  "notes": "FK→ATS.SYMBOL_MARKETS(SYMBOL_ID)"},
            {"name": "MARKET_ID",         "type": "NUMBER(4,0)",   "not_null": True,  "notes": "FK→ATS.SYMBOL_MARKETS(MARKET_ID)"},
            {"name": "EXCHANGE_ID",       "type": "NUMBER(4,0)",   "not_null": True,  "notes": "FK→ATS.SYMBOL_MARKETS(EXCHANGE_ID)"},
            {"name": "TRADES_COUNT",      "type": "NUMBER(10,0)",  "not_null": False, "notes": ""},
            {"name": "CHANGE_PRICE",      "type": "NUMBER(14,4)",  "not_null": False, "notes": ""},
            {"name": "OPEN_PRICE_YIELD",  "type": "NUMBER(15,4)",  "not_null": False, "notes": ""},
            {"name": "YIELD",             "type": "NUMBER(15,4)",  "not_null": False, "notes": ""},
        ]
    },
    "BEST_MKT": {
        "grain": "symbol_timestamp",
        "date_key": "ENTRY_DATETIME",
        "notes": "",
        "columns": [
            {"name": "ENTRY_DATETIME",      "type": "TIMESTAMP(9)",  "not_null": True,  "notes": ""},
            {"name": "BID_ORDER_COUNT",     "type": "NUMBER(8,0)",   "not_null": False, "notes": ""},
            {"name": "OFFER_ORDER_COUNT",   "type": "NUMBER(8,0)",   "not_null": False, "notes": ""},
            {"name": "BID_VOLUME",          "type": "NUMBER(10,0)",  "not_null": False, "notes": ""},
            {"name": "OFFER_VOLUME",        "type": "NUMBER(10,0)",  "not_null": False, "notes": ""},
            {"name": "BID_PRICE",           "type": "NUMBER(14,4)",  "not_null": False, "notes": ""},
            {"name": "OFFER_PRICE",         "type": "NUMBER(14,4)",  "not_null": False, "notes": ""},
            {"name": "SYMBOL_ID",           "type": "NUMBER(15,0)",  "not_null": True,  "notes": ""},
            {"name": "MARKET_ID",           "type": "NUMBER(4,0)",   "not_null": True,  "notes": ""},
            {"name": "EXCHANGE_ID",         "type": "NUMBER(4,0)",   "not_null": True,  "notes": ""},
        ]
    },
    "SYMBOLS": {
        "grain": "",
        "date_key": "",
        "notes": "",
        "columns": [
            {"name": "SYMBOL",              "type": "NVARCHAR2(64)",  "not_null": True,  "notes": ""},
            {"name": "SYMBOL_ID",           "type": "NUMBER(15,0)",   "not_null": True,  "notes": "PK"},
            {"name": "COMPANY_ID",          "type": "NUMBER(15,0)",   "not_null": False, "notes": "FK→ATS.COMPANIES(COMPANY_ID)"},
            {"name": "FACE_VALUE",          "type": "NUMBER(14,4)",   "not_null": False, "notes": ""},
            {"name": "OUTSTANDING_SHARES",  "type": "NUMBER(12,0)",   "not_null": False, "notes": ""},
            {"name": "SETTLEMENT_TYPE_ID",  "type": "NUMBER(4,0)",    "not_null": True,  "notes": "FK→ATS.SETTLEMENT_TYPES(SETTLEMENT_TYPE_ID)"},
            {"name": "SYMBOL_TYPE_ID",      "type": "NUMBER(2,0)",    "not_null": True,  "notes": "FK→ATS.SYMBOL_TYPES(SYMBOL_TYPE_ID)"},
            {"name": "SYMBOL_GROUP_ID",     "type": "NUMBER(4,0)",    "not_null": True,  "notes": "FK→ATS.SYMBOL_GROUPS(SYMBOL_GROUP_ID)"},
            {"name": "SYMBOL_CATEGORY_ID",  "type": "NUMBER(2,0)",    "not_null": False, "notes": ""},
            {"name": "ACTIVE",              "type": "NUMBER(1,0)",    "not_null": True,  "notes": ""},
            {"name": "CREATION_DATE",       "type": "DATE",           "not_null": True,  "notes": ""},
            {"name": "MODIFIED_BY",         "type": "VARCHAR2(32)",   "not_null": True,  "notes": ""},
            {"name": "MODIFIED_DATE",       "type": "DATE",           "not_null": True,  "notes": ""},
            {"name": "CURRENCY_ID",         "type": "NUMBER(4,0)",    "not_null": True,  "notes": "FK→ATS.CURRENCY(CURRENCY_ID)"},
            {"name": "FIRST_TRADING_DAY",   "type": "DATE",           "not_null": True,  "notes": ""},
            {"name": "ISSUE_PRICE",         "type": "NUMBER(14,4)",   "not_null": True,  "notes": ""},
            {"name": "ISIN",                "type": "NVARCHAR2(12)",  "not_null": True,  "notes": ""},
            {"name": "ISSUER_ID",           "type": "NUMBER(6,0)",    "not_null": False, "notes": "FK→ATS.ISSUER(ISSUER_ID)"},
            {"name": "CFI",                 "type": "NVARCHAR2(20)",  "not_null": False, "notes": ""},
            {"name": "FISN",                "type": "NVARCHAR2(35)",  "not_null": False, "notes": ""},
            {"name": "LEI",                 "type": "NVARCHAR2(20)",  "not_null": False, "notes": ""},
            {"name": "HAIRCUT",             "type": "NUMBER(2,0)",    "not_null": True,  "notes": ""},
            {"name": "FREE_FLOAT_SHARES",   "type": "NUMBER(15,0)",   "not_null": False, "notes": ""},
            {"name": "AUTHORIZED_CAPITAL",  "type": "NUMBER(15,0)",   "not_null": False, "notes": ""},
            {"name": "ETF_TYPE_ID",         "type": "NUMBER(2,0)",    "not_null": False, "notes": "FK→ATS.ETF_TYPE(ETF_TYPE_ID)"},
        ]
    },
    "EXCHANGES": {
        "grain": "",
        "date_key": "",
        "notes": "",
        "columns": [
            {"name": "EXCHANGE_CODE",       "type": "NVARCHAR2(8)",   "not_null": True,  "notes": ""},
            {"name": "EXCHANGE_NAME",       "type": "NVARCHAR2(128)", "not_null": True,  "notes": ""},
            {"name": "CONTACT_ENTITY_ID",   "type": "NUMBER(10,0)",   "not_null": True,  "notes": "FK→ATS.CONTACT_ENTITIES(CONTACT_ENTITY_ID)"},
            {"name": "EXCHANGE_ID",         "type": "NUMBER(4,0)",    "not_null": True,  "notes": "PK"},
            {"name": "CONNECTIVITY",        "type": "NUMBER(1,0)",    "not_null": False, "notes": "0=CAPAZAR, 1=FIX"},
            {"name": "CREATION_DATE",       "type": "DATE",           "not_null": True,  "notes": ""},
            {"name": "MODIFIED_BY",         "type": "VARCHAR2(32)",   "not_null": True,  "notes": ""},
            {"name": "MODIFIED_DATE",       "type": "DATE",           "not_null": True,  "notes": ""},
            {"name": "ACTIVE",              "type": "NUMBER(1,0)",    "not_null": True,  "notes": ""},
            {"name": "DESCRIPTION",         "type": "NVARCHAR2(500)", "not_null": False, "notes": ""},
            {"name": "MBO_DEPTH",           "type": "NUMBER(4,0)",    "not_null": True,  "notes": ""},
            {"name": "MBP_DEPTH",           "type": "NUMBER(4,0)",    "not_null": True,  "notes": ""},
            {"name": "ALLOW_SHORT_SELL",    "type": "NUMBER(1,0)",    "not_null": True,  "notes": ""},
            {"name": "CURRENCY_ID",         "type": "NUMBER(4,0)",    "not_null": False, "notes": "FK→ATS.CURRENCY(CURRENCY_ID)"},
        ]
    },
    "ORDERS": {
        "grain": "order_event",
        "date_key": "ENTRY_DATETIME",
        "notes": "SIDE is B/S; IS_SHORT is 0/1 string. Use ENTRY_DATETIME for date filtering.",
        "columns": [
            {"name": "ENTRY_DATETIME",         "type": "TIMESTAMP(6)",  "not_null": True,  "notes": "PK"},
            {"name": "ORDER_NO",               "type": "NUMBER(10,0)",  "not_null": True,  "notes": "PK"},
            {"name": "VOLUME",                 "type": "NUMBER(10,0)",  "not_null": True,  "notes": ""},
            {"name": "PRICE",                  "type": "NUMBER(14,4)",  "not_null": True,  "notes": ""},
            {"name": "IS_SHORT",               "type": "NVARCHAR2(1)",  "not_null": True,  "notes": ""},
            {"name": "DISCLOSED_VOLUME",       "type": "NUMBER(10,0)",  "not_null": True,  "notes": ""},
            {"name": "SIDE",                   "type": "NVARCHAR2(1)",  "not_null": True,  "notes": ""},
            {"name": "TIF",                    "type": "DATE",          "not_null": False, "notes": ""},
            {"name": "REF_NO",                 "type": "VARCHAR2(20)",  "not_null": False, "notes": ""},
            {"name": "TRIGGER_PRICE",          "type": "NUMBER(14,4)",  "not_null": True,  "notes": ""},
            {"name": "TRAILING_STOPLOSS_DIP",  "type": "NUMBER(14,4)",  "not_null": True,  "notes": ""},
            {"name": "CLIENT_ID",              "type": "NUMBER(20,0)",  "not_null": True,  "notes": "FK→ATS.EDS_CLIENTS(CLIENT_ID)"},
            {"name": "FLAG_ID",                "type": "NUMBER(2,0)",   "not_null": False, "notes": "FK→ATS.FLAGS(FLAG_ID)"},
            {"name": "SYMBOL_ID",              "type": "NUMBER(15,0)",  "not_null": True,  "notes": "PK, FK→ATS.SYMBOL_MARKETS(SYMBOL_ID)"},
            {"name": "MARKET_ID",              "type": "NUMBER(4,0)",   "not_null": True,  "notes": "PK, FK→ATS.SYMBOL_MARKETS(MARKET_ID)"},
            {"name": "EXCHANGE_ID",            "type": "NUMBER(4,0)",   "not_null": True,  "notes": "PK, FK→ATS.SYMBOL_MARKETS(EXCHANGE_ID)"},
            {"name": "BROKER_ID",              "type": "NUMBER(5,0)",   "not_null": True,  "notes": "FK→ATS.SUBSCRIBED_BROKERS(BROKER_ID)"},
            {"name": "USER_ID",                "type": "NUMBER(30,0)",  "not_null": True,  "notes": "FK→ATS.USERS(USER_ID)"},
            {"name": "STATE",                  "type": "NUMBER(1,0)",   "not_null": True,  "notes": ""},
            {"name": "TRADER_ID",              "type": "NUMBER(30,0)",  "not_null": False, "notes": "FK→ATS.USERS(USER_ID)"},
            {"name": "ORDER_TYPE",             "type": "NUMBER(1,0)",   "not_null": True,  "notes": ""},
            {"name": "PRICE_TYPE",             "type": "NUMBER(1,0)",   "not_null": True,  "notes": ""},
            {"name": "STATE_TIME",             "type": "TIMESTAMP(6)",  "not_null": False, "notes": ""},
            {"name": "QUOTE_ID",               "type": "NUMBER(10,0)",  "not_null": False, "notes": ""},
            {"name": "CUSTODIAN_ID",           "type": "NUMBER(20,0)",  "not_null": False, "notes": ""},
            {"name": "MF_VOLUME",              "type": "NUMBER(10,0)",  "not_null": False, "notes": ""},
            {"name": "QUEUING_TIME",           "type": "TIMESTAMP(6)",  "not_null": False, "notes": ""},
            {"name": "FIX_SESSION",            "type": "VARCHAR2(200)", "not_null": False, "notes": ""},
            {"name": "ORIGINATOR",             "type": "NUMBER(1,0)",   "not_null": False, "notes": ""},
            {"name": "YIELD",                  "type": "NUMBER(15,4)",  "not_null": False, "notes": ""},
            {"name": "ACCRUED_PROFIT",         "type": "NUMBER(24,6)",  "not_null": False, "notes": ""},
            {"name": "VALUE",                  "type": "NUMBER(24,6)",  "not_null": False, "notes": ""},
            {"name": "PRICING_MECHANISM",      "type": "NUMBER(1,0)",   "not_null": False, "notes": ""},
            {"name": "SWIFT_REF_NO",           "type": "VARCHAR2(20)",  "not_null": False, "notes": ""},
            {"name": "INTERNAL_REF_NO",        "type": "VARCHAR2(25)",  "not_null": False, "notes": ""},
            {"name": "ACTUAL_VOLUME",          "type": "NUMBER(10,0)",  "not_null": True,  "notes": ""},
        ]
    },
    "SYMBOL_MARKETS": {
        "grain": "",
        "date_key": "",
        "notes": "STATE: 0=Open, 1=Suspended, 2=Deleted",
        "columns": [
            {"name": "TICK_SIZE",                       "type": "NUMBER(8,4)",    "not_null": True,  "notes": ""},
            {"name": "BOARD_LOT",                       "type": "NUMBER(6,0)",    "not_null": True,  "notes": ""},
            {"name": "UPPER_CIRCUIT_BREAKER_LIMIT",     "type": "NUMBER(14,4)",   "not_null": True,  "notes": ""},
            {"name": "LOWER_CIRCUIT_BREAKER_LIMIT",     "type": "NUMBER(14,4)",   "not_null": True,  "notes": ""},
            {"name": "UPPER_ORDER_VALUE_LIMIT",         "type": "NUMBER(15,4)",   "not_null": True,  "notes": ""},
            {"name": "LOWER_ORDER_VALUE_LIMIT",         "type": "NUMBER(15,4)",   "not_null": True,  "notes": ""},
            {"name": "UPPER_ORDER_VOLUME_LIMIT",        "type": "NUMBER(10,0)",   "not_null": True,  "notes": ""},
            {"name": "LOWER_ORDER_VOLUME_LIMIT",        "type": "NUMBER(10,0)",   "not_null": True,  "notes": ""},
            {"name": "MARKET_ID",                       "type": "NUMBER(4,0)",    "not_null": True,  "notes": "PK, FK→ATS.MARKETS(MARKET_ID)"},
            {"name": "SYMBOL_ID",                       "type": "NUMBER(15,0)",   "not_null": True,  "notes": "PK, FK→ATS.SYMBOLS(SYMBOL_ID)"},
            {"name": "FIFTY_TWO_WEEK_HIGH",             "type": "NUMBER(10,4)",   "not_null": False, "notes": ""},
            {"name": "FIFTY_TWO_WEEK_LOW",              "type": "NUMBER(10,4)",   "not_null": False, "notes": ""},
            {"name": "EXCHANGE_ID",                     "type": "NUMBER(4,0)",    "not_null": True,  "notes": "PK, FK→ATS.EXCHANGES(EXCHANGE_ID)"},
            {"name": "CLOSE_PRICE",                     "type": "NUMBER(16,4)",   "not_null": False, "notes": ""},
            {"name": "STATE",                           "type": "NUMBER(1,0)",    "not_null": False, "notes": "0=Open, 1=Suspended, 2=Deleted"},
            {"name": "EXCHANGE_MARKET_ID",              "type": "NUMBER(10,0)",   "not_null": True,  "notes": "FK→ATS.EXCHANGE_MARKETS(EXCHANGE_MARKET_ID)"},
            {"name": "CREATION_DATE",                   "type": "DATE",           "not_null": True,  "notes": ""},
            {"name": "MODIFIED_BY",                     "type": "VARCHAR2(32)",   "not_null": True,  "notes": ""},
            {"name": "MODIFIED_DATE",                   "type": "DATE",           "not_null": True,  "notes": ""},
            {"name": "MARKET_CONFIG_OVERRIDE",          "type": "NUMBER(1,0)",    "not_null": True,  "notes": ""},
            {"name": "UPPER_VOLUME_ALERT_LIMIT",        "type": "NUMBER(10,0)",   "not_null": True,  "notes": ""},
            {"name": "LOWER_VOLUME_ALERT_LIMIT",        "type": "NUMBER(10,0)",   "not_null": True,  "notes": ""},
            {"name": "UPPER_VALUE_ALERT_LIMIT",         "type": "NUMBER(15,4)",   "not_null": True,  "notes": ""},
            {"name": "LOWER_VALUE_ALERT_LIMIT",         "type": "NUMBER(15,4)",   "not_null": True,  "notes": ""},
            {"name": "MBO_DEPTH",                       "type": "NUMBER(4,0)",    "not_null": True,  "notes": ""},
            {"name": "MBP_DEPTH",                       "type": "NUMBER(4,0)",    "not_null": True,  "notes": ""},
            {"name": "ALLOW_SHORT_SELL",                "type": "NUMBER(1,0)",    "not_null": True,  "notes": ""},
            {"name": "UPPER_CIRCUIT_PERCENT",           "type": "NUMBER(3,0)",    "not_null": True,  "notes": ""},
            {"name": "LOWER_CIRCUIT_PERCENT",           "type": "NUMBER(3,0)",    "not_null": True,  "notes": ""},
            {"name": "QUOTE_SPREAD",                    "type": "NUMBER(14,4)",   "not_null": False, "notes": ""},
            {"name": "REASON",                          "type": "NVARCHAR2(160)", "not_null": False, "notes": ""},
            {"name": "FIXED_TICK_SIZE",                 "type": "NUMBER(1,0)",    "not_null": False, "notes": ""},
            {"name": "NEG_UPPER_CIRCUIT_BREAKER_LIMT",  "type": "NUMBER(14,4)",  "not_null": False, "notes": ""},
            {"name": "NEG_LOWER_CIRCUIT_BREAKER_LIMT",  "type": "NUMBER(14,4)",  "not_null": False, "notes": ""},
            {"name": "NEG_UPPER_CIRCUIT_PERCENT",       "type": "NUMBER(3,0)",    "not_null": False, "notes": ""},
            {"name": "NEG_LOWER_CIRCUIT_PERCENT",       "type": "NUMBER(3,0)",    "not_null": False, "notes": ""},
            {"name": "MIN_TRADE_VOLUME",                "type": "NUMBER(15,0)",   "not_null": False, "notes": ""},
            {"name": "NO_OF_DAYS",                      "type": "NUMBER(10,0)",   "not_null": False, "notes": ""},
            {"name": "DYN_UPPER_CIRCUIT_PERCENT",       "type": "NUMBER(3,0)",    "not_null": False, "notes": ""},
            {"name": "DYN_LOWER_CIRCUIT_PERCENT",       "type": "NUMBER(3,0)",    "not_null": False, "notes": ""},
            {"name": "NEG_DYN_LOWER_CIRCUIT_PERCENT",   "type": "NUMBER(3,0)",    "not_null": False, "notes": ""},
            {"name": "NEG_DYN_UPPER_CIRCUIT_PERCENT",   "type": "NUMBER(3,0)",    "not_null": False, "notes": ""},
        ]
    },
    "FLAGS": {
        "grain": "",
        "date_key": "",
        "notes": "",
        "columns": [
            {"name": "FLAG_CODE", "type": "NVARCHAR2(20)", "not_null": True,  "notes": ""},
            {"name": "DESC_",     "type": "NVARCHAR2(20)", "not_null": True,  "notes": ""},
            {"name": "FLAG_ID",   "type": "NUMBER(2,0)",   "not_null": True,  "notes": "PK"},
        ]
    },
    "ORDER_TYPES": {
        "grain": "",
        "date_key": "",
        "notes": "",
        "columns": [
            {"name": "ID",          "type": "NUMBER(4,0)",   "not_null": True,  "notes": "PK"},
            {"name": "CODE",        "type": "VARCHAR2(20)",  "not_null": True,  "notes": ""},
            {"name": "DESCRIPTION", "type": "VARCHAR2(100)", "not_null": False, "notes": ""},
        ]
    },
    "ORDER_STATES": {
        "grain": "",
        "date_key": "",
        "notes": "",
        "columns": [
            {"name": "STATE_ID",   "type": "NUMBER(2,0)",  "not_null": True, "notes": "PK"},
            {"name": "STATE_CODE", "type": "VARCHAR2(32)", "not_null": True, "notes": ""},
        ]
    },
    "SUBSCRIBED_BROKERS": {
        "grain": "",
        "date_key": "",
        "notes": "",
        "columns": [
            {"name": "BROKER_CODE",              "type": "NVARCHAR2(35)",  "not_null": True,  "notes": ""},
            {"name": "BROKER_ID",                "type": "NUMBER(5,0)",    "not_null": True,  "notes": "PK"},
            {"name": "CASH",                     "type": "NUMBER(15,0)",   "not_null": False, "notes": ""},
            {"name": "CREDIT_LINE_LIMIT",        "type": "NUMBER(20,4)",   "not_null": False, "notes": ""},
            {"name": "CM_ID",                    "type": "NUMBER(5,0)",    "not_null": False, "notes": ""},
            {"name": "EXCHANGE_ID",              "type": "NUMBER(5,0)",    "not_null": False, "notes": "FK→ATS.EXCHANGES(EXCHANGE_ID)"},
            {"name": "ACTIVE",                   "type": "NUMBER(1,0)",    "not_null": True,  "notes": ""},
            {"name": "BYPASS_CASH_LIMIT",        "type": "NUMBER(1,0)",    "not_null": False, "notes": ""},
            {"name": "BYPASS_RISK",              "type": "NUMBER(1,0)",    "not_null": False, "notes": ""},
            {"name": "CREATION_DATE",            "type": "DATE",           "not_null": True,  "notes": ""},
            {"name": "MODIFIED_BY",              "type": "VARCHAR2(32)",   "not_null": True,  "notes": ""},
            {"name": "MODIFIED_DATE",            "type": "DATE",           "not_null": True,  "notes": ""},
            {"name": "MOBILE",                   "type": "VARCHAR2(25)",   "not_null": False, "notes": ""},
            {"name": "EMAIL",                    "type": "VARCHAR2(100)",  "not_null": False, "notes": ""},
            {"name": "BROKER_NAME",              "type": "NVARCHAR2(200)", "not_null": False, "notes": ""},
            {"name": "BROKER_TYPE_ID",           "type": "NUMBER(3,0)",    "not_null": True,  "notes": "FK→ATS.BROKER_TYPES(BROKER_TYPE_ID)"},
            {"name": "BYPASS_CREDIT_LINE_LIMIT", "type": "NUMBER(1,0)",    "not_null": False, "notes": ""},
            {"name": "BYPASS_SHORT_SELL",        "type": "NUMBER(1,0)",    "not_null": False, "notes": ""},
            {"name": "ADDRESS",                  "type": "NVARCHAR2(264)", "not_null": False, "notes": ""},
            {"name": "COUNTRY",                  "type": "NVARCHAR2(64)",  "not_null": False, "notes": ""},
            {"name": "FAX",                      "type": "NVARCHAR2(100)", "not_null": False, "notes": ""},
            {"name": "TRADER_ID",                "type": "NUMBER(30,0)",   "not_null": False, "notes": ""},
        ]
    },
    "EDS_CLIENTS": {
        "grain": "",
        "date_key": "",
        "notes": "ACTIVE: 0=Active, 1=Suspended",
        "columns": [
            {"name": "CLIENT_CODE",          "type": "NVARCHAR2(30)",  "not_null": True,  "notes": ""},
            {"name": "AGENT_ID",             "type": "NUMBER(6,0)",    "not_null": False, "notes": ""},
            {"name": "CLIENT_ID",            "type": "NUMBER(20,0)",   "not_null": True,  "notes": "PK"},
            {"name": "BRANCH_ID",            "type": "NUMBER(6,0)",    "not_null": False, "notes": ""},
            {"name": "BROKER_ID",            "type": "NUMBER(5,0)",    "not_null": False, "notes": ""},
            {"name": "CLIENT_GROUP_ID",      "type": "NUMBER(10,0)",   "not_null": False, "notes": ""},
            {"name": "DEFAULT_EXCHANGE_ID",  "type": "NUMBER(4,0)",    "not_null": False, "notes": "FK→ATS.EXCHANGES(EXCHANGE_ID)"},
            {"name": "ACTIVE",               "type": "NUMBER(1,0)",    "not_null": False, "notes": "0=Active, 1=Suspended"},
            {"name": "NAME",                 "type": "NVARCHAR2(400)", "not_null": False, "notes": ""},
            {"name": "MOBILE",               "type": "NVARCHAR2(30)",  "not_null": False, "notes": ""},
            {"name": "TELEPHONE",            "type": "NVARCHAR2(30)",  "not_null": False, "notes": ""},
            {"name": "NIC",                  "type": "NVARCHAR2(30)",  "not_null": False, "notes": ""},
            {"name": "DEPO_REFERENCE",       "type": "NVARCHAR2(64)",  "not_null": True,  "notes": ""},
            {"name": "MODIFICATION_DATE",    "type": "DATE",           "not_null": True,  "notes": ""},
            {"name": "REGISTRATION_DATE",    "type": "DATE",           "not_null": True,  "notes": ""},
            {"name": "IS_FOREIGNER",         "type": "VARCHAR2(1)",    "not_null": False, "notes": ""},
            {"name": "ADDRESS",              "type": "NVARCHAR2(264)", "not_null": False, "notes": ""},
            {"name": "EMAIL",                "type": "NVARCHAR2(200)", "not_null": False, "notes": ""},
            {"name": "COUNTRY",              "type": "NVARCHAR2(64)",  "not_null": False, "notes": ""},
            {"name": "FAX",                  "type": "NVARCHAR2(100)", "not_null": False, "notes": ""},
            {"name": "IS_PROPRIETARY",       "type": "NUMBER(1,0)",    "not_null": False, "notes": ""},
            {"name": "IS_TAX_EXMP",          "type": "NUMBER(1,0)",    "not_null": False, "notes": ""},
            {"name": "IS_POLITICAL_PERSON",  "type": "CHAR(1)",        "not_null": False, "notes": ""},
        ]
    },
    "USERS": {
        "grain": "",
        "date_key": "",
        "notes": "STATUS: 1=Active, 0=Suspended",
        "columns": [
            {"name": "USER_ID",                  "type": "NUMBER(30,0)",   "not_null": True,  "notes": "PK"},
            {"name": "USER_NAME",                "type": "NVARCHAR2(32)",  "not_null": True,  "notes": ""},
            {"name": "PASSWORD",                 "type": "NVARCHAR2(32)",  "not_null": True,  "notes": ""},
            {"name": "EMAIL",                    "type": "NVARCHAR2(256)", "not_null": False, "notes": ""},
            {"name": "USER_TYPE_ID",             "type": "NUMBER(3,0)",    "not_null": False, "notes": "FK→ATS.USER_TYPES(TYPE_ID)"},
            {"name": "BROKER_ID",                "type": "NUMBER(5,0)",    "not_null": False, "notes": "FK→ATS.SUBSCRIBED_BROKERS(BROKER_ID)"},
            {"name": "LAST_LOGIN_DATETIME",      "type": "DATE",           "not_null": False, "notes": ""},
            {"name": "LAST_LOGIN_IP",            "type": "NVARCHAR2(15)",  "not_null": False, "notes": ""},
            {"name": "SKIN",                     "type": "NVARCHAR2(30)",  "not_null": False, "notes": ""},
            {"name": "STATUS",                   "type": "NUMBER(2,0)",    "not_null": False, "notes": "FK→ATS.USER_STATUS(ID), 1=Active, 0=Suspended"},
            {"name": "TWO_FACTOR_AUTH",          "type": "NUMBER(1,0)",    "not_null": False, "notes": ""},
            {"name": "PWD_OTP_FLAG",             "type": "NUMBER(1,0)",    "not_null": False, "notes": ""},
            {"name": "PWD_EXPIRY_DATE",          "type": "DATE",           "not_null": True,  "notes": ""},
            {"name": "CREATION_DATE",            "type": "DATE",           "not_null": True,  "notes": ""},
            {"name": "MODIFIED_BY",              "type": "VARCHAR2(32)",   "not_null": True,  "notes": ""},
            {"name": "MODIFIED_DATE",            "type": "DATE",           "not_null": True,  "notes": ""},
            {"name": "MOBILE",                   "type": "VARCHAR2(15)",   "not_null": False, "notes": ""},
            {"name": "IP_ADDRESS",               "type": "VARCHAR2(20)",   "not_null": False, "notes": ""},
            {"name": "MAC_ADDRESS",              "type": "VARCHAR2(60)",   "not_null": False, "notes": ""},
            {"name": "COMPLETE_NAME",            "type": "VARCHAR2(64)",   "not_null": True,  "notes": ""},
            {"name": "SEND_SMS",                 "type": "NVARCHAR2(1)",   "not_null": True,  "notes": ""},
            {"name": "LOGIN_SMS",                "type": "NVARCHAR2(1)",   "not_null": True,  "notes": ""},
            {"name": "SMS_AUTH_SUBSCRIPTION",    "type": "NVARCHAR2(1)",   "not_null": True,  "notes": ""},
            {"name": "USER_EXPIRY",              "type": "NVARCHAR2(1)",   "not_null": False, "notes": ""},
        ]
    },
    "TRADES": {
        "grain": "trade_event",
        "date_key": "ENTRY_DATETIME",
        "notes": "CRITICAL: No ORDER_NO column. Link via BUYER_ORDER_NO/SELLER_ORDER_NO→ORDERS.ORDER_NO.",
        "columns": [
            {"name": "ENTRY_DATETIME",          "type": "TIMESTAMP(6)",  "not_null": True,  "notes": "PK"},
            {"name": "TICKET_NO",               "type": "NUMBER(10,0)",  "not_null": True,  "notes": "PK"},
            {"name": "SELLER_ORDER_NO",         "type": "NUMBER(10,0)",  "not_null": True,  "notes": ""},
            {"name": "BUYER_ORDER_NO",          "type": "NUMBER(10,0)",  "not_null": True,  "notes": ""},
            {"name": "PRICE",                   "type": "NUMBER(16,4)",  "not_null": True,  "notes": ""},
            {"name": "VOLUME",                  "type": "NUMBER(10,0)",  "not_null": True,  "notes": ""},
            {"name": "EXCHANGE_ID",             "type": "NUMBER(4,0)",   "not_null": True,  "notes": "PK, FK→ATS.SYMBOL_MARKETS(EXCHANGE_ID)"},
            {"name": "BUYER_CLIENT_ID",         "type": "NUMBER(20,0)",  "not_null": True,  "notes": "FK→ATS.EDS_CLIENTS(CLIENT_ID)"},
            {"name": "SELLER_CLIENT_ID",        "type": "NUMBER(20,0)",  "not_null": True,  "notes": "FK→ATS.EDS_CLIENTS(CLIENT_ID)"},
            {"name": "SYMBOL_ID",               "type": "NUMBER(15,0)",  "not_null": True,  "notes": "PK, FK→ATS.SYMBOL_MARKETS(SYMBOL_ID)"},
            {"name": "MARKET_ID",               "type": "NUMBER(4,0)",   "not_null": True,  "notes": "PK, FK→ATS.SYMBOL_MARKETS(MARKET_ID)"},
            {"name": "BUYER_BROKER_ID",         "type": "NUMBER(5,0)",   "not_null": True,  "notes": "FK→ATS.SUBSCRIBED_BROKERS(BROKER_ID)"},
            {"name": "SELLER_BROKER_ID",        "type": "NUMBER(5,0)",   "not_null": True,  "notes": "FK→ATS.SUBSCRIBED_BROKERS(BROKER_ID)"},
            {"name": "BUYER_USER_ID",           "type": "NUMBER(30,0)",  "not_null": True,  "notes": "FK→ATS.USERS(USER_ID)"},
            {"name": "SELLER_USER_ID",          "type": "NUMBER(30,0)",  "not_null": True,  "notes": "FK→ATS.USERS(USER_ID)"},
            {"name": "TRADE_TYPE",              "type": "NUMBER(1,0)",   "not_null": True,  "notes": ""},
            {"name": "IS_SHORT",                "type": "NVARCHAR2(1)",  "not_null": True,  "notes": ""},
            {"name": "STATE_ID",                "type": "NUMBER(2,0)",   "not_null": True,  "notes": "FK→ATS.TRADE_STATES(STATE_ID)"},
            {"name": "BUYER_REMAINING_VOLUME",  "type": "NUMBER(10,0)",  "not_null": True,  "notes": ""},
            {"name": "SELLER_REMAINING_VOLUME", "type": "NUMBER(10,0)",  "not_null": True,  "notes": ""},
            {"name": "BUYER_CUSTODIAN_ID",      "type": "NUMBER(20,0)",  "not_null": False, "notes": ""},
            {"name": "SELLER_CUSTODIAN_ID",     "type": "NUMBER(20,0)",  "not_null": False, "notes": ""},
            {"name": "ACCRUED_PROFIT",          "type": "NUMBER(24,6)",  "not_null": False, "notes": ""},
            {"name": "YIELD",                   "type": "NUMBER(15,4)",  "not_null": False, "notes": ""},
            {"name": "VALUE",                   "type": "NUMBER(24,6)",  "not_null": False, "notes": ""},
            {"name": "PRICING_MECHANISM",       "type": "NUMBER(1,0)",   "not_null": False, "notes": ""},
            {"name": "PRICING_MODEL",           "type": "NUMBER(1,0)",   "not_null": False, "notes": ""},
            {"name": "SETTLEMENT_TYPE_ID",      "type": "NUMBER(4,0)",   "not_null": False, "notes": ""},
            {"name": "SETTLEMENT_AMOUNT",       "type": "NUMBER(24,6)",  "not_null": False, "notes": ""},
            {"name": "CONTRACT_ID",             "type": "VARCHAR2(25)",  "not_null": False, "notes": ""},
            {"name": "INITIAL_DATE",            "type": "DATE",          "not_null": False, "notes": ""},
            {"name": "TERMINATION_DATE",        "type": "DATE",          "not_null": False, "notes": ""},
            {"name": "LEG",                     "type": "NUMBER(1,0)",   "not_null": False, "notes": ""},
            {"name": "REPURCHASE_PRICE",        "type": "NUMBER(16,4)",  "not_null": False, "notes": ""},
            {"name": "DIRTY_PRICE",             "type": "NUMBER(16,4)",  "not_null": False, "notes": ""},
            {"name": "BUYER_TRADER_ID",         "type": "NUMBER(30,0)",  "not_null": False, "notes": ""},
            {"name": "SELLER_TRADER_ID",        "type": "NUMBER(30,0)",  "not_null": False, "notes": ""},
        ]
    },
    "CANCELLED_TRADES": {
        "grain": "cancel_event",
        "date_key": "ENTRY_DATETIME",
        "notes": "Standalone cancellation events; 1:1 linkage to TRADES by TICKET_NO not guaranteed.",
        "columns": [
            {"name": "ENTRY_DATETIME",          "type": "TIMESTAMP(6)",  "not_null": True,  "notes": ""},
            {"name": "TICKET_NO",               "type": "NUMBER(10,0)",  "not_null": True,  "notes": ""},
            {"name": "SELLER_ORDER_NO",         "type": "NUMBER(10,0)",  "not_null": True,  "notes": ""},
            {"name": "BUYER_ORDER_NO",          "type": "NUMBER(10,0)",  "not_null": True,  "notes": ""},
            {"name": "PRICE",                   "type": "NUMBER(16,4)",  "not_null": True,  "notes": ""},
            {"name": "VOLUME",                  "type": "NUMBER(10,0)",  "not_null": True,  "notes": ""},
            {"name": "EXCHANGE_ID",             "type": "NUMBER(4,0)",   "not_null": True,  "notes": ""},
            {"name": "BUYER_CLIENT_ID",         "type": "NUMBER(20,0)",  "not_null": True,  "notes": ""},
            {"name": "SELLER_CLIENT_ID",        "type": "NUMBER(20,0)",  "not_null": True,  "notes": ""},
            {"name": "SYMBOL_ID",               "type": "NUMBER(15,0)",  "not_null": True,  "notes": ""},
            {"name": "MARKET_ID",               "type": "NUMBER(4,0)",   "not_null": True,  "notes": ""},
            {"name": "BUYER_BROKER_ID",         "type": "NUMBER(5,0)",   "not_null": True,  "notes": ""},
            {"name": "SELLER_BROKER_ID",        "type": "NUMBER(5,0)",   "not_null": True,  "notes": ""},
            {"name": "BUYER_USER_ID",           "type": "NUMBER(30,0)",  "not_null": True,  "notes": ""},
            {"name": "SELLER_USER_ID",          "type": "NUMBER(30,0)",  "not_null": True,  "notes": ""},
            {"name": "TRADE_TYPE",              "type": "NUMBER(1,0)",   "not_null": True,  "notes": ""},
            {"name": "IS_SHORT",                "type": "NVARCHAR2(1)",  "not_null": True,  "notes": ""},
            {"name": "STATE_ID",                "type": "NUMBER(2,0)",   "not_null": True,  "notes": ""},
            {"name": "BUYER_REMAINING_VOLUME",  "type": "NUMBER(10,0)",  "not_null": True,  "notes": ""},
            {"name": "SELLER_REMAINING_VOLUME", "type": "NUMBER(10,0)",  "not_null": True,  "notes": ""},
            {"name": "BUYER_CUSTODIAN_ID",      "type": "NUMBER(20,0)",  "not_null": False, "notes": ""},
            {"name": "SELLER_CUSTODIAN_ID",     "type": "NUMBER(20,0)",  "not_null": False, "notes": ""},
            {"name": "ACCRUED_PROFIT",          "type": "NUMBER(20,4)",  "not_null": False, "notes": ""},
            {"name": "YIELD",                   "type": "NUMBER(16,4)",  "not_null": False, "notes": ""},
            {"name": "VALUE",                   "type": "NUMBER(20,4)",  "not_null": False, "notes": ""},
            {"name": "PRICING_MECHANISM",       "type": "NUMBER(1,0)",   "not_null": False, "notes": ""},
            {"name": "PRICING_MODEL",           "type": "NUMBER(1,0)",   "not_null": False, "notes": ""},
            {"name": "SETTLEMENT_TYPE_ID",      "type": "NUMBER(4,0)",   "not_null": False, "notes": ""},
            {"name": "SETTLEMENT_AMOUNT",       "type": "NUMBER(20,4)",  "not_null": False, "notes": ""},
            {"name": "CONTRACT_ID",             "type": "VARCHAR2(25)",  "not_null": False, "notes": ""},
            {"name": "INITIAL_DATE",            "type": "DATE",          "not_null": False, "notes": ""},
            {"name": "TERMINATION_DATE",        "type": "DATE",          "not_null": False, "notes": ""},
            {"name": "LEG",                     "type": "NUMBER(1,0)",   "not_null": False, "notes": ""},
            {"name": "REPURCHASE_PRICE",        "type": "NUMBER(16,4)",  "not_null": False, "notes": ""},
            {"name": "DIRTY_PRICE",             "type": "NUMBER(16,4)",  "not_null": False, "notes": ""},
            {"name": "BUYER_TRADER_ID",         "type": "NUMBER(30,0)",  "not_null": False, "notes": ""},
            {"name": "SELLER_TRADER_ID",        "type": "NUMBER(30,0)",  "not_null": False, "notes": ""},
            {"name": "TRADE_DATETIME",          "type": "TIMESTAMP(6)",  "not_null": False, "notes": ""},
            {"name": "CANCELLATION_DATETIME",   "type": "TIMESTAMP(6)",  "not_null": False, "notes": ""},
        ]
    },
    "NEGOTIATED_TRADES": {
        "grain": "negotiation_event",
        "date_key": "ENTRY_DATETIME",
        "notes": "Uses CLIENT_ID / COUNTER_CLIENT_ID (NOT BUYER/SELLER).",
        "columns": [
            {"name": "ENTRY_DATETIME",         "type": "TIMESTAMP(6)",  "not_null": True,  "notes": ""},
            {"name": "ORDER_NO",               "type": "NUMBER(10,0)",  "not_null": True,  "notes": ""},
            {"name": "VOLUME",                 "type": "NUMBER(10,0)",  "not_null": True,  "notes": ""},
            {"name": "PRICE",                  "type": "NUMBER(14,4)",  "not_null": True,  "notes": ""},
            {"name": "IS_SHORT",               "type": "NVARCHAR2(1)",  "not_null": True,  "notes": ""},
            {"name": "DISCLOSED_VOLUME",       "type": "NUMBER(10,0)",  "not_null": True,  "notes": ""},
            {"name": "SIDE",                   "type": "NVARCHAR2(1)",  "not_null": True,  "notes": ""},
            {"name": "TIF",                    "type": "DATE",          "not_null": False, "notes": ""},
            {"name": "REF_NO",                 "type": "VARCHAR2(20)",  "not_null": False, "notes": ""},
            {"name": "TRIGGER_PRICE",          "type": "NUMBER(14,4)",  "not_null": True,  "notes": ""},
            {"name": "TRAILING_STOPLOSS_DIP",  "type": "NUMBER(14,4)",  "not_null": True,  "notes": ""},
            {"name": "CLIENT_ID",              "type": "NUMBER(20,0)",  "not_null": True,  "notes": ""},
            {"name": "FLAG_ID",                "type": "NUMBER(2,0)",   "not_null": False, "notes": ""},
            {"name": "SYMBOL_ID",              "type": "NUMBER(15,0)",  "not_null": True,  "notes": ""},
            {"name": "MARKET_ID",              "type": "NUMBER(4,0)",   "not_null": True,  "notes": ""},
            {"name": "EXCHANGE_ID",            "type": "NUMBER(4,0)",   "not_null": True,  "notes": ""},
            {"name": "BROKER_ID",              "type": "NUMBER(5,0)",   "not_null": True,  "notes": ""},
            {"name": "USER_ID",                "type": "NUMBER(30,0)",  "not_null": True,  "notes": ""},
            {"name": "STATE",                  "type": "NUMBER(1,0)",   "not_null": True,  "notes": ""},
            {"name": "TRADER_ID",              "type": "NUMBER(30,0)",  "not_null": False, "notes": ""},
            {"name": "ORDER_TYPE",             "type": "NUMBER(1,0)",   "not_null": True,  "notes": ""},
            {"name": "COUNTER_ORDER_NO",       "type": "NUMBER(10,0)",  "not_null": True,  "notes": ""},
            {"name": "COUNTER_USER_ID",        "type": "NUMBER(30,0)",  "not_null": True,  "notes": ""},
            {"name": "COUNTER_CLIENT_ID",      "type": "NUMBER(20,0)",  "not_null": False, "notes": ""},
            {"name": "COUNTER_BROKER_ID",      "type": "NUMBER(5,0)",   "not_null": True,  "notes": ""},
            {"name": "NEGOTIATED_STATE",       "type": "NUMBER(1,0)",   "not_null": True,  "notes": ""},
            {"name": "PRICE_TYPE",             "type": "NUMBER(1,0)",   "not_null": True,  "notes": ""},
            {"name": "CUSTODIAN_ID",           "type": "NUMBER(20,0)",  "not_null": True,  "notes": ""},
            {"name": "COUNTER_CUSTODIAN_ID",   "type": "NUMBER(20,0)",  "not_null": False, "notes": ""},
            {"name": "YIELD",                  "type": "NUMBER(15,4)",  "not_null": False, "notes": ""},
            {"name": "ACCRUED_PROFIT",         "type": "NUMBER(16,4)",  "not_null": False, "notes": ""},
            {"name": "VALUE",                  "type": "NUMBER(20,4)",  "not_null": False, "notes": ""},
            {"name": "PRICING_MECHANISM",      "type": "NUMBER(1,0)",   "not_null": False, "notes": ""},
            {"name": "SETTLEMENT_TYPE_ID",     "type": "NUMBER(4,0)",   "not_null": False, "notes": ""},
            {"name": "SWIFT_REF_NO",           "type": "VARCHAR2(20)",  "not_null": False, "notes": ""},
            {"name": "NEGOTIATED_STATUS",      "type": "NUMBER(1,0)",   "not_null": False, "notes": ""},
            {"name": "INTERNAL_REF_NO",        "type": "VARCHAR2(25)",  "not_null": False, "notes": ""},
        ]
    },
    "TRADE_STATES": {
        "grain": "",
        "date_key": "",
        "notes": "",
        "columns": [
            {"name": "STATE_ID",   "type": "NUMBER(2,0)",  "not_null": True, "notes": "PK"},
            {"name": "STATE_CODE", "type": "VARCHAR2(32)", "not_null": True, "notes": ""},
        ]
    },
    "SETTLEMENT_TYPES": {
        "grain": "",
        "date_key": "",
        "notes": "",
        "columns": [
            {"name": "SETTLEMENT_TYPE",     "type": "NVARCHAR2(64)",  "not_null": True, "notes": ""},
            {"name": "SETTLEMENT_DESC",     "type": "NVARCHAR2(256)", "not_null": False, "notes": ""},
            {"name": "TRADE_DAYS",          "type": "NUMBER(3,0)",    "not_null": True,  "notes": ""},
            {"name": "SETTLEMENT_DAYS",     "type": "NUMBER(3,0)",    "not_null": True,  "notes": ""},
            {"name": "SETTLEMENT_TYPE_ID",  "type": "NUMBER(4,0)",    "not_null": True,  "notes": "PK"},
            {"name": "ACTIVE",              "type": "NCHAR(1)",       "not_null": True,  "notes": ""},
            {"name": "CREATION_DATE",       "type": "DATE",           "not_null": True,  "notes": ""},
            {"name": "MODIFIED_BY",         "type": "VARCHAR2(32)",   "not_null": True,  "notes": ""},
            {"name": "MODIFIED_DATE",       "type": "DATE",           "not_null": True,  "notes": ""},
        ]
    },
    "SYMBOL_TYPES": {
        "grain": "",
        "date_key": "",
        "notes": "",
        "columns": [
            {"name": "SYMBOL_TYPE_ID", "type": "NUMBER(2,0)",   "not_null": True, "notes": "PK"},
            {"name": "SYMBOL_TYPE",    "type": "NVARCHAR2(20)", "not_null": True, "notes": ""},
        ]
    },
    "REJECTED_ORDERS": {
        "grain": "rejection_event",
        "date_key": "ENTRY_DATETIME",
        "notes": "Join REJECTION_ID→REJECTIONS.DESCRIPTION for human-readable reasons.",
        "columns": [
            {"name": "ENTRY_DATETIME",         "type": "TIMESTAMP(6)",  "not_null": True,  "notes": ""},
            {"name": "ORDER_NO",               "type": "NUMBER(10,0)",  "not_null": True,  "notes": ""},
            {"name": "VOLUME",                 "type": "NUMBER(10,0)",  "not_null": True,  "notes": ""},
            {"name": "PRICE",                  "type": "NUMBER(14,4)",  "not_null": True,  "notes": ""},
            {"name": "IS_SHORT",               "type": "NVARCHAR2(1)",  "not_null": True,  "notes": ""},
            {"name": "DISCLOSED_VOLUME",       "type": "NUMBER(10,0)",  "not_null": True,  "notes": ""},
            {"name": "SIDE",                   "type": "NVARCHAR2(1)",  "not_null": True,  "notes": ""},
            {"name": "TIF",                    "type": "DATE",          "not_null": False, "notes": ""},
            {"name": "REF_NO",                 "type": "VARCHAR2(20)",  "not_null": False, "notes": ""},
            {"name": "TRIGGER_PRICE",          "type": "NUMBER(14,4)",  "not_null": True,  "notes": ""},
            {"name": "TRAILING_STOPLOSS_DIP",  "type": "NUMBER(14,4)",  "not_null": True,  "notes": ""},
            {"name": "CLIENT_ID",              "type": "NUMBER(20,0)",  "not_null": True,  "notes": ""},
            {"name": "FLAG_ID",                "type": "NUMBER(2,0)",   "not_null": False, "notes": ""},
            {"name": "SYMBOL_ID",              "type": "NUMBER(15,0)",  "not_null": True,  "notes": ""},
            {"name": "MARKET_ID",              "type": "NUMBER(4,0)",   "not_null": True,  "notes": ""},
            {"name": "EXCHANGE_ID",            "type": "NUMBER(4,0)",   "not_null": True,  "notes": ""},
            {"name": "BROKER_ID",              "type": "NUMBER(5,0)",   "not_null": True,  "notes": ""},
            {"name": "USER_ID",                "type": "NUMBER(30,0)",  "not_null": True,  "notes": ""},
            {"name": "STATE",                  "type": "NUMBER(1,0)",   "not_null": True,  "notes": ""},
            {"name": "TRADER_ID",              "type": "NUMBER(30,0)",  "not_null": False, "notes": ""},
            {"name": "ORDER_TYPE",             "type": "NUMBER(1,0)",   "not_null": True,  "notes": ""},
            {"name": "PRICE_TYPE",             "type": "NUMBER(1,0)",   "not_null": True,  "notes": ""},
            {"name": "REJECTION_ID",           "type": "NUMBER(2,0)",   "not_null": False, "notes": ""},
            {"name": "SOURCE_ID",              "type": "NUMBER(2,0)",   "not_null": False, "notes": ""},
            {"name": "STATE_TIME",             "type": "TIMESTAMP(6)",  "not_null": False, "notes": ""},
            {"name": "QUOTE_ID",               "type": "NUMBER(10,0)",  "not_null": False, "notes": ""},
            {"name": "CUSTODIAN_ID",           "type": "NUMBER(20,0)",  "not_null": False, "notes": ""},
            {"name": "YIELD",                  "type": "NUMBER(15,4)",  "not_null": False, "notes": ""},
            {"name": "ACCRUED_PROFIT",         "type": "NUMBER(16,4)",  "not_null": False, "notes": ""},
            {"name": "VALUE",                  "type": "NUMBER(20,4)",  "not_null": False, "notes": ""},
            {"name": "PRICING_MECHANISM",      "type": "NUMBER(1,0)",   "not_null": False, "notes": ""},
            {"name": "CLIENT_CODE",            "type": "NVARCHAR2(30)", "not_null": False, "notes": ""},
            {"name": "INTERNAL_REF_NO",        "type": "VARCHAR2(25)",  "not_null": False, "notes": ""},
            {"name": "ACTUAL_VOLUME",          "type": "NUMBER(10,0)",  "not_null": True,  "notes": ""},
        ]
    },
    "REJECTIONS": {
        "grain": "",
        "date_key": "",
        "notes": "",
        "columns": [
            {"name": "REJECTION_ID",  "type": "NUMBER(2,0)",   "not_null": True, "notes": "PK"},
            {"name": "DESCRIPTION",   "type": "VARCHAR2(250)", "not_null": True, "notes": ""},
        ]
    },
    "ATS_LEVY_DATA_LOG": {
        "grain": "levy_log_event",
        "date_key": "TRANSACTION_DATE",
        "notes": "Operational levy log; may include entries without market/side.",
        "columns": [
            {"name": "TRANSACTION_ID",   "type": "NUMBER(14,0)",   "not_null": False, "notes": ""},
            {"name": "TRANSACTION_DATE", "type": "DATE",           "not_null": False, "notes": ""},
            {"name": "TICKET_NO",        "type": "NUMBER(10,0)",   "not_null": False, "notes": ""},
            {"name": "BROKER_ID",        "type": "NUMBER(5,0)",    "not_null": False, "notes": ""},
            {"name": "ACCOUNT_ID",       "type": "NUMBER(20,0)",   "not_null": False, "notes": ""},
            {"name": "LEVY_ID",          "type": "NUMBER(8,0)",    "not_null": False, "notes": ""},
            {"name": "PRICE",            "type": "NUMBER(14,4)",   "not_null": False, "notes": ""},
            {"name": "VOLUME",           "type": "NUMBER(10,0)",   "not_null": False, "notes": ""},
            {"name": "AMOUNT",           "type": "NUMBER(15,4)",   "not_null": False, "notes": ""},
            {"name": "LEVY_AMOUNT",      "type": "NUMBER(14,4)",   "not_null": False, "notes": ""},
            {"name": "LEVY_RATE",        "type": "NUMBER(14,4)",   "not_null": False, "notes": ""},
            {"name": "BUY_SELL",         "type": "VARCHAR2(1)",    "not_null": False, "notes": ""},
            {"name": "MARKET",           "type": "VARCHAR2(14)",   "not_null": False, "notes": ""},
            {"name": "LEVY_ACCOUNT",     "type": "VARCHAR2(30)",   "not_null": False, "notes": ""},
            {"name": "FROM_LEVY_DATE",   "type": "DATE",           "not_null": False, "notes": ""},
            {"name": "TO_LEVY_DATE",     "type": "DATE",           "not_null": False, "notes": ""},
            {"name": "LOG_DESCRIPTION",  "type": "VARCHAR2(100)",  "not_null": False, "notes": ""},
            {"name": "LEVY_ENTRY_DATE",  "type": "TIMESTAMP(6)",   "not_null": False, "notes": ""},
            {"name": "ENTRY_USER",       "type": "VARCHAR2(30)",   "not_null": False, "notes": ""},
        ]
    },
    "SETTLEMENT_LEVY_DATA": {
        "grain": "levy_settlement_event",
        "date_key": "TRANSACTION_DATE",
        "notes": "Settlement-stage levy facts; includes CLIENT_ID for client/broker pivots.",
        "columns": [
            {"name": "TRANSACTION_ID",   "type": "NUMBER(14,0)",  "not_null": False, "notes": ""},
            {"name": "TRANSACTION_DATE", "type": "DATE",          "not_null": False, "notes": ""},
            {"name": "TICKET_NO",        "type": "NUMBER(10,0)",  "not_null": False, "notes": ""},
            {"name": "PRICE",            "type": "NUMBER(14,4)",  "not_null": False, "notes": ""},
            {"name": "VOLUME",           "type": "NUMBER(10,0)",  "not_null": False, "notes": ""},
            {"name": "AMOUNT",           "type": "NUMBER(15,4)",  "not_null": False, "notes": ""},
            {"name": "BROKER_ID",        "type": "NUMBER(5,0)",   "not_null": False, "notes": ""},
            {"name": "CLIENT_ID",        "type": "NUMBER(20,0)",  "not_null": False, "notes": ""},
            {"name": "LEVY_AMOUNT",      "type": "NUMBER(14,4)",  "not_null": False, "notes": ""},
            {"name": "LEVY_ID",          "type": "NUMBER(8,0)",   "not_null": False, "notes": ""},
            {"name": "BUY_SELL",         "type": "VARCHAR2(1)",   "not_null": False, "notes": ""},
            {"name": "MARKET",           "type": "VARCHAR2(14)",  "not_null": False, "notes": ""},
            {"name": "LEVY_ACCOUNT",     "type": "VARCHAR2(30)",  "not_null": False, "notes": ""},
            {"name": "LEVY_ENTRY_DATE",  "type": "TIMESTAMP(6)",  "not_null": False, "notes": ""},
            {"name": "ENTRY_USER",       "type": "VARCHAR2(30)",  "not_null": False, "notes": ""},
        ]
    },
    "LEVIES": {
        "grain": "",
        "date_key": "",
        "notes": "",
        "columns": [
            {"name": "LEVY_ID",              "type": "NUMBER(8,0)",   "not_null": True,  "notes": "PK"},
            {"name": "LEVY_CODE",            "type": "VARCHAR2(32)",  "not_null": True,  "notes": ""},
            {"name": "LEVY_NAME",            "type": "VARCHAR2(128)", "not_null": True,  "notes": ""},
            {"name": "EFFECTIVE_FROM",       "type": "DATE",          "not_null": False, "notes": ""},
            {"name": "APPLIES_TO",           "type": "VARCHAR2(4)",   "not_null": False, "notes": ""},
            {"name": "LEVY_TYPE_ID",         "type": "NUMBER(3,0)",   "not_null": True,  "notes": "FK→ATS.LEVY_TYPES(ID)"},
            {"name": "EFFECTIVE_TO",         "type": "DATE",          "not_null": False, "notes": ""},
            {"name": "RECURRENCE_CODE",      "type": "VARCHAR2(25)",  "not_null": True,  "notes": "FK→ATS.LEVY_RECURRENCE(RECURRENCE_CODE)"},
            {"name": "WITH_AGREEMENT",       "type": "VARCHAR2(1)",   "not_null": False, "notes": ""},
            {"name": "LEVY_CATEGORY",        "type": "VARCHAR2(12)",  "not_null": True,  "notes": ""},
            {"name": "OWN_PORTFOLIO",        "type": "VARCHAR2(1)",   "not_null": False, "notes": ""},
            {"name": "MAX_VALUE",            "type": "NUMBER(15,4)",  "not_null": False, "notes": ""},
            {"name": "MIN_VALUE",            "type": "NUMBER(15,4)",  "not_null": False, "notes": ""},
            {"name": "MARKET_ID",            "type": "NUMBER(10,0)",  "not_null": False, "notes": "FK→ATS.MARKETS(MARKET_ID)"},
            {"name": "FOREIGN_CURRENCY_BOND","type": "NUMBER(1,0)",   "not_null": False, "notes": ""},
        ]
    },
    "LEVY_TYPES": {
        "grain": "",
        "date_key": "",
        "notes": "",
        "columns": [
            {"name": "ID",          "type": "NUMBER(3,0)",  "not_null": True,  "notes": "PK"},
            {"name": "CODE",        "type": "VARCHAR2(20)", "not_null": False, "notes": ""},
            {"name": "DESCRIPTION", "type": "VARCHAR2(64)", "not_null": False, "notes": ""},
        ]
    },
    "LEVY_RANGES": {
        "grain": "",
        "date_key": "",
        "notes": "",
        "columns": [
            {"name": "LEVY_RANGE_ID",  "type": "NUMBER(8,0)",   "not_null": True,  "notes": "PK"},
            {"name": "LEVY_ID",        "type": "NUMBER(8,0)",   "not_null": True,  "notes": "FK→ATS.LEVIES(LEVY_ID)"},
            {"name": "RANGE_FROM",     "type": "NUMBER(15,4)",  "not_null": True,  "notes": ""},
            {"name": "RANGE_TO",       "type": "NUMBER(15,4)",  "not_null": True,  "notes": ""},
            {"name": "FIXED_RATE",     "type": "NUMBER(14,4)",  "not_null": False, "notes": ""},
            {"name": "LEVY_CRITERIA",  "type": "NUMBER",        "not_null": True,  "notes": "FK→ATS.LEVY_CRITERIA(ID)"},
            {"name": "VALUE_TYPE",     "type": "VARCHAR2(10)",  "not_null": False, "notes": ""},
            {"name": "MIN_VALUE",      "type": "NUMBER(14,4)",  "not_null": False, "notes": ""},
            {"name": "MAX_VALUE",      "type": "NUMBER(14,4)",  "not_null": False, "notes": ""},
            {"name": "PERCENT_OFF",    "type": "NUMBER(20,0)",  "not_null": False, "notes": "FK→ATS.LEVY_PERCENT_OFF(ID)"},
            {"name": "PERCENT",        "type": "NUMBER(7,4)",   "not_null": False, "notes": ""},
        ]
    },
    "LEVY_CRITERIA": {
        "grain": "",
        "date_key": "",
        "notes": "",
        "columns": [
            {"name": "ID",            "type": "NUMBER",        "not_null": True,  "notes": "PK"},
            {"name": "CRITERIA_CODE", "type": "VARCHAR2(20)",  "not_null": True,  "notes": ""},
            {"name": "DESCREPTION",   "type": "VARCHAR2(25)",  "not_null": False, "notes": "Typo in schema card (DESCREPTION)"},
        ]
    },
    "LEVY_INFO": {
        "grain": "",
        "date_key": "",
        "notes": "",
        "columns": [
            {"name": "LEVY_ID",     "type": "NUMBER(8,0)",  "not_null": True,  "notes": "PK, FK→ATS.LEVIES(LEVY_ID)"},
            {"name": "VALUE_TYPE",  "type": "VARCHAR2(10)", "not_null": True,  "notes": ""},
            {"name": "VALUE",       "type": "NUMBER(14,4)", "not_null": True,  "notes": ""},
            {"name": "MIN_VALUE",   "type": "NUMBER(14,4)", "not_null": False, "notes": ""},
            {"name": "MAX_VALUE",   "type": "NUMBER(14,4)", "not_null": False, "notes": ""},
            {"name": "PERCENT_OFF", "type": "NUMBER",       "not_null": False, "notes": "FK→ATS.LEVY_PERCENT_OFF(ID)"},
        ]
    },
    "LEVY_MEMBER_TYPES": {
        "grain": "",
        "date_key": "",
        "notes": "",
        "columns": [
            {"name": "ID",             "type": "NUMBER(5,0)", "not_null": False, "notes": ""},
            {"name": "MEMBER_TYPE_ID", "type": "NUMBER(5,0)", "not_null": False, "notes": "FK→ATS.BROKER_TYPES(BROKER_TYPE_ID)"},
            {"name": "LEVY_ID",        "type": "NUMBER(5,0)", "not_null": False, "notes": "FK→ATS.LEVIES(LEVY_ID)"},
            {"name": "ACTIVE",         "type": "NUMBER(1,0)", "not_null": False, "notes": ""},
        ]
    },
    "LEVY_SECURITIES": {
        "grain": "",
        "date_key": "",
        "notes": "",
        "columns": [
            {"name": "LEVY_ID",          "type": "NUMBER(10,0)", "not_null": False, "notes": "FK→ATS.LEVIES(LEVY_ID)"},
            {"name": "BOND_TYPE_ID",     "type": "NUMBER(10,0)", "not_null": False, "notes": ""},
            {"name": "BOND_CATEGORY_ID", "type": "NUMBER(10,0)", "not_null": False, "notes": "FK→ATS.BOND_CATEGORY(ID)"},
            {"name": "ID",               "type": "NUMBER(10,0)", "not_null": False, "notes": ""},
        ]
    },
    "REPO_CONTRACTS": {
        "grain": "repo_leg",
        "date_key": "ENTRY_DATETIME",
        "notes": "LEG pairs mirrored rows (1=initial, 2=repurchase). Note: NEW_CONTARCT_ID is a known typo in schema card.",
        "columns": [
            {"name": "ENTRY_DATETIME",               "type": "TIMESTAMP(6)",  "not_null": False, "notes": ""},
            {"name": "CONTRACT_NO",                  "type": "VARCHAR2(25)",  "not_null": False, "notes": ""},
            {"name": "SELLER_ORDER_NO",              "type": "NUMBER(10,0)",  "not_null": False, "notes": ""},
            {"name": "BUYER_ORDER_NO",               "type": "NUMBER(10,0)",  "not_null": False, "notes": ""},
            {"name": "PRICE",                        "type": "NUMBER(16,4)",  "not_null": False, "notes": ""},
            {"name": "VOLUME",                       "type": "NUMBER(10,0)",  "not_null": False, "notes": ""},
            {"name": "EXCHANGE_ID",                  "type": "NUMBER(4,0)",   "not_null": False, "notes": ""},
            {"name": "BUYER_CLIENT_ID",              "type": "NUMBER(20,0)",  "not_null": False, "notes": ""},
            {"name": "SELLER_CLIENT_ID",             "type": "NUMBER(20,0)",  "not_null": False, "notes": ""},
            {"name": "SYMBOL_ID",                    "type": "NUMBER(15,0)",  "not_null": False, "notes": ""},
            {"name": "MARKET_ID",                    "type": "NUMBER(4,0)",   "not_null": False, "notes": ""},
            {"name": "BUYER_BROKER_ID",              "type": "NUMBER(5,0)",   "not_null": False, "notes": ""},
            {"name": "SELLER_BROKER_ID",             "type": "NUMBER(5,0)",   "not_null": False, "notes": ""},
            {"name": "BUYER_USER_ID",                "type": "NUMBER(30,0)",  "not_null": False, "notes": ""},
            {"name": "SELLER_USER_ID",               "type": "NUMBER(30,0)",  "not_null": False, "notes": ""},
            {"name": "TRADE_TYPE",                   "type": "NUMBER(1,0)",   "not_null": False, "notes": ""},
            {"name": "STATE_ID",                     "type": "NUMBER(2,0)",   "not_null": False, "notes": ""},
            {"name": "BUYER_REMAINING_VOLUME",       "type": "NUMBER(10,0)",  "not_null": False, "notes": ""},
            {"name": "SELLER_REMAINING_VOLUME",      "type": "NUMBER(10,0)",  "not_null": False, "notes": ""},
            {"name": "BUYER_CUSTODIAN_ID",           "type": "NUMBER(20,0)",  "not_null": False, "notes": ""},
            {"name": "SELLER_CUSTODIAN_ID",          "type": "NUMBER(20,0)",  "not_null": False, "notes": ""},
            {"name": "ACCRUED_PROFIT",               "type": "NUMBER(16,4)",  "not_null": False, "notes": ""},
            {"name": "YIELD",                        "type": "NUMBER(15,4)",  "not_null": False, "notes": ""},
            {"name": "VALUE",                        "type": "NUMBER(20,4)",  "not_null": False, "notes": ""},
            {"name": "PRICING_MECHANISM",            "type": "NUMBER(1,0)",   "not_null": False, "notes": ""},
            {"name": "PRICING_MODEL",                "type": "NUMBER(1,0)",   "not_null": False, "notes": ""},
            {"name": "SETTLEMENT_TYPE_ID",           "type": "NUMBER(4,0)",   "not_null": False, "notes": ""},
            {"name": "SETTLEMENT_AMOUNT",            "type": "NUMBER(20,4)",  "not_null": False, "notes": ""},
            {"name": "LEG",                          "type": "NUMBER(1,0)",   "not_null": False, "notes": ""},
            {"name": "TERMINATION_DATE",             "type": "DATE",          "not_null": False, "notes": ""},
            {"name": "REPURCHASE_PRICE",             "type": "NUMBER(16,4)",  "not_null": False, "notes": ""},
            {"name": "TICKET_NO",                    "type": "NUMBER(10,0)",  "not_null": False, "notes": ""},
            {"name": "INITIAL_DATE",                 "type": "DATE",          "not_null": False, "notes": ""},
            {"name": "TRADE_STATE",                  "type": "VARCHAR2(32)",  "not_null": False, "notes": ""},
            {"name": "IS_PROCESSED",                 "type": "VARCHAR2(1)",   "not_null": False, "notes": ""},
            {"name": "DIRTY_PRICE",                  "type": "NUMBER(16,4)",  "not_null": False, "notes": ""},
            {"name": "REPO_TYPE",                    "type": "VARCHAR2(16)",  "not_null": False, "notes": ""},
            {"name": "REPURCHASE_ACCRUED_PROFIT",    "type": "NUMBER(16,4)",  "not_null": False, "notes": ""},
            {"name": "REPURCHASE_SETTLEMENT_AMOUNT", "type": "NUMBER(20,4)",  "not_null": False, "notes": ""},
            {"name": "REPO_HAIRCUT",                 "type": "NUMBER(8,4)",   "not_null": False, "notes": ""},
            {"name": "REPURCHASE_DIRTY_PRICE",       "type": "NUMBER(16,4)",  "not_null": False, "notes": ""},
            {"name": "REPO_RATE",                    "type": "NUMBER(16,4)",  "not_null": False, "notes": ""},
            {"name": "PREVIOUS_CONTRACT_NO",         "type": "VARCHAR2(25)",  "not_null": False, "notes": ""},
            {"name": "NEW_CONTRACT_ID",              "type": "VARCHAR2(25)",  "not_null": False, "notes": ""},
            {"name": "CONTRACT_MODIFY_DATE",         "type": "DATE",          "not_null": False, "notes": ""},
            {"name": "PREVIOUS_REPURCHASE_AMOUNT",   "type": "NUMBER(20,4)",  "not_null": False, "notes": ""},
            {"name": "PAR_VALUE",                    "type": "NUMBER(16,4)",  "not_null": False, "notes": ""},
            {"name": "MARKET_VALUE",                 "type": "NUMBER(20,4)",  "not_null": False, "notes": ""},
            {"name": "ACCRUED_DAYS",                 "type": "NUMBER",        "not_null": False, "notes": ""},
            {"name": "NEW_CONTARCT_ID",              "type": "VARCHAR2(25)",  "not_null": False, "notes": "Typo in schema card (CONTARCT)"},
        ]
    },
    "REPO_CONTRACTS_CANCELLED": {
        "grain": "repo_cancel_leg",
        "date_key": "ENTRY_DATETIME",
        "notes": "Structurally mirrors REPO_CONTRACTS; only voided legs.",
        "columns": [
            {"name": "ENTRY_DATETIME",               "type": "TIMESTAMP(6)",  "not_null": False, "notes": ""},
            {"name": "TRADE_DATETIME",               "type": "TIMESTAMP(6)",  "not_null": False, "notes": ""},
            {"name": "CONTRACT_NO",                  "type": "VARCHAR2(25)",  "not_null": False, "notes": ""},
            {"name": "SELLER_ORDER_NO",              "type": "NUMBER(10,0)",  "not_null": False, "notes": ""},
            {"name": "BUYER_ORDER_NO",               "type": "NUMBER(10,0)",  "not_null": False, "notes": ""},
            {"name": "PRICE",                        "type": "NUMBER(14,4)",  "not_null": False, "notes": ""},
            {"name": "VOLUME",                       "type": "NUMBER(10,0)",  "not_null": False, "notes": ""},
            {"name": "EXCHANGE_ID",                  "type": "NUMBER(4,0)",   "not_null": False, "notes": ""},
            {"name": "BUYER_CLIENT_ID",              "type": "NUMBER(20,0)",  "not_null": False, "notes": ""},
            {"name": "SELLER_CLIENT_ID",             "type": "NUMBER(20,0)",  "not_null": False, "notes": ""},
            {"name": "SYMBOL_ID",                    "type": "NUMBER(15,0)",  "not_null": False, "notes": ""},
            {"name": "MARKET_ID",                    "type": "NUMBER(4,0)",   "not_null": False, "notes": ""},
            {"name": "BUYER_BROKER_ID",              "type": "NUMBER(5,0)",   "not_null": False, "notes": ""},
            {"name": "SELLER_BROKER_ID",             "type": "NUMBER(5,0)",   "not_null": False, "notes": ""},
            {"name": "BUYER_USER_ID",                "type": "NUMBER(30,0)",  "not_null": False, "notes": ""},
            {"name": "SELLER_USER_ID",               "type": "NUMBER(30,0)",  "not_null": False, "notes": ""},
            {"name": "TRADE_TYPE",                   "type": "NUMBER(1,0)",   "not_null": False, "notes": ""},
            {"name": "STATE_ID",                     "type": "NUMBER(2,0)",   "not_null": False, "notes": ""},
            {"name": "BUYER_REMAINING_VOLUME",       "type": "NUMBER(10,0)",  "not_null": False, "notes": ""},
            {"name": "SELLER_REMAINING_VOLUME",      "type": "NUMBER(10,0)",  "not_null": False, "notes": ""},
            {"name": "BUYER_CUSTODIAN_ID",           "type": "NUMBER(20,0)",  "not_null": False, "notes": ""},
            {"name": "SELLER_CUSTODIAN_ID",          "type": "NUMBER(20,0)",  "not_null": False, "notes": ""},
            {"name": "ACCRUED_PROFIT",               "type": "NUMBER(16,4)",  "not_null": False, "notes": ""},
            {"name": "YIELD",                        "type": "NUMBER(15,4)",  "not_null": False, "notes": ""},
            {"name": "VALUE",                        "type": "NUMBER(15,4)",  "not_null": False, "notes": ""},
            {"name": "PRICING_MECHANISM",            "type": "NUMBER(1,0)",   "not_null": False, "notes": ""},
            {"name": "PRICING_MODEL",                "type": "NUMBER(1,0)",   "not_null": False, "notes": ""},
            {"name": "SETTLEMENT_TYPE_ID",           "type": "NUMBER(4,0)",   "not_null": False, "notes": ""},
            {"name": "SETTLEMENT_AMOUNT",            "type": "NUMBER(20,4)",  "not_null": False, "notes": ""},
            {"name": "LEG",                          "type": "NUMBER(1,0)",   "not_null": False, "notes": ""},
            {"name": "TERMINATION_DATE",             "type": "DATE",          "not_null": False, "notes": ""},
            {"name": "REPURCHASE_PRICE",             "type": "NUMBER(14,4)",  "not_null": False, "notes": ""},
            {"name": "TICKET_NO",                    "type": "NUMBER(10,0)",  "not_null": False, "notes": ""},
            {"name": "INITIAL_DATE",                 "type": "DATE",          "not_null": False, "notes": ""},
            {"name": "TRADE_STATE",                  "type": "VARCHAR2(32)",  "not_null": False, "notes": ""},
            {"name": "IS_PROCESSED",                 "type": "VARCHAR2(1)",   "not_null": False, "notes": ""},
            {"name": "REPO_RATE",                    "type": "NUMBER(8,4)",   "not_null": False, "notes": ""},
            {"name": "DIRTY_PRICE",                  "type": "NUMBER(14,4)",  "not_null": False, "notes": ""},
            {"name": "REPO_TYPE",                    "type": "VARCHAR2(16)",  "not_null": False, "notes": ""},
            {"name": "REPURCHASE_ACCRUED_PROFIT",    "type": "NUMBER(15,4)",  "not_null": False, "notes": ""},
            {"name": "REPURCHASE_SETTLEMENT_AMOUNT", "type": "NUMBER(20,4)",  "not_null": False, "notes": ""},
            {"name": "REPO_HAIRCUT",                 "type": "NUMBER(8,4)",   "not_null": False, "notes": ""},
            {"name": "REPURCHASE_DIRTY_PRICE",       "type": "NUMBER(14,4)",  "not_null": False, "notes": ""},
            {"name": "PREVIOUS_CONTRACT_NO",         "type": "VARCHAR2(25)",  "not_null": False, "notes": ""},
            {"name": "NEW_CONTRACT_ID",              "type": "VARCHAR2(25)",  "not_null": False, "notes": ""},
            {"name": "CONTRACT_MODIFY_DATE",         "type": "DATE",          "not_null": False, "notes": ""},
            {"name": "PREVIOUS_REPURCHASE_AMOUNT",   "type": "NUMBER(20,4)",  "not_null": False, "notes": ""},
            {"name": "PAR_VALUE",                    "type": "NUMBER(16,4)",  "not_null": False, "notes": ""},
            {"name": "MARKET_VALUE",                 "type": "NUMBER(20,4)",  "not_null": False, "notes": ""},
            {"name": "ACCRUED_DAYS",                 "type": "NUMBER",        "not_null": False, "notes": ""},
        ]
    },
    "REPO_LOG": {
        "grain": "repo_log_event",
        "date_key": "ENTRY_DATETIME",
        "notes": "Soft-join to REPO_CONTRACTS via CONTRACT_ID = CONTRACT_NO.",
        "columns": [
            {"name": "ENTRY_DATETIME",               "type": "TIMESTAMP(6)",  "not_null": False, "notes": ""},
            {"name": "ORDER_NO",                     "type": "NUMBER(10,0)",  "not_null": False, "notes": ""},
            {"name": "VOLUME",                       "type": "NUMBER(10,0)",  "not_null": False, "notes": ""},
            {"name": "PRICE",                        "type": "NUMBER(16,4)",  "not_null": False, "notes": ""},
            {"name": "SIDE",                         "type": "NVARCHAR2(1)",  "not_null": False, "notes": ""},
            {"name": "CONTRACT_ID",                  "type": "VARCHAR2(20)",  "not_null": False, "notes": ""},
            {"name": "CLIENT_ID",                    "type": "NUMBER(20,0)",  "not_null": False, "notes": ""},
            {"name": "SYMBOL_ID",                    "type": "NUMBER(15,0)",  "not_null": False, "notes": ""},
            {"name": "MARKET_ID",                    "type": "NUMBER(4,0)",   "not_null": False, "notes": ""},
            {"name": "EXCHANGE_ID",                  "type": "NUMBER(4,0)",   "not_null": False, "notes": ""},
            {"name": "BROKER_ID",                    "type": "NUMBER(5,0)",   "not_null": False, "notes": ""},
            {"name": "USER_ID",                      "type": "NUMBER(30,0)",  "not_null": False, "notes": ""},
            {"name": "PRIVATE_ORDER_STATE",          "type": "NUMBER(2,0)",   "not_null": False, "notes": ""},
            {"name": "TRADER_ID",                    "type": "NUMBER(30,0)",  "not_null": False, "notes": ""},
            {"name": "ORDER_TYPE",                   "type": "NUMBER(1,0)",   "not_null": False, "notes": ""},
            {"name": "COUNTER_ORDER_NO",             "type": "NUMBER(10,0)",  "not_null": False, "notes": ""},
            {"name": "COUNTER_USER_ID",              "type": "NUMBER(30,0)",  "not_null": False, "notes": ""},
            {"name": "COUNTER_CLIENT_ID",            "type": "NUMBER(20,0)",  "not_null": False, "notes": ""},
            {"name": "COUNTER_BROKER_ID",            "type": "NUMBER(5,0)",   "not_null": False, "notes": ""},
            {"name": "NEGOTIATED_STATE",             "type": "NUMBER(1,0)",   "not_null": False, "notes": ""},
            {"name": "CUSTODIAN_ID",                 "type": "NUMBER(20,0)",  "not_null": False, "notes": ""},
            {"name": "COUNTER_CUSTODIAN_ID",         "type": "NUMBER(20,0)",  "not_null": False, "notes": ""},
            {"name": "YIELD",                        "type": "NUMBER(15,4)",  "not_null": False, "notes": ""},
            {"name": "ACCRUED_PROFIT",               "type": "NUMBER(16,4)",  "not_null": False, "notes": ""},
            {"name": "VALUE",                        "type": "NUMBER(20,4)",  "not_null": False, "notes": ""},
            {"name": "PRICING_MECHANISM",            "type": "NUMBER(1,0)",   "not_null": False, "notes": ""},
            {"name": "SETTLEMENT_TYPE_ID",           "type": "NUMBER(4,0)",   "not_null": False, "notes": ""},
            {"name": "LEG",                          "type": "NUMBER(1,0)",   "not_null": False, "notes": ""},
            {"name": "TERMINATION_DATE",             "type": "DATE",          "not_null": False, "notes": ""},
            {"name": "REPURCHASE_PRICE",             "type": "NUMBER(16,4)",  "not_null": False, "notes": ""},
            {"name": "PREVIOUS_REP_PRICE",           "type": "NUMBER(16,4)",  "not_null": False, "notes": ""},
            {"name": "REF_NO",                       "type": "VARCHAR2(12)",  "not_null": False, "notes": ""},
            {"name": "INITIATOR",                    "type": "NUMBER(1,0)",   "not_null": False, "notes": ""},
            {"name": "INITIAL_DATE",                 "type": "DATE",          "not_null": False, "notes": ""},
            {"name": "PUBLIC_ORDER_STATE",           "type": "NUMBER(2,0)",   "not_null": False, "notes": ""},
            {"name": "NEGOTIATED_STATUS",            "type": "NUMBER(1,0)",   "not_null": False, "notes": ""},
            {"name": "REPO_RATE",                    "type": "NUMBER(8,4)",   "not_null": False, "notes": ""},
            {"name": "SETTLEMENT_AMOUNT",            "type": "NUMBER(20,4)",  "not_null": False, "notes": ""},
            {"name": "DIRTY_PRICE",                  "type": "NUMBER(16,4)",  "not_null": False, "notes": ""},
            {"name": "REPO_TYPE",                    "type": "VARCHAR2(16)",  "not_null": False, "notes": ""},
            {"name": "REPURCHASE_ACCRUED_PROFIT",    "type": "NUMBER(16,4)",  "not_null": False, "notes": ""},
            {"name": "REPURCHASE_SETTLEMENT_AMOUNT", "type": "NUMBER(20,4)",  "not_null": False, "notes": ""},
            {"name": "REPO_HAIRCUT",                 "type": "NUMBER(8,4)",   "not_null": False, "notes": ""},
            {"name": "REPURCHASE_DIRTY_PRICE",       "type": "NUMBER(16,4)",  "not_null": False, "notes": ""},
            {"name": "NEW_CONTRACT_ID",              "type": "VARCHAR2(25)",  "not_null": False, "notes": ""},
            {"name": "CONTRACT_MODIFY_DATE",         "type": "DATE",          "not_null": False, "notes": ""},
            {"name": "PREVIOUS_REPURCHASE_AMOUNT",   "type": "NUMBER(20,4)",  "not_null": False, "notes": ""},
            {"name": "PAR_VALUE",                    "type": "NUMBER(16,4)",  "not_null": False, "notes": ""},
            {"name": "MARKET_VALUE",                 "type": "NUMBER(20,4)",  "not_null": False, "notes": ""},
            {"name": "ACCRUED_DAYS",                 "type": "NUMBER",        "not_null": False, "notes": ""},
            {"name": "FIX_REF_NO",                   "type": "VARCHAR2(20)",  "not_null": False, "notes": ""},
            {"name": "ORIGINATOR",                   "type": "NUMBER(1,0)",   "not_null": False, "notes": ""},
            {"name": "FIX_SESSION",                  "type": "VARCHAR2(200)", "not_null": False, "notes": ""},
        ]
    },
}

# ---------------------------------------------------------------------------
# Helpers: build the Oracle type string from ALL_TAB_COLUMNS row
# ---------------------------------------------------------------------------

def oracle_type_str(row: dict) -> str:
    """
    Reconstruct a human-readable Oracle type string from ALL_TAB_COLUMNS fields.
    Mirrors what is written in the schema card as closely as possible.
    """
    data_type = (row.get("DATA_TYPE") or "").upper().strip()

    # TIMESTAMP
    if data_type == "TIMESTAMP(6) WITH TIME ZONE":
        return "TIMESTAMP(6) WITH TIME ZONE"
    if data_type.startswith("TIMESTAMP"):
        scale = row.get("DATA_SCALE")
        if scale is not None:
            return f"TIMESTAMP({int(scale)})"
        # Oracle stores fractional-seconds precision in DATA_SCALE for TIMESTAMP
        return "TIMESTAMP"

    # NUMBER
    if data_type == "NUMBER":
        prec  = row.get("DATA_PRECISION")
        scale = row.get("DATA_SCALE")
        if prec is not None and scale is not None:
            return f"NUMBER({int(prec)},{int(scale)})"
        if prec is not None:
            return f"NUMBER({int(prec)})"
        return "NUMBER"

    # FLOAT
    if data_type == "FLOAT":
        prec = row.get("DATA_PRECISION")
        if prec is not None:
            return f"FLOAT({int(prec)})"
        return "FLOAT"

    # Char types – use DATA_LENGTH
    char_types = ("VARCHAR2", "NVARCHAR2", "CHAR", "NCHAR")
    for ct in char_types:
        if data_type == ct:
            length = row.get("DATA_LENGTH") or row.get("CHAR_LENGTH")
            if length is not None:
                return f"{ct}({int(length)})"
            return ct

    # DATE, CLOB, BLOB, XMLTYPE, etc.
    return data_type


def nullable_str(nullable_flag: str) -> str:
    """Convert Oracle Y/N to human-readable."""
    return "NOT NULL" if (nullable_flag or "Y").upper() == "N" else "NULL"


# ---------------------------------------------------------------------------
# Oracle DB queries
# ---------------------------------------------------------------------------

def get_connection(dsn: str, user: str, password: str):
    """Try oracledb first, fall back to cx_Oracle."""
    try:
        import oracledb                   # preferred – thin client, no Oracle libs needed
        oracledb.init_oracle_client()     # thick mode (optional; remove if thin is OK)
        conn = oracledb.connect(user=user, password=password, dsn=dsn)
        print("  [DB] Connected via oracledb (thick mode)")
        return conn
    except Exception:
        pass

    try:
        import oracledb
        conn = oracledb.connect(user=user, password=password, dsn=dsn)
        print("  [DB] Connected via oracledb (thin mode)")
        return conn
    except Exception as e_thin:
        print(f"  [WARN] oracledb failed ({e_thin}). Trying cx_Oracle...")

    try:
        import cx_Oracle                  # fallback – requires Oracle Client libraries
        conn = cx_Oracle.connect(user, password, dsn)
        print("  [DB] Connected via cx_Oracle")
        return conn
    except Exception as e_cx:
        raise RuntimeError(
            f"Cannot connect to Oracle.\n"
            f"  oracledb error : {e_thin}\n"
            f"  cx_Oracle error: {e_cx}"
        )


def fetch_all_dict(cursor, query: str, params=None) -> list:
    """Execute query and return list of dicts (column name → value)."""
    cursor.execute(query, params or [])
    cols = [d[0].upper() for d in cursor.description]
    return [dict(zip(cols, row)) for row in cursor.fetchall()]


def query_live_schema(conn, owner: str) -> tuple:
    """
    Returns:
        live_tables  : set of table names (upper-case) that exist in the owner
        live_columns : dict  table_name → { col_name: row_dict }
    """
    owner_upper = owner.upper()
    cur = conn.cursor()

    print(f"  [DB] Fetching table list for owner={owner_upper} ...")
    tables_rows = fetch_all_dict(
        cur,
        "SELECT TABLE_NAME FROM ALL_TABLES WHERE OWNER = :1 ORDER BY TABLE_NAME",
        [owner_upper]
    )
    live_tables = {r["TABLE_NAME"] for r in tables_rows}
    print(f"  [DB] Found {len(live_tables)} tables.")

    print("  [DB] Fetching column details ...")
    col_rows = fetch_all_dict(
        cur,
        """
        SELECT
            TABLE_NAME,
            COLUMN_NAME,
            DATA_TYPE,
            DATA_LENGTH,
            CHAR_LENGTH,
            DATA_PRECISION,
            DATA_SCALE,
            NULLABLE,
            COLUMN_ID
        FROM ALL_TAB_COLUMNS
        WHERE OWNER = :1
        ORDER BY TABLE_NAME, COLUMN_ID
        """,
        [owner_upper]
    )

    live_columns: dict = {}
    for r in col_rows:
        tbl = r["TABLE_NAME"]
        col = r["COLUMN_NAME"].upper()
        live_columns.setdefault(tbl, {})[col] = r

    print(f"  [DB] Fetched columns for {len(live_columns)} tables.")
    cur.close()
    return live_tables, live_columns


# ---------------------------------------------------------------------------
# Comparison logic
# ---------------------------------------------------------------------------

def compare_type(card_type: str, live_type_str: str) -> bool:
    """
    Case-insensitive type comparison.
    Normalise minor formatting differences (spaces around commas, etc.).
    """
    def normalise(s: str) -> str:
        return s.upper().replace(" ", "").replace(",0)", ")").replace("(0)", "")

    return normalise(card_type) == normalise(live_type_str)


def compare_table(table_name: str, card_meta: dict, live_cols: dict) -> dict:
    """
    Compare one table.  Returns a result dict:
      status          : 'MATCHED' | 'CHANGED' | 'MISSING'
      col_results     : list of per-column dicts
      new_cols        : list of column names only in live DB
      removed_cols    : list of column names only in schema card
      changed_cols    : count of columns with differences
    """
    card_columns = card_meta["columns"]
    card_col_map = {c["name"].upper(): c for c in card_columns}
    live_col_map_upper = {k.upper(): v for k, v in live_cols.items()}

    col_results   = []
    new_cols      = []
    removed_cols  = []
    changed_count = 0

    # (a) Check every card column
    for card_col in card_columns:
        cname = card_col["name"].upper()
        if cname not in live_col_map_upper:
            removed_cols.append(card_col["name"])
            col_results.append({
                "column":      card_col["name"],
                "card_type":   card_col["type"],
                "live_type":   "—",
                "card_null":   "NOT NULL" if card_col["not_null"] else "NULL",
                "live_null":   "—",
                "status":      "❌ REMOVED",
                "diff_notes":  "Column missing from live DB",
            })
            continue

        live_row   = live_col_map_upper[cname]
        live_type  = oracle_type_str(live_row)
        live_null  = nullable_str(live_row.get("NULLABLE", "Y"))
        card_null  = "NOT NULL" if card_col["not_null"] else "NULL"

        diffs = []
        if not compare_type(card_col["type"], live_type):
            diffs.append(f"Type: `{card_col['type']}` → `{live_type}`")
        if card_col["not_null"] and live_null != "NOT NULL":
            diffs.append(f"Nullable: `NOT NULL` → `NULL`")
        elif not card_col["not_null"] and live_null == "NOT NULL":
            diffs.append(f"Nullable: `NULL` → `NOT NULL`")

        if diffs:
            changed_count += 1
            col_results.append({
                "column":     card_col["name"],
                "card_type":  card_col["type"],
                "live_type":  live_type,
                "card_null":  card_null,
                "live_null":  live_null,
                "status":     "⚠️ CHANGED",
                "diff_notes": "; ".join(diffs),
            })
        else:
            col_results.append({
                "column":     card_col["name"],
                "card_type":  card_col["type"],
                "live_type":  live_type,
                "card_null":  card_null,
                "live_null":  live_null,
                "status":     "✅ OK",
                "diff_notes": card_col.get("notes", ""),
            })

    # (b) Extra columns in live DB not in schema card
    card_names_upper = {c["name"].upper() for c in card_columns}
    for live_col_name_upper, live_row in live_col_map_upper.items():
        if live_col_name_upper not in card_names_upper:
            new_cols.append(live_row["COLUMN_NAME"])
            col_results.append({
                "column":     live_row["COLUMN_NAME"],
                "card_type":  "—",
                "live_type":  oracle_type_str(live_row),
                "card_null":  "—",
                "live_null":  nullable_str(live_row.get("NULLABLE", "Y")),
                "status":     "🆕 NEW COL",
                "diff_notes": "Column exists in live DB but not in schema card",
            })

    if removed_cols or changed_count > 0 or new_cols:
        status = "CHANGED"
    else:
        status = "MATCHED"

    return {
        "status":        status,
        "col_results":   col_results,
        "new_cols":      new_cols,
        "removed_cols":  removed_cols,
        "changed_count": changed_count,
    }


# ---------------------------------------------------------------------------
# Markdown report generation
# ---------------------------------------------------------------------------

MD_TABLE_HEADER = (
    "| Column | Schema Card Type | Live DB Type | "
    "Card Nullable | Live Nullable | Status | Notes |\n"
    "|--------|-----------------|-------------|"
    "--------------|--------------|--------|-------|\n"
)


def escape_md(s: str) -> str:
    """Escape pipe characters inside Markdown table cells."""
    return str(s).replace("|", "\\|")


def build_report(
    owner: str,
    dsn: str,
    card_tables: list,
    live_tables: set,
    live_columns: dict,
    comparison_results: dict,
    generated_at: str,
) -> str:
    lines = []

    # ── Header ──────────────────────────────────────────────────────────────
    lines.append(f"# ATS Schema Comparison Report\n")
    lines.append(f"**Generated on:** {generated_at}  ")
    lines.append(f"**Database:** {owner}@{dsn}  ")
    lines.append(f"**Schema Card Version:** schema_card.md (ATS owner, 33 tables)\n")

    # ── Summary ─────────────────────────────────────────────────────────────
    total_card  = len(card_tables)
    missing_tbl = [t for t in card_tables if t not in live_tables]
    present_tbl = [t for t in card_tables if t in live_tables]

    total_changed  = sum(r["changed_count"] for r in comparison_results.values())
    total_new_cols = sum(len(r["new_cols"])  for r in comparison_results.values())
    total_removed  = sum(len(r["removed_cols"]) for r in comparison_results.values())

    extra_in_live = sorted(live_tables - set(card_tables))

    lines.append("## Summary\n")
    lines.append(f"- **Total tables in Schema Card:** {total_card}")
    lines.append(f"- **Tables present in DB:** {len(present_tbl)}")
    lines.append(f"- **Tables missing from DB:** {len(missing_tbl)}")
    lines.append(f"- **Columns changed (type or nullability):** {total_changed}")
    lines.append(f"- **New columns (in DB, not in card):** {total_new_cols}")
    lines.append(f"- **Removed columns (in card, not in DB):** {total_removed}")
    lines.append(f"- **Extra tables in live DB (not in card):** {len(extra_in_live)}\n")

    # ── Detailed comparison per table ────────────────────────────────────────
    lines.append("---\n")
    lines.append("## Detailed Comparison by Table\n")

    for tbl in sorted(card_tables):
        meta = SCHEMA_CARD[tbl]
        lines.append(f"### {owner}.{tbl}\n")

        if tbl not in live_tables:
            lines.append("**Status:** ❌ MISSING TABLE – not found in live DB\n")
            if meta.get("grain"):
                lines.append(f"**Grain (from card):** {meta['grain']}  ")
            if meta.get("date_key"):
                lines.append(f"**Date Key:** {meta['date_key']}  ")
            lines.append("")
            continue

        res = comparison_results[tbl]
        status_icon = "✅ Matched" if res["status"] == "MATCHED" else "⚠️ Changed"
        lines.append(f"**Status:** {status_icon}  ")
        if meta.get("grain"):
            lines.append(f"**Grain (from card):** {meta['grain']}  ")
        if meta.get("date_key"):
            lines.append(f"**Date Key:** {meta['date_key']}  ")
        if res["new_cols"]:
            lines.append(f"**New columns (live DB only):** {', '.join(res['new_cols'])}  ")
        if res["removed_cols"]:
            lines.append(f"**Removed columns (card only):** {', '.join(res['removed_cols'])}  ")
        lines.append("")

        # Column table
        lines.append(MD_TABLE_HEADER.rstrip("\n"))
        for cr in res["col_results"]:
            row = (
                f"| {escape_md(cr['column'])} "
                f"| {escape_md(cr['card_type'])} "
                f"| {escape_md(cr['live_type'])} "
                f"| {escape_md(cr['card_null'])} "
                f"| {escape_md(cr['live_null'])} "
                f"| {escape_md(cr['status'])} "
                f"| {escape_md(cr['diff_notes'])} |"
            )
            lines.append(row)
        lines.append("")

    # ── Extra tables in live DB ───────────────────────────────────────────────
    lines.append("---\n")
    lines.append("## Tables Only in Live DB (not in Schema Card)\n")
    if extra_in_live:
        for t in extra_in_live:
            lines.append(f"- `{owner}.{t}`")
    else:
        lines.append("_None found._")
    lines.append("")

    # ── Tables only in schema card ────────────────────────────────────────────
    lines.append("## Tables Only in Schema Card (missing from Live DB)\n")
    if missing_tbl:
        for t in sorted(missing_tbl):
            lines.append(f"- `{owner}.{t}`")
    else:
        lines.append("_None – all schema card tables present in DB._")
    lines.append("")

    # ── Critical guardrails ───────────────────────────────────────────────────
    lines.append("---\n")
    lines.append("## Critical Guardrails and Notes from Schema Card\n")
    lines.append(
        "1. **No `ORDER_NO` on TRADES** – Do NOT use `TRADES.ORDER_NO` (does not exist). "
        "Link orders via `TRADES.BUYER_ORDER_NO` / `TRADES.SELLER_ORDER_NO` → `ORDERS.ORDER_NO`.\n"
    )
    lines.append(
        "2. **TRADES profit** – For broker/client profit questions use `SUM(ACCRUED_PROFIT)`, "
        "NOT `SUM(VALUE)` or notional.\n"
    )
    lines.append(
        "3. **Output guardrail** – Final user-facing outputs must be business-friendly: "
        "use labels/names over IDs "
        "(e.g. `EDS_CLIENTS.NAME`, `SUBSCRIBED_BROKERS.BROKER_NAME`, `SYMBOLS.SYMBOL`, "
        "`EXCHANGES.EXCHANGE_NAME`, `ORDER_STATES.STATE_CODE`, `TRADE_STATES.STATE_CODE`, "
        "`SETTLEMENT_TYPES.SETTLEMENT_TYPE`).\n"
    )
    lines.append(
        "4. **REPO_CONTRACTS leg pairing** – `LEG=1` is the initial leg, `LEG=2` is repurchase. "
        "Use `INITIAL_DATE` / `TERMINATION_DATE` for active-contract filters.\n"
    )
    lines.append(
        "5. **NEGOTIATED_TRADES party columns** – Uses `CLIENT_ID` / `COUNTER_CLIENT_ID`, "
        "NOT `BUYER_*` / `SELLER_*`.\n"
    )
    lines.append(
        "6. **SETTLEMENT_LEVY_DATA date grain** – `TRANSACTION_DATE` is the primary date key "
        "for levy amount queries.\n"
    )
    lines.append(
        "7. **Typo in schema card** – `REPO_CONTRACTS.NEW_CONTARCT_ID` is a known typo "
        "(should be `NEW_CONTRACT_ID`); both column names may exist in the live DB.\n"
    )
    lines.append(
        "8. **ANSI joins only** – Use standard `JOIN ... ON ...` syntax; "
        "never use Oracle legacy `(+)` join syntax.\n"
    )

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="ATS Oracle Schema Comparison Tool"
    )
    parser.add_argument("--dsn",      default=DEFAULT_DSN,      help="Oracle DSN (host:port/service)")
    parser.add_argument("--user",     default=DEFAULT_USER,     help="Oracle username")
    parser.add_argument("--password", default=DEFAULT_PASSWORD, help="Oracle password")
    parser.add_argument("--owner",    default=DEFAULT_OWNER,    help="Oracle schema owner (default: ATS)")
    parser.add_argument("--output",   default="ats_schema_comparison_report.md",
                        help="Output Markdown file (default: ats_schema_comparison_report.md)")
    args = parser.parse_args()

    generated_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    card_tables  = sorted(SCHEMA_CARD.keys())

    print("=" * 60)
    print("  ATS Schema Comparison Tool")
    print(f"  Generated at : {generated_at}")
    print(f"  DSN          : {args.dsn}")
    print(f"  Owner        : {args.owner}")
    print(f"  Card tables  : {len(card_tables)}")
    print("=" * 60)

    # ── Connect ──────────────────────────────────────────────────────────────
    print("\n[1/4] Connecting to Oracle database ...")
    try:
        conn = get_connection(args.dsn, args.user, args.password)
    except RuntimeError as e:
        print(f"\n[ERROR] {e}")
        sys.exit(1)

    # ── Query live schema ────────────────────────────────────────────────────
    print("\n[2/4] Querying live schema ...")
    try:
        live_tables, live_columns = query_live_schema(conn, args.owner)
    finally:
        conn.close()
        print("  [DB] Connection closed.")

    # ── Compare ──────────────────────────────────────────────────────────────
    print("\n[3/4] Comparing schema card vs live DB ...")
    comparison_results: dict = {}

    for tbl in sorted(card_tables):
        print(f"  Analysing {args.owner}.{tbl} ...", end=" ")
        if tbl not in live_tables:
            print("❌ MISSING")
            continue

        live_cols = live_columns.get(tbl, {})
        result    = compare_table(tbl, SCHEMA_CARD[tbl], live_cols)
        comparison_results[tbl] = result

        icon = "✅" if result["status"] == "MATCHED" else "⚠️"
        details = []
        if result["changed_count"]:
            details.append(f"{result['changed_count']} col(s) changed")
        if result["new_cols"]:
            details.append(f"{len(result['new_cols'])} new col(s)")
        if result["removed_cols"]:
            details.append(f"{len(result['removed_cols'])} removed col(s)")
        print(f"{icon}  {', '.join(details) if details else 'OK'}")

    # ── Build report ─────────────────────────────────────────────────────────
    print("\n[4/4] Building Markdown report ...")
    report = build_report(
        owner=args.owner,
        dsn=args.dsn,
        card_tables=card_tables,
        live_tables=live_tables,
        live_columns=live_columns,
        comparison_results=comparison_results,
        generated_at=generated_at,
    )

    with open(args.output, "w", encoding="utf-8") as f:
        f.write(report)

    print(f"\n✅ Report written to: {args.output}")
    print("=" * 60)

    # ── Quick console summary ────────────────────────────────────────────────
    missing_tbls = [t for t in card_tables if t not in live_tables]
    print(f"  Tables in card   : {len(card_tables)}")
    print(f"  Tables in DB     : {len(live_tables)}")
    print(f"  Missing tables   : {len(missing_tbls)}")
    print(f"  Compared tables  : {len(comparison_results)}")
    total_changed = sum(r["changed_count"] for r in comparison_results.values())
    total_new     = sum(len(r["new_cols"])  for r in comparison_results.values())
    total_removed = sum(len(r["removed_cols"]) for r in comparison_results.values())
    print(f"  Changed cols     : {total_changed}")
    print(f"  New cols (DB)    : {total_new}")
    print(f"  Removed cols     : {total_removed}")
    print("=" * 60)


if __name__ == "__main__":
    main()