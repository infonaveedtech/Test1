"""
agents/agent0_intent.py — Intent Classifier & Safety Gate

Responsibilities:
  1. Decide if query needs the NL→SQL pipeline
  2. Detect if clarification is needed before proceeding
  3. Safety filtering (block dangerous/off-topic queries)
  4. Rephrase/normalize the user query for downstream agents

Output contract (JSON):
{
  "should_run_pipeline": bool,
  "needs_clarification": bool,
  "clarification_questions": ["..."],   // only if needs_clarification=true
  "intent": "sql_query" | "clarification_answer" | "small_talk" | "meta_question" | "unsafe",
  "rephrased_query": "...",
  "assistant_reply": "...",             // message to show user if not running pipeline
  "confidence": 0.0-1.0,
  "safety": {
    "is_potentially_unsafe": bool,
    "notes": "..."
  }
}
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

from core.config import get_settings
from core.exceptions import ClarificationRequired, UnsafeQueryError
from core.ollama import get_client

logger = logging.getLogger(__name__)

_SYSTEM_PROMPT = """You are Agent-0, the Intent Classifier for a financial markets analytics chatbot.

Your job is to analyze the user's message IN CONTEXT of the conversation history, then return a JSON decision.

The system has access to a financial markets database which contains the information for:
- Trading data (symbols, prices, volumes, turnover)
- Market data (exchanges, best bid/offer quotes)
- Time-series indicators (daily, intraday)

DECISION RULES:
1. should_run_pipeline = true  → If the user wants data from the database (e.g. "show me turnover", "top 10 symbols", "compare exchanges", "how many trades")
2. needs_clarification = true  → If the query is ambiguous, missing key parameters (time range, metric, grouping), or contradictory. In this case, ask 1-2 SPECIFIC clarifying questions.
3. intent = "small_talk"       → If it's a greeting, thank you, or off-topic conversational message
4. intent = "meta_question"    → If the user asks about the system's capabilities ("what can you do?", "which tables do you have?")
5. intent = "clarification_answer" → If this message is clearly answering a clarification question you asked earlier
6. intent = "unsafe"           → If the query requests DML (INSERT/UPDATE/DELETE/DROP), credentials, or is malicious
7. should_run_pipeline = false → For small_talk, meta_question, unsafe

CLARIFICATION GUIDELINES:
- Only ask for clarification if it would materially change the SQL (e.g., missing date range when no default is obvious)
- If the query is somewhat vague but a reasonable default exists (e.g., "last 30 days"), proceed with that default
- Ask max 2 questions at a time
- Questions must be specific and actionable

HISTORY AWARENESS:
- If the user says "same but for last month" or "add exchange breakdown", this is a follow-up; extract the full intent from history
- If a clarification was asked and this message answers it, set intent = "clarification_answer" and combine with previous context

Return ONLY a valid JSON object. No prose, no markdown, no code fences."""


def _load_system_prompt() -> str:
    s = get_settings()
    p = s.prompts_path / "system_agent0_intent.md"
    if p.exists():
        return p.read_text(encoding="utf-8", errors="ignore")
    return _SYSTEM_PROMPT


def _fallback_intent(query: str) -> Dict[str, Any]:
    return {
        "should_run_pipeline": True,
        "needs_clarification": False,
        "clarification_questions": [],
        "intent": "sql_query",
        "rephrased_query": query.strip(),
        "assistant_reply": "I'll look that up in the database for you.",
        "confidence": 0.5,
        "safety": {"is_potentially_unsafe": False, "notes": "Fallback; no explicit safety signals."},
    }


def run(
    user_query: str,
    conversation_history: List[Dict[str, str]] = None,
) -> Dict[str, Any]:
    """
    Run Agent-0.

    Args:
        user_query: The latest user message.
        conversation_history: Prior messages as [{"role": "user"|"assistant", "content": "..."}]

    Returns:
        Parsed intent dict.

    Side effects:
        - Raises ClarificationRequired if needs_clarification=true
        - Raises UnsafeQueryError if safety.is_potentially_unsafe=true
    """
    s = get_settings()
    client = get_client()

    system_txt = _load_system_prompt()

    # Build messages: system + optional history + current query
    messages: List[Dict[str, str]] = [{"role": "system", "content": system_txt}]

    if conversation_history:
        # Inject last few turns for context
        messages.extend(conversation_history[-8:])

    history_summary = ""
    if conversation_history:
        history_summary = (
            f"\n\nConversation context: {len(conversation_history)} prior messages in this session."
        )

    messages.append({
        "role": "user",
        "content": (
            f"User message:\n{user_query.strip()}"
            + history_summary
            + "\n\nReturn ONLY the JSON object."
        ),
    })

    obj = client.chat_json(
        messages,
        model=s.model_for(0),
        num_ctx=s.ctx_for(0),
        temperature=0.0,
        num_predict=512,
    )

    if obj is None:
        logger.warning("[Agent0] JSON parse failed; using fallback intent.")
        obj = _fallback_intent(user_query)

    # Normalize keys
    obj.setdefault("should_run_pipeline", True)
    obj.setdefault("needs_clarification", False)
    obj.setdefault("clarification_questions", [])
    obj.setdefault("intent", "sql_query")
    obj.setdefault("rephrased_query", user_query.strip())
    obj.setdefault("assistant_reply", "")
    obj.setdefault("confidence", 0.7)
    safety = obj.get("safety") or {}
    safety.setdefault("is_potentially_unsafe", False)
    safety.setdefault("notes", "")
    obj["safety"] = safety

    logger.info(
        "[Agent0] intent=%s pipeline=%s clarify=%s confidence=%.2f",
        obj["intent"],
        obj["should_run_pipeline"],
        obj["needs_clarification"],
        obj["confidence"],
    )

    # Raise typed exceptions for pipeline to catch
    if obj["safety"]["is_potentially_unsafe"]:
        raise UnsafeQueryError(obj["safety"]["notes"])

    if obj.get("needs_clarification"):
        questions = obj.get("clarification_questions") or []
        raise ClarificationRequired(
            questions=questions,
            assistant_message=obj.get("assistant_reply", ""),
        )

    return obj
