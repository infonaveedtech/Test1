"""
core/ollama.py — Unified, robust Ollama HTTP client (LLM chat only).

Embeddings are handled separately by rag/embedder.py using sentence-transformers,
which runs locally with no Ollama dependency.
"""
from __future__ import annotations

import json
import re
import time
import logging
from typing import Any, Dict, List, Optional
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

logger = logging.getLogger(__name__)

_THINK_RE = re.compile(r"<think>.*?</think>", re.DOTALL | re.IGNORECASE)


def _strip_think(text: str) -> str:
    return _THINK_RE.sub("", text).strip()


def _strip_code_fence(text: str) -> str:
    s = text.strip()
    if s.startswith("```"):
        s = re.sub(r"^```[a-zA-Z]*\n?", "", s)
        s = re.sub(r"```$", "", s)
    return s.strip()


def extract_json(text: Optional[str]) -> Optional[Dict[str, Any]]:
    """
    Multi-strategy JSON extractor.
    1. Direct parse
    2. Strip think tags + code fences, parse
    3. Find largest balanced { } block, parse
    """
    if not text:
        return None

    def _try(s: str) -> Optional[Dict]:
        try:
            obj = json.loads(s)
            if isinstance(obj, dict):
                return obj
            if isinstance(obj, str):
                inner = json.loads(obj)
                if isinstance(inner, dict):
                    return inner
        except Exception:
            pass
        return None

    cleaned = _strip_think(text)

    obj = _try(cleaned)
    if obj:
        return obj

    fenced = _strip_code_fence(cleaned)
    obj = _try(fenced)
    if obj:
        return obj

    # Find largest {...} block
    best: Optional[str] = None
    stack: list = []
    start = 0
    for i, ch in enumerate(fenced):
        if ch == "{":
            if not stack:
                start = i
            stack.append(i)
        elif ch == "}" and stack:
            stack.pop()
            if not stack:
                block = fenced[start : i + 1]
                if best is None or len(block) > len(best):
                    best = block
    if best:
        obj = _try(best)
        if obj:
            return obj

    return None


class OllamaClient:
    """
    Thin, stateless Ollama /api/chat client (LLM inference only).
    Embeddings are NOT handled here — use rag.embedder.get_embedder() instead.
    """

    def __init__(self, host: str, default_model: str):
        self.host = host.rstrip("/")
        self.default_model = default_model
        self._chat_url = f"{self.host}/api/chat"

    # ── chat ─────────────────────────────────────────────────────

    def chat(
        self,
        messages: List[Dict[str, str]],
        *,
        model: Optional[str] = None,
        num_ctx: int = 8192,
        temperature: float = 0.1,
        num_predict: int = 4096,
        stream: bool = False,
        retries: int = 2,
        timeout: int = 900,
    ) -> str:
        """Call /api/chat, return assistant content as plain text."""
        model = model or self.default_model
        payload = {
            "model": model,
            "messages": messages,
            "stream": stream,
            "keep_alive": "10m",
            "options": {
                "num_ctx": num_ctx,
                "temperature": temperature,
                "num_predict": num_predict,
            },
        }

        for attempt in range(retries + 1):
            try:
                data = json.dumps(payload).encode("utf-8")
                req = Request(self._chat_url, data=data,
                              headers={"Content-Type": "application/json"})
                with urlopen(req, timeout=timeout) as resp:
                    raw = resp.read().decode("utf-8", errors="ignore")
                    obj = json.loads(raw)
                    content = (
                        obj.get("message", {}).get("content")
                        or (obj.get("choices", [{}])[0]
                               .get("message", {}).get("content", ""))
                        or ""
                    )
                    return _strip_think(content).strip()

            except (HTTPError, URLError, OSError) as exc:
                if attempt < retries:
                    wait = 2 ** attempt
                    logger.warning("[Ollama] attempt %d failed (%s), retrying in %ds…",
                                   attempt + 1, exc, wait)
                    time.sleep(wait)
                else:
                    raise RuntimeError(
                        f"Ollama /api/chat failed after {retries + 1} attempts: {exc}"
                    ) from exc
        return ""

    def chat_json(
        self,
        messages: List[Dict[str, str]],
        *,
        model: Optional[str] = None,
        num_ctx: int = 8192,
        temperature: float = 0.1,
        num_predict: int = 4096,
        retries: int = 2,
        timeout: int = 900,
        retry_prompt: Optional[str] = None,
    ) -> Optional[Dict[str, Any]]:
        """chat() + extract first JSON object. Retries once with explicit reminder."""
        raw = self.chat(messages, model=model, num_ctx=num_ctx,
                        temperature=temperature, num_predict=num_predict,
                        retries=retries, timeout=timeout)
        obj = extract_json(raw)
        if obj is not None:
            return obj

        logger.warning("[Ollama.chat_json] JSON parse failed — retrying with explicit reminder")
        reminder = retry_prompt or (
            "\n\nCRITICAL: Your ENTIRE response must be ONE valid JSON object only. "
            "No prose. No markdown. No code fences. Start with { and end with }."
        )
        retry_messages = list(messages)
        retry_messages[-1] = {
            "role": "user",
            "content": retry_messages[-1]["content"] + reminder,
        }
        raw2 = self.chat(retry_messages, model=model, num_ctx=num_ctx,
                         temperature=0.0, num_predict=num_predict,
                         retries=1, timeout=timeout)
        return extract_json(raw2)

    # ── health ────────────────────────────────────────────────────

    def health_check(self) -> bool:
        """Returns True if Ollama server is reachable."""
        try:
            req = Request(f"{self.host}/api/tags")
            with urlopen(req, timeout=5):
                return True
        except Exception:
            return False

    def list_models(self) -> List[str]:
        """Return names of all pulled models."""
        try:
            req = Request(f"{self.host}/api/tags")
            with urlopen(req, timeout=10) as resp:
                obj = json.loads(resp.read().decode("utf-8"))
                return [m["name"] for m in obj.get("models", [])]
        except Exception:
            return []


# ── Singleton ─────────────────────────────────────────────────────────────────

_client: Optional[OllamaClient] = None


def get_client() -> OllamaClient:
    global _client
    if _client is None:
        from core.config import get_settings
        s = get_settings()
        _client = OllamaClient(host=s.LLM_HOST, default_model=s.LLM_MODEL)
    return _client
