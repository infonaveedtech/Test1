"""
core/exceptions.py — Typed exceptions used throughout the pipeline.
"""


class NL2SQLError(Exception):
    """Base class for all NL→SQL errors."""


class IntentError(NL2SQLError):
    """Agent-0 failed to classify intent."""


class ClarificationRequired(NL2SQLError):
    """
    Agent-0 determined the query needs clarification before proceeding.
    The `questions` attribute holds the list of clarifying questions.
    """
    def __init__(self, questions: list[str], assistant_message: str = ""):
        self.questions = questions
        self.assistant_message = assistant_message
        super().__init__(f"Clarification required: {questions}")


class RAGError(NL2SQLError):
    """FAISS retrieval or embedding failed."""


class PlannerError(NL2SQLError):
    """Agent-1 (Planner) failed to produce a valid envelope."""


class ComposerError(NL2SQLError):
    """Agent-2 (Composer) failed to produce valid SQL."""


class VerifierError(NL2SQLError):
    """Agent-3 (Verifier) failed."""


class DatabaseError(NL2SQLError):
    """Oracle execution error."""


class SessionNotFound(NL2SQLError):
    """Requested session/conversation does not exist."""


class UnsafeQueryError(NL2SQLError):
    """Agent-0 flagged the query as potentially unsafe or out of scope."""
    def __init__(self, reason: str):
        self.reason = reason
        super().__init__(f"Unsafe query blocked: {reason}")
