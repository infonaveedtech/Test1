# """
# db/sqlite_store.py — SQLite-backed persistence for sessions, messages, and runs.

# Schema:
#   sessions   — one row per conversation session
#   messages   — chat history ordered by turn
#   runs       — each pipeline execution with full artifacts
# """
# from __future__ import annotations

# import json
# import sqlite3
# import time
# import uuid
# from contextlib import contextmanager
# from pathlib import Path
# from typing import Any, Dict, Generator, List, Optional

# from core.config import get_settings


# # ── Connection management ──────────────────────────────────────────────────────

# def _db_path() -> Path:
#     p = Path(get_settings().SQLITE_PATH)
#     p.parent.mkdir(parents=True, exist_ok=True)
#     return p


# @contextmanager
# def _conn() -> Generator[sqlite3.Connection, None, None]:
#     db = sqlite3.connect(str(_db_path()), check_same_thread=False)
#     db.row_factory = sqlite3.Row
#     db.execute("PRAGMA journal_mode=WAL")
#     db.execute("PRAGMA foreign_keys=ON")
#     try:
#         yield db
#         db.commit()
#     except Exception:
#         db.rollback()
#         raise
#     finally:
#         db.close()


# # ── Schema migration ───────────────────────────────────────────────────────────

# SCHEMA_SQL = """
# CREATE TABLE IF NOT EXISTS sessions (
#     session_id   TEXT PRIMARY KEY,
#     title        TEXT NOT NULL DEFAULT 'New Chat',
#     created_at   REAL NOT NULL,
#     updated_at   REAL NOT NULL,
#     meta         TEXT NOT NULL DEFAULT '{}'
# );

# CREATE TABLE IF NOT EXISTS messages (
#     message_id   TEXT PRIMARY KEY,
#     session_id   TEXT NOT NULL REFERENCES sessions(session_id) ON DELETE CASCADE,
#     role         TEXT NOT NULL CHECK(role IN ('user','assistant','system')),
#     content      TEXT NOT NULL,
#     turn         INTEGER NOT NULL,
#     created_at   REAL NOT NULL,
#     meta         TEXT NOT NULL DEFAULT '{}'
# );
# CREATE INDEX IF NOT EXISTS idx_messages_session ON messages(session_id, turn);

# CREATE TABLE IF NOT EXISTS runs (
#     run_id            TEXT PRIMARY KEY,
#     session_id        TEXT NOT NULL REFERENCES sessions(session_id) ON DELETE CASCADE,
#     message_id        TEXT,
#     question          TEXT NOT NULL,
#     intent            TEXT,
#     should_run_pipeline INTEGER NOT NULL DEFAULT 0,
#     rephrased_query   TEXT,
#     plan_envelope     TEXT,
#     composed_sql      TEXT,
#     verified_sql      TEXT,
#     db_columns        TEXT,
#     db_rows           TEXT,
#     db_row_count      INTEGER,
#     answer_text       TEXT,
#     answer_summary    TEXT,
#     answer_key_facts  TEXT,
#     status            TEXT NOT NULL DEFAULT 'pending',
#     error_message     TEXT,
#     timing_ms         TEXT NOT NULL DEFAULT '{}',
#     created_at        REAL NOT NULL,
#     completed_at      REAL
# );
# CREATE INDEX IF NOT EXISTS idx_runs_session ON runs(session_id);
# """


# def init_db() -> None:
#     """Create tables if they don't exist. Safe to call multiple times."""
#     with _conn() as db:
#         db.executescript(SCHEMA_SQL)


# # ── Session CRUD ───────────────────────────────────────────────────────────────

# def create_session(title: str = "New Chat", meta: Dict = None) -> Dict[str, Any]:
#     sid = str(uuid.uuid4())
#     now = time.time()
#     with _conn() as db:
#         db.execute(
#             "INSERT INTO sessions VALUES (?,?,?,?,?)",
#             (sid, title, now, now, json.dumps(meta or {})),
#         )
#     return get_session(sid)


# def get_session(session_id: str) -> Optional[Dict[str, Any]]:
#     with _conn() as db:
#         row = db.execute(
#             "SELECT * FROM sessions WHERE session_id=?", (session_id,)
#         ).fetchone()
#     if row is None:
#         return None
#     return dict(row)


# def list_sessions(limit: int = 50) -> List[Dict[str, Any]]:
#     with _conn() as db:
#         rows = db.execute(
#             "SELECT * FROM sessions ORDER BY updated_at DESC LIMIT ?", (limit,)
#         ).fetchall()
#     return [dict(r) for r in rows]


# def update_session_title(session_id: str, title: str) -> None:
#     now = time.time()
#     with _conn() as db:
#         db.execute(
#             "UPDATE sessions SET title=?, updated_at=? WHERE session_id=?",
#             (title, now, session_id),
#         )


# def delete_session(session_id: str) -> None:
#     with _conn() as db:
#         db.execute("DELETE FROM sessions WHERE session_id=?", (session_id,))


# # ── Message CRUD ───────────────────────────────────────────────────────────────

# def add_message(
#     session_id: str,
#     role: str,
#     content: str,
#     meta: Dict = None,
# ) -> Dict[str, Any]:
#     mid = str(uuid.uuid4())
#     now = time.time()
#     # Get next turn number
#     with _conn() as db:
#         row = db.execute(
#             "SELECT COALESCE(MAX(turn),0)+1 FROM messages WHERE session_id=?",
#             (session_id,),
#         ).fetchone()
#         turn = row[0]
#         db.execute(
#             "INSERT INTO messages VALUES (?,?,?,?,?,?,?)",
#             (mid, session_id, role, content, turn, now, json.dumps(meta or {})),
#         )
#         db.execute(
#             "UPDATE sessions SET updated_at=? WHERE session_id=?", (now, session_id)
#         )
#     return get_message(mid)


# def get_message(message_id: str) -> Optional[Dict[str, Any]]:
#     with _conn() as db:
#         row = db.execute(
#             "SELECT * FROM messages WHERE message_id=?", (message_id,)
#         ).fetchone()
#     return dict(row) if row else None


# def get_session_messages(
#     session_id: str, limit: int = 50
# ) -> List[Dict[str, Any]]:
#     with _conn() as db:
#         rows = db.execute(
#             "SELECT * FROM messages WHERE session_id=? ORDER BY turn ASC LIMIT ?",
#             (session_id, limit),
#         ).fetchall()
#     return [dict(r) for r in rows]


# def get_history_for_llm(session_id: str, max_turns: int = 10) -> List[Dict[str, str]]:
#     """
#     Return the last N turns as OpenAI-style messages for injection into LLM prompts.
#     Only includes user and assistant messages (not system).
#     """
#     msgs = get_session_messages(session_id, limit=max_turns * 2)
#     result = []
#     for m in msgs:
#         if m["role"] in ("user", "assistant"):
#             result.append({"role": m["role"], "content": m["content"]})
#     return result[-max_turns * 2:]  # cap at 2*N messages


# # ── Run CRUD ───────────────────────────────────────────────────────────────────

# def create_run(session_id: str, question: str, message_id: str = None) -> str:
#     run_id = str(uuid.uuid4())
#     now = time.time()
#     with _conn() as db:
#         db.execute(
#             """INSERT INTO runs (run_id, session_id, message_id, question, created_at)
#                VALUES (?,?,?,?,?)""",
#             (run_id, session_id, message_id, question, now),
#         )
#     return run_id


# def update_run(run_id: str, **kwargs) -> None:
#     """
#     Flexible partial update. Accepted kwargs:
#       intent, should_run_pipeline, rephrased_query, plan_envelope (dict→json),
#       composed_sql, verified_sql, db_columns (list→json), db_rows (list→json),
#       db_row_count, answer_text, answer_summary, answer_key_facts (list→json),
#       status, error_message, timing_ms (dict→json), completed_at
#     """
#     json_fields = {
#         "plan_envelope", "db_columns", "db_rows",
#         "answer_key_facts", "timing_ms",
#     }
#     sets, vals = [], []
#     for k, v in kwargs.items():
#         sets.append(f"{k}=?")
#         vals.append(json.dumps(v) if k in json_fields and v is not None else v)
#     if not sets:
#         return
#     vals.append(run_id)
#     with _conn() as db:
#         db.execute(f"UPDATE runs SET {', '.join(sets)} WHERE run_id=?", vals)


# def get_run(run_id: str) -> Optional[Dict[str, Any]]:
#     with _conn() as db:
#         row = db.execute("SELECT * FROM runs WHERE run_id=?", (run_id,)).fetchone()
#     if row is None:
#         return None
#     d = dict(row)
#     # Deserialize JSON fields
#     for f in ("plan_envelope", "db_columns", "db_rows", "answer_key_facts", "timing_ms"):
#         if d.get(f):
#             try:
#                 d[f] = json.loads(d[f])
#             except Exception:
#                 pass
#     return d


# def list_runs(session_id: str, limit: int = 20) -> List[Dict[str, Any]]:
#     with _conn() as db:
#         rows = db.execute(
#             "SELECT * FROM runs WHERE session_id=? ORDER BY created_at DESC LIMIT ?",
#             (session_id, limit),
#         ).fetchall()
#     return [get_run(dict(r)["run_id"]) for r in rows]


#---------------------------------------------------------------------------------------------------------


# """
# Compatibility shim.

# The app previously imported db.sqlite_store for chatbot persistence.
# We now want the same public API to be served by Oracle instead.

# So this file simply re-exports the Oracle-backed store functions.
# """

# from db.oracle_store import (
#     add_message,
#     create_run,
#     create_session,
#     delete_session,
#     get_history_for_llm,
#     get_message,
#     get_run,
#     get_session,
#     get_session_messages,
#     init_db,
#     list_runs,
#     list_sessions,
#     update_run,
#     update_session_title,
# )

# __all__ = [
#     "init_db",
#     "create_session",
#     "get_session",
#     "list_sessions",
#     "update_session_title",
#     "delete_session",
#     "add_message",
#     "get_message",
#     "get_session_messages",
#     "get_history_for_llm",
#     "create_run",
#     "update_run",
#     "get_run",
#     "list_runs",
# ]



#-----------------------------------------

"""
Compatibility shim.

The app previously imported db.sqlite_store for chatbot persistence.
We now want the same public API to be served by Oracle instead.

So this file simply re-exports the Oracle-backed store functions.
"""

from db.oracle_store import (
    add_message,
    create_run,
    create_session,
    delete_session,
    get_history_for_llm,
    get_message,
    get_run,
    get_session,
    get_session_messages,
    init_db,
    list_runs,
    list_sessions,
    set_session_starred,
    toggle_session_starred,
    update_run,
    update_session_title,
)

__all__ = [
    "init_db",
    "create_session",
    "get_session",
    "list_sessions",
    "update_session_title",
    "set_session_starred",
    "toggle_session_starred",
    "delete_session",
    "add_message",
    "get_message",
    "get_session_messages",
    "get_history_for_llm",
    "create_run",
    "update_run",
    "get_run",
    "list_runs",
]