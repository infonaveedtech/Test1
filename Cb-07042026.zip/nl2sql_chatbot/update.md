# Schema Sync Progress — NL2SQL Chatbot

## Context

The chatbot was originally built on **Schema Card v227**, while the production database is now on **v177**.
This introduced mismatches across:

* Schema Card (`prompts/schema_card.md`)
* Glossary (`data/docs/glossary.docs.jsonl`)
* Fewshots (`data/docs/fewshots.docs.jsonl`)
* FAISS indexed metadata (`data/faiss/...`)
* Agent prompting logic

The goal is to **align the entire pipeline with the live DB schema**.

---

## ✅ Phase 1 — Removed Columns Cleanup

### Removed Columns Identified

* `ATS.CANCELLED_TRADES.CANCELLATION_DATETIME`
* `ATS.EDS_CLIENTS.IS_POLITICAL_PERSON`
* `ATS.REPO_CONTRACTS.NEW_CONTARCT_ID`
* `ATS.SYMBOLS.SETTLEMENT_TYPE_ID`

---

### Fixes Applied

#### 1. `CANCELLATION_DATETIME`

* Replaced everywhere with `ENTRY_DATETIME`
* Updated:

  * Schema card
  * Glossary
  * Fewshots (`fs-015`, `fs-045`, `fs-048`)
* Rebuilt FAISS indexes

#### 2. `IS_POLITICAL_PERSON`

* Removed from schema card
* No usage in glossary/fewshots → no further action required

#### 3. `NEW_CONTARCT_ID`

* Removed typo column from schema card
* Confirmed not used in fewshots/glossary

#### 4. `SYMBOLS.SETTLEMENT_TYPE_ID`

* Removed from `ATS.SYMBOLS` in schema card
* Verified:

  * Not used in glossary
  * Not used in fewshots
  * Valid usage remains in:

    * `TRADES`
    * `REPO_CONTRACTS`
    * `SYMBOL_MARKETS`

---

### RAG Rebuild

* Rebuilt FAISS indexes successfully:

  * Fewshots: 85 docs
  * Glossary: 53 docs
* Ensured no stale metadata remains

---

## ✅ Phase 2 — Data Type Changes Review

### Summary

* **70 columns changed** (precision, width, nullability)
* Categorized into:

#### High-impact (reviewed)

* Trade / Repo numeric precision changes
* Price, yield, accrued profit fields

#### Medium-impact

* String width expansions (clients, symbols, brokers)
* Flag fields (`SIDE`, `IS_SHORT` → length increased)

#### Low-impact

* Minor metadata columns

---

### Actions Taken

* Updated schema card datatypes where relevant
* No immediate changes required in:

  * Glossary
  * Fewshots
* Confirmed:

  * No SQL logic depended on exact datatype precision

---

## ✅ Phase 3 — New Columns Identification

### Summary

* **73 new columns** added in live DB

### Key Areas

#### High-value (analytics-relevant)

* `TRADES`

  * `DISCOUNT_RATE`, `PRINCIPAL_AMOUNT`, `SETTLEMENT_DATE`
  * `IS_CANCELLED`, `IS_SETTLED`
* `ORDERS`

  * `ACCOUNT_CATEGORY`, `DISCOUNT_RATE`, `RECEIVING_TIME`
* `NEGOTIATED_TRADES`

  * `PRINCIPAL_AMOUNT`, `SETTLEMENT_AMOUNT`, `DISCOUNT_RATE`
* `SYMBOL_INDICATORS` / `SYMBOL_DAILY_INDICATORS`

  * `DISCOUNT_RATE`, `PERCENTAGE_CHANGE`
* `SYMBOL_MARKETS`

  * `SETTLEMENT_TYPE_ID`, `PRECISION`, market configs

#### Low-priority (operational/internal)

* `LEGACY_*`
* `XML_PAYLOAD`
* `BROKER_RECORD_ID`
* `CSD_REJECTION_REASON`

---

## ⚙️ Current System Status

### ✅ Completed

* Removed-column inconsistencies resolved
* Schema card aligned for deletions
* Fewshots and glossary updated
* FAISS indexes rebuilt
* No stale schema leakage in RAG

### ⚠️ Pending

* Incorporation of **new columns into schema card**
* Optional enrichment of:

  * Glossary
  * Fewshots (to leverage new analytics fields)

---

## 🔜 Next Steps

### Phase 4 — Schema Enrichment

1. Add high-value new columns to schema card:

   * `TRADES`, `ORDERS`, `NEGOTIATED_TRADES`
   * `SYMBOL_MARKETS`, `SYMBOL_INDICATORS`

2. Decide usage strategy:

   * Which fields should influence NL→SQL generation
   * Which remain hidden/internal

---

### Phase 5 — Fewshot & Glossary Expansion

* Add new query patterns using:

  * `DISCOUNT_RATE`
  * `SETTLEMENT_DATE`
  * `PRINCIPAL_AMOUNT`
* Introduce new business questions:

  * settlement-based analytics
  * discount/yield comparisons

---

### Phase 6 — End-to-End Validation

* Run test prompts:

  * cancellation trends
  * settlement-type queries
  * repo analytics
* Ensure:

  * no invalid columns generated
  * correct joins used
  * consistent date semantics
