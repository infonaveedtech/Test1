# ATS Schema Comparison Report

**Generated on:** 2026-04-03 11:40:08  
**Database:** ATS@192.168.36.96:1521/infotechdb  
**Schema Card Version:** schema_card.md (ATS owner, 33 tables)

## Summary

- **Total tables in Schema Card:** 33
- **Tables present in DB:** 33
- **Tables missing from DB:** 0
- **Columns changed (type or nullability):** 71
- **New columns (in DB, not in card):** 50
- **Removed columns (in card, not in DB):** 4
- **Extra tables in live DB (not in card):** 276

---

## Detailed Comparison by Table

### ATS.ATS_LEVY_DATA_LOG

**Status:** ✅ Matched  
**Grain (from card):** levy_log_event  
**Date Key:** TRANSACTION_DATE  

| Column | Schema Card Type | Live DB Type | Card Nullable | Live Nullable | Status | Notes |
|--------|-----------------|-------------|--------------|--------------|--------|-------|
| TRANSACTION_ID | NUMBER(14,0) | NUMBER(14,0) | NULL | NULL | ✅ OK |  |
| TRANSACTION_DATE | DATE | DATE | NULL | NULL | ✅ OK |  |
| TICKET_NO | NUMBER(10,0) | NUMBER(10,0) | NULL | NULL | ✅ OK |  |
| BROKER_ID | NUMBER(5,0) | NUMBER(5,0) | NULL | NULL | ✅ OK |  |
| ACCOUNT_ID | NUMBER(20,0) | NUMBER(20,0) | NULL | NULL | ✅ OK |  |
| LEVY_ID | NUMBER(8,0) | NUMBER(8,0) | NULL | NULL | ✅ OK |  |
| PRICE | NUMBER(14,4) | NUMBER(14,4) | NULL | NULL | ✅ OK |  |
| VOLUME | NUMBER(10,0) | NUMBER(10,0) | NULL | NULL | ✅ OK |  |
| AMOUNT | NUMBER(15,4) | NUMBER(15,4) | NULL | NULL | ✅ OK |  |
| LEVY_AMOUNT | NUMBER(14,4) | NUMBER(14,4) | NULL | NULL | ✅ OK |  |
| LEVY_RATE | NUMBER(14,4) | NUMBER(14,4) | NULL | NULL | ✅ OK |  |
| BUY_SELL | VARCHAR2(1) | VARCHAR2(1) | NULL | NULL | ✅ OK |  |
| MARKET | VARCHAR2(14) | VARCHAR2(14) | NULL | NULL | ✅ OK |  |
| LEVY_ACCOUNT | VARCHAR2(30) | VARCHAR2(30) | NULL | NULL | ✅ OK |  |
| FROM_LEVY_DATE | DATE | DATE | NULL | NULL | ✅ OK |  |
| TO_LEVY_DATE | DATE | DATE | NULL | NULL | ✅ OK |  |
| LOG_DESCRIPTION | VARCHAR2(100) | VARCHAR2(100) | NULL | NULL | ✅ OK |  |
| LEVY_ENTRY_DATE | TIMESTAMP(6) | TIMESTAMP(6) | NULL | NULL | ✅ OK |  |
| ENTRY_USER | VARCHAR2(30) | VARCHAR2(30) | NULL | NULL | ✅ OK |  |

### ATS.BEST_MKT

**Status:** ✅ Matched  
**Grain (from card):** symbol_timestamp  
**Date Key:** ENTRY_DATETIME  

| Column | Schema Card Type | Live DB Type | Card Nullable | Live Nullable | Status | Notes |
|--------|-----------------|-------------|--------------|--------------|--------|-------|
| ENTRY_DATETIME | TIMESTAMP(9) | TIMESTAMP(9) | NOT NULL | NOT NULL | ✅ OK |  |
| BID_ORDER_COUNT | NUMBER(8,0) | NUMBER(8,0) | NULL | NULL | ✅ OK |  |
| OFFER_ORDER_COUNT | NUMBER(8,0) | NUMBER(8,0) | NULL | NULL | ✅ OK |  |
| BID_VOLUME | NUMBER(10,0) | NUMBER(10,0) | NULL | NULL | ✅ OK |  |
| OFFER_VOLUME | NUMBER(10,0) | NUMBER(10,0) | NULL | NULL | ✅ OK |  |
| BID_PRICE | NUMBER(14,4) | NUMBER(14,4) | NULL | NULL | ✅ OK |  |
| OFFER_PRICE | NUMBER(14,4) | NUMBER(14,4) | NULL | NULL | ✅ OK |  |
| SYMBOL_ID | NUMBER(15,0) | NUMBER(15,0) | NOT NULL | NOT NULL | ✅ OK |  |
| MARKET_ID | NUMBER(4,0) | NUMBER(4,0) | NOT NULL | NOT NULL | ✅ OK |  |
| EXCHANGE_ID | NUMBER(4,0) | NUMBER(4,0) | NOT NULL | NOT NULL | ✅ OK |  |

### ATS.CANCELLED_TRADES

**Status:** ⚠️ Changed  
**Grain (from card):** cancel_event  
**Date Key:** ENTRY_DATETIME  
**Removed columns (card only):** CANCELLATION_DATETIME  

| Column | Schema Card Type | Live DB Type | Card Nullable | Live Nullable | Status | Notes |
|--------|-----------------|-------------|--------------|--------------|--------|-------|
| ENTRY_DATETIME | TIMESTAMP(6) | TIMESTAMP(6) | NOT NULL | NOT NULL | ✅ OK |  |
| TICKET_NO | NUMBER(10,0) | NUMBER(10,0) | NOT NULL | NOT NULL | ✅ OK |  |
| SELLER_ORDER_NO | NUMBER(10,0) | NUMBER(10,0) | NOT NULL | NOT NULL | ✅ OK |  |
| BUYER_ORDER_NO | NUMBER(10,0) | NUMBER(10,0) | NOT NULL | NOT NULL | ✅ OK |  |
| PRICE | NUMBER(16,4) | NUMBER(14,4) | NOT NULL | NOT NULL | ⚠️ CHANGED | Type: `NUMBER(16,4)` → `NUMBER(14,4)` |
| VOLUME | NUMBER(10,0) | NUMBER(10,0) | NOT NULL | NOT NULL | ✅ OK |  |
| EXCHANGE_ID | NUMBER(4,0) | NUMBER(4,0) | NOT NULL | NOT NULL | ✅ OK |  |
| BUYER_CLIENT_ID | NUMBER(20,0) | NUMBER(20,0) | NOT NULL | NOT NULL | ✅ OK |  |
| SELLER_CLIENT_ID | NUMBER(20,0) | NUMBER(20,0) | NOT NULL | NOT NULL | ✅ OK |  |
| SYMBOL_ID | NUMBER(15,0) | NUMBER(15,0) | NOT NULL | NOT NULL | ✅ OK |  |
| MARKET_ID | NUMBER(4,0) | NUMBER(4,0) | NOT NULL | NOT NULL | ✅ OK |  |
| BUYER_BROKER_ID | NUMBER(5,0) | NUMBER(5,0) | NOT NULL | NOT NULL | ✅ OK |  |
| SELLER_BROKER_ID | NUMBER(5,0) | NUMBER(5,0) | NOT NULL | NOT NULL | ✅ OK |  |
| BUYER_USER_ID | NUMBER(30,0) | NUMBER(30,0) | NOT NULL | NOT NULL | ✅ OK |  |
| SELLER_USER_ID | NUMBER(30,0) | NUMBER(30,0) | NOT NULL | NOT NULL | ✅ OK |  |
| TRADE_TYPE | NUMBER(1,0) | NUMBER(1,0) | NOT NULL | NOT NULL | ✅ OK |  |
| IS_SHORT | NVARCHAR2(1) | NVARCHAR2(2) | NOT NULL | NOT NULL | ⚠️ CHANGED | Type: `NVARCHAR2(1)` → `NVARCHAR2(2)` |
| STATE_ID | NUMBER(2,0) | NUMBER(2,0) | NOT NULL | NOT NULL | ✅ OK |  |
| BUYER_REMAINING_VOLUME | NUMBER(10,0) | NUMBER(10,0) | NOT NULL | NOT NULL | ✅ OK |  |
| SELLER_REMAINING_VOLUME | NUMBER(10,0) | NUMBER(10,0) | NOT NULL | NOT NULL | ✅ OK |  |
| BUYER_CUSTODIAN_ID | NUMBER(20,0) | NUMBER(20,0) | NULL | NULL | ✅ OK |  |
| SELLER_CUSTODIAN_ID | NUMBER(20,0) | NUMBER(20,0) | NULL | NULL | ✅ OK |  |
| ACCRUED_PROFIT | NUMBER(20,4) | NUMBER(15,4) | NULL | NULL | ⚠️ CHANGED | Type: `NUMBER(20,4)` → `NUMBER(15,4)` |
| YIELD | NUMBER(16,4) | NUMBER(15,4) | NULL | NULL | ⚠️ CHANGED | Type: `NUMBER(16,4)` → `NUMBER(15,4)` |
| VALUE | NUMBER(20,4) | NUMBER(15,4) | NULL | NULL | ⚠️ CHANGED | Type: `NUMBER(20,4)` → `NUMBER(15,4)` |
| PRICING_MECHANISM | NUMBER(1,0) | NUMBER(1,0) | NULL | NULL | ✅ OK |  |
| PRICING_MODEL | NUMBER(1,0) | NUMBER(1,0) | NULL | NULL | ✅ OK |  |
| SETTLEMENT_TYPE_ID | NUMBER(4,0) | NUMBER(4,0) | NULL | NULL | ✅ OK |  |
| SETTLEMENT_AMOUNT | NUMBER(20,4) | NUMBER(20,4) | NULL | NULL | ✅ OK |  |
| CONTRACT_ID | VARCHAR2(25) | VARCHAR2(25) | NULL | NULL | ✅ OK |  |
| INITIAL_DATE | DATE | DATE | NULL | NULL | ✅ OK |  |
| TERMINATION_DATE | DATE | DATE | NULL | NULL | ✅ OK |  |
| LEG | NUMBER(1,0) | NUMBER(1,0) | NULL | NULL | ✅ OK |  |
| REPURCHASE_PRICE | NUMBER(16,4) | NUMBER(14,4) | NULL | NULL | ⚠️ CHANGED | Type: `NUMBER(16,4)` → `NUMBER(14,4)` |
| DIRTY_PRICE | NUMBER(16,4) | NUMBER(14,4) | NULL | NULL | ⚠️ CHANGED | Type: `NUMBER(16,4)` → `NUMBER(14,4)` |
| BUYER_TRADER_ID | NUMBER(30,0) | NUMBER(30,0) | NULL | NULL | ✅ OK |  |
| SELLER_TRADER_ID | NUMBER(30,0) | NUMBER(30,0) | NULL | NULL | ✅ OK |  |
| TRADE_DATETIME | TIMESTAMP(6) | TIMESTAMP(6) | NULL | NULL | ✅ OK |  |
| CANCELLATION_DATETIME | TIMESTAMP(6) | — | NULL | — | ❌ REMOVED | Column missing from live DB |

### ATS.EDS_CLIENTS

**Status:** ⚠️ Changed  
**New columns (live DB only):** IS_DEFAULT, APPROVAL_FLAG  
**Removed columns (card only):** IS_POLITICAL_PERSON  

| Column | Schema Card Type | Live DB Type | Card Nullable | Live Nullable | Status | Notes |
|--------|-----------------|-------------|--------------|--------------|--------|-------|
| CLIENT_CODE | NVARCHAR2(30) | NVARCHAR2(60) | NOT NULL | NOT NULL | ⚠️ CHANGED | Type: `NVARCHAR2(30)` → `NVARCHAR2(60)` |
| AGENT_ID | NUMBER(6,0) | NUMBER(6,0) | NULL | NULL | ✅ OK |  |
| CLIENT_ID | NUMBER(20,0) | NUMBER(20,0) | NOT NULL | NOT NULL | ✅ OK | PK |
| BRANCH_ID | NUMBER(6,0) | NUMBER(6,0) | NULL | NULL | ✅ OK |  |
| BROKER_ID | NUMBER(5,0) | NUMBER(5,0) | NULL | NULL | ✅ OK |  |
| CLIENT_GROUP_ID | NUMBER(10,0) | NUMBER(10,0) | NULL | NULL | ✅ OK |  |
| DEFAULT_EXCHANGE_ID | NUMBER(4,0) | NUMBER(4,0) | NULL | NULL | ✅ OK | FK→ATS.EXCHANGES(EXCHANGE_ID) |
| ACTIVE | NUMBER(1,0) | NUMBER(1,0) | NULL | NULL | ✅ OK | 0=Active, 1=Suspended |
| NAME | NVARCHAR2(400) | NVARCHAR2(800) | NULL | NULL | ⚠️ CHANGED | Type: `NVARCHAR2(400)` → `NVARCHAR2(800)` |
| MOBILE | NVARCHAR2(30) | NVARCHAR2(60) | NULL | NULL | ⚠️ CHANGED | Type: `NVARCHAR2(30)` → `NVARCHAR2(60)` |
| TELEPHONE | NVARCHAR2(30) | NVARCHAR2(60) | NULL | NULL | ⚠️ CHANGED | Type: `NVARCHAR2(30)` → `NVARCHAR2(60)` |
| NIC | NVARCHAR2(30) | NVARCHAR2(60) | NULL | NULL | ⚠️ CHANGED | Type: `NVARCHAR2(30)` → `NVARCHAR2(60)` |
| DEPO_REFERENCE | NVARCHAR2(64) | NVARCHAR2(128) | NOT NULL | NOT NULL | ⚠️ CHANGED | Type: `NVARCHAR2(64)` → `NVARCHAR2(128)` |
| MODIFICATION_DATE | DATE | DATE | NOT NULL | NOT NULL | ✅ OK |  |
| REGISTRATION_DATE | DATE | DATE | NOT NULL | NOT NULL | ✅ OK |  |
| IS_FOREIGNER | VARCHAR2(1) | VARCHAR2(1) | NULL | NULL | ✅ OK |  |
| ADDRESS | NVARCHAR2(264) | NVARCHAR2(528) | NULL | NULL | ⚠️ CHANGED | Type: `NVARCHAR2(264)` → `NVARCHAR2(528)` |
| EMAIL | NVARCHAR2(200) | NVARCHAR2(400) | NULL | NULL | ⚠️ CHANGED | Type: `NVARCHAR2(200)` → `NVARCHAR2(400)` |
| COUNTRY | NVARCHAR2(64) | NVARCHAR2(128) | NULL | NULL | ⚠️ CHANGED | Type: `NVARCHAR2(64)` → `NVARCHAR2(128)` |
| FAX | NVARCHAR2(100) | NVARCHAR2(200) | NULL | NULL | ⚠️ CHANGED | Type: `NVARCHAR2(100)` → `NVARCHAR2(200)` |
| IS_PROPRIETARY | NUMBER(1,0) | NUMBER(1,0) | NULL | NULL | ✅ OK |  |
| IS_TAX_EXMP | NUMBER(1,0) | NUMBER(1,0) | NULL | NULL | ✅ OK |  |
| IS_POLITICAL_PERSON | CHAR(1) | — | NULL | — | ❌ REMOVED | Column missing from live DB |
| IS_DEFAULT | — | NUMBER(1,0) | — | NULL | 🆕 NEW COL | Column exists in live DB but not in schema card |
| APPROVAL_FLAG | — | NUMBER(3,0) | — | NULL | 🆕 NEW COL | Column exists in live DB but not in schema card |

### ATS.EXCHANGES

**Status:** ⚠️ Changed  

| Column | Schema Card Type | Live DB Type | Card Nullable | Live Nullable | Status | Notes |
|--------|-----------------|-------------|--------------|--------------|--------|-------|
| EXCHANGE_CODE | NVARCHAR2(8) | NVARCHAR2(24) | NOT NULL | NOT NULL | ⚠️ CHANGED | Type: `NVARCHAR2(8)` → `NVARCHAR2(24)` |
| EXCHANGE_NAME | NVARCHAR2(128) | NVARCHAR2(256) | NOT NULL | NOT NULL | ⚠️ CHANGED | Type: `NVARCHAR2(128)` → `NVARCHAR2(256)` |
| CONTACT_ENTITY_ID | NUMBER(10,0) | NUMBER(10,0) | NOT NULL | NOT NULL | ✅ OK | FK→ATS.CONTACT_ENTITIES(CONTACT_ENTITY_ID) |
| EXCHANGE_ID | NUMBER(4,0) | NUMBER(4,0) | NOT NULL | NOT NULL | ✅ OK | PK |
| CONNECTIVITY | NUMBER(1,0) | NUMBER(1,0) | NULL | NULL | ✅ OK | 0=CAPAZAR, 1=FIX |
| CREATION_DATE | DATE | DATE | NOT NULL | NOT NULL | ✅ OK |  |
| MODIFIED_BY | VARCHAR2(32) | VARCHAR2(32) | NOT NULL | NOT NULL | ✅ OK |  |
| MODIFIED_DATE | DATE | DATE | NOT NULL | NOT NULL | ✅ OK |  |
| ACTIVE | NUMBER(1,0) | NUMBER(1,0) | NOT NULL | NOT NULL | ✅ OK |  |
| DESCRIPTION | NVARCHAR2(500) | NVARCHAR2(1000) | NULL | NULL | ⚠️ CHANGED | Type: `NVARCHAR2(500)` → `NVARCHAR2(1000)` |
| MBO_DEPTH | NUMBER(4,0) | NUMBER(4,0) | NOT NULL | NOT NULL | ✅ OK |  |
| MBP_DEPTH | NUMBER(4,0) | NUMBER(4,0) | NOT NULL | NOT NULL | ✅ OK |  |
| ALLOW_SHORT_SELL | NUMBER(1,0) | NUMBER(1,0) | NOT NULL | NOT NULL | ✅ OK |  |
| CURRENCY_ID | NUMBER(4,0) | NUMBER(4,0) | NULL | NULL | ✅ OK | FK→ATS.CURRENCY(CURRENCY_ID) |

### ATS.FLAGS

**Status:** ⚠️ Changed  

| Column | Schema Card Type | Live DB Type | Card Nullable | Live Nullable | Status | Notes |
|--------|-----------------|-------------|--------------|--------------|--------|-------|
| FLAG_CODE | NVARCHAR2(20) | NVARCHAR2(40) | NOT NULL | NOT NULL | ⚠️ CHANGED | Type: `NVARCHAR2(20)` → `NVARCHAR2(40)` |
| DESC_ | NVARCHAR2(20) | NVARCHAR2(40) | NOT NULL | NOT NULL | ⚠️ CHANGED | Type: `NVARCHAR2(20)` → `NVARCHAR2(40)` |
| FLAG_ID | NUMBER(2,0) | NUMBER(2,0) | NOT NULL | NOT NULL | ✅ OK | PK |

### ATS.LEVIES

**Status:** ✅ Matched  

| Column | Schema Card Type | Live DB Type | Card Nullable | Live Nullable | Status | Notes |
|--------|-----------------|-------------|--------------|--------------|--------|-------|
| LEVY_ID | NUMBER(8,0) | NUMBER(8,0) | NOT NULL | NOT NULL | ✅ OK | PK |
| LEVY_CODE | VARCHAR2(32) | VARCHAR2(32) | NOT NULL | NOT NULL | ✅ OK |  |
| LEVY_NAME | VARCHAR2(128) | VARCHAR2(128) | NOT NULL | NOT NULL | ✅ OK |  |
| EFFECTIVE_FROM | DATE | DATE | NULL | NULL | ✅ OK |  |
| APPLIES_TO | VARCHAR2(4) | VARCHAR2(4) | NULL | NULL | ✅ OK |  |
| LEVY_TYPE_ID | NUMBER(3,0) | NUMBER(3,0) | NOT NULL | NOT NULL | ✅ OK | FK→ATS.LEVY_TYPES(ID) |
| EFFECTIVE_TO | DATE | DATE | NULL | NULL | ✅ OK |  |
| RECURRENCE_CODE | VARCHAR2(25) | VARCHAR2(25) | NOT NULL | NOT NULL | ✅ OK | FK→ATS.LEVY_RECURRENCE(RECURRENCE_CODE) |
| WITH_AGREEMENT | VARCHAR2(1) | VARCHAR2(1) | NULL | NULL | ✅ OK |  |
| LEVY_CATEGORY | VARCHAR2(12) | VARCHAR2(12) | NOT NULL | NOT NULL | ✅ OK |  |
| OWN_PORTFOLIO | VARCHAR2(1) | VARCHAR2(1) | NULL | NULL | ✅ OK |  |
| MAX_VALUE | NUMBER(15,4) | NUMBER(15,4) | NULL | NULL | ✅ OK |  |
| MIN_VALUE | NUMBER(15,4) | NUMBER(15,4) | NULL | NULL | ✅ OK |  |
| MARKET_ID | NUMBER(10,0) | NUMBER(10,0) | NULL | NULL | ✅ OK | FK→ATS.MARKETS(MARKET_ID) |
| FOREIGN_CURRENCY_BOND | NUMBER(1,0) | NUMBER(1,0) | NULL | NULL | ✅ OK |  |

### ATS.LEVY_CRITERIA

**Status:** ✅ Matched  

| Column | Schema Card Type | Live DB Type | Card Nullable | Live Nullable | Status | Notes |
|--------|-----------------|-------------|--------------|--------------|--------|-------|
| ID | NUMBER | NUMBER | NOT NULL | NOT NULL | ✅ OK | PK |
| CRITERIA_CODE | VARCHAR2(20) | VARCHAR2(20) | NOT NULL | NOT NULL | ✅ OK |  |
| DESCREPTION | VARCHAR2(25) | VARCHAR2(25) | NULL | NULL | ✅ OK | Typo in schema card (DESCREPTION) |

### ATS.LEVY_INFO

**Status:** ✅ Matched  

| Column | Schema Card Type | Live DB Type | Card Nullable | Live Nullable | Status | Notes |
|--------|-----------------|-------------|--------------|--------------|--------|-------|
| LEVY_ID | NUMBER(8,0) | NUMBER(8,0) | NOT NULL | NOT NULL | ✅ OK | PK, FK→ATS.LEVIES(LEVY_ID) |
| VALUE_TYPE | VARCHAR2(10) | VARCHAR2(10) | NOT NULL | NOT NULL | ✅ OK |  |
| VALUE | NUMBER(14,4) | NUMBER(14,4) | NOT NULL | NOT NULL | ✅ OK |  |
| MIN_VALUE | NUMBER(14,4) | NUMBER(14,4) | NULL | NULL | ✅ OK |  |
| MAX_VALUE | NUMBER(14,4) | NUMBER(14,4) | NULL | NULL | ✅ OK |  |
| PERCENT_OFF | NUMBER | NUMBER | NULL | NULL | ✅ OK | FK→ATS.LEVY_PERCENT_OFF(ID) |

### ATS.LEVY_MEMBER_TYPES

**Status:** ✅ Matched  

| Column | Schema Card Type | Live DB Type | Card Nullable | Live Nullable | Status | Notes |
|--------|-----------------|-------------|--------------|--------------|--------|-------|
| ID | NUMBER(5,0) | NUMBER(5,0) | NULL | NULL | ✅ OK |  |
| MEMBER_TYPE_ID | NUMBER(5,0) | NUMBER(5,0) | NULL | NULL | ✅ OK | FK→ATS.BROKER_TYPES(BROKER_TYPE_ID) |
| LEVY_ID | NUMBER(5,0) | NUMBER(5,0) | NULL | NULL | ✅ OK | FK→ATS.LEVIES(LEVY_ID) |
| ACTIVE | NUMBER(1,0) | NUMBER(1,0) | NULL | NULL | ✅ OK |  |

### ATS.LEVY_RANGES

**Status:** ✅ Matched  

| Column | Schema Card Type | Live DB Type | Card Nullable | Live Nullable | Status | Notes |
|--------|-----------------|-------------|--------------|--------------|--------|-------|
| LEVY_RANGE_ID | NUMBER(8,0) | NUMBER(8,0) | NOT NULL | NOT NULL | ✅ OK | PK |
| LEVY_ID | NUMBER(8,0) | NUMBER(8,0) | NOT NULL | NOT NULL | ✅ OK | FK→ATS.LEVIES(LEVY_ID) |
| RANGE_FROM | NUMBER(15,4) | NUMBER(15,4) | NOT NULL | NOT NULL | ✅ OK |  |
| RANGE_TO | NUMBER(15,4) | NUMBER(15,4) | NOT NULL | NOT NULL | ✅ OK |  |
| FIXED_RATE | NUMBER(14,4) | NUMBER(14,4) | NULL | NULL | ✅ OK |  |
| LEVY_CRITERIA | NUMBER | NUMBER | NOT NULL | NOT NULL | ✅ OK | FK→ATS.LEVY_CRITERIA(ID) |
| VALUE_TYPE | VARCHAR2(10) | VARCHAR2(10) | NULL | NULL | ✅ OK |  |
| MIN_VALUE | NUMBER(14,4) | NUMBER(14,4) | NULL | NULL | ✅ OK |  |
| MAX_VALUE | NUMBER(14,4) | NUMBER(14,4) | NULL | NULL | ✅ OK |  |
| PERCENT_OFF | NUMBER(20,0) | NUMBER(20,0) | NULL | NULL | ✅ OK | FK→ATS.LEVY_PERCENT_OFF(ID) |
| PERCENT | NUMBER(7,4) | NUMBER(7,4) | NULL | NULL | ✅ OK |  |

### ATS.LEVY_SECURITIES

**Status:** ✅ Matched  

| Column | Schema Card Type | Live DB Type | Card Nullable | Live Nullable | Status | Notes |
|--------|-----------------|-------------|--------------|--------------|--------|-------|
| LEVY_ID | NUMBER(10,0) | NUMBER(10,0) | NULL | NULL | ✅ OK | FK→ATS.LEVIES(LEVY_ID) |
| BOND_TYPE_ID | NUMBER(10,0) | NUMBER(10,0) | NULL | NULL | ✅ OK |  |
| BOND_CATEGORY_ID | NUMBER(10,0) | NUMBER(10,0) | NULL | NULL | ✅ OK | FK→ATS.BOND_CATEGORY(ID) |
| ID | NUMBER(10,0) | NUMBER(10,0) | NULL | NULL | ✅ OK |  |

### ATS.LEVY_TYPES

**Status:** ✅ Matched  

| Column | Schema Card Type | Live DB Type | Card Nullable | Live Nullable | Status | Notes |
|--------|-----------------|-------------|--------------|--------------|--------|-------|
| ID | NUMBER(3,0) | NUMBER(3,0) | NOT NULL | NOT NULL | ✅ OK | PK |
| CODE | VARCHAR2(20) | VARCHAR2(20) | NULL | NULL | ✅ OK |  |
| DESCRIPTION | VARCHAR2(64) | VARCHAR2(64) | NULL | NULL | ✅ OK |  |

### ATS.NEGOTIATED_TRADES

**Status:** ⚠️ Changed  
**Grain (from card):** negotiation_event  
**Date Key:** ENTRY_DATETIME  
**New columns (live DB only):** PRINCIPAL_AMOUNT, INVESTMENT_AMOUNT, SETTLEMENT_DATE, DISCOUNT_RATE  

| Column | Schema Card Type | Live DB Type | Card Nullable | Live Nullable | Status | Notes |
|--------|-----------------|-------------|--------------|--------------|--------|-------|
| ENTRY_DATETIME | TIMESTAMP(6) | TIMESTAMP(6) | NOT NULL | NOT NULL | ✅ OK |  |
| ORDER_NO | NUMBER(10,0) | NUMBER(10,0) | NOT NULL | NOT NULL | ✅ OK |  |
| VOLUME | NUMBER(10,0) | NUMBER(10,0) | NOT NULL | NOT NULL | ✅ OK |  |
| PRICE | NUMBER(14,4) | NUMBER(14,4) | NOT NULL | NOT NULL | ✅ OK |  |
| IS_SHORT | NVARCHAR2(1) | NVARCHAR2(2) | NOT NULL | NOT NULL | ⚠️ CHANGED | Type: `NVARCHAR2(1)` → `NVARCHAR2(2)` |
| DISCLOSED_VOLUME | NUMBER(10,0) | NUMBER(10,0) | NOT NULL | NOT NULL | ✅ OK |  |
| SIDE | NVARCHAR2(1) | NVARCHAR2(2) | NOT NULL | NOT NULL | ⚠️ CHANGED | Type: `NVARCHAR2(1)` → `NVARCHAR2(2)` |
| TIF | DATE | DATE | NULL | NULL | ✅ OK |  |
| REF_NO | VARCHAR2(20) | VARCHAR2(20) | NULL | NULL | ✅ OK |  |
| TRIGGER_PRICE | NUMBER(14,4) | NUMBER(14,4) | NOT NULL | NOT NULL | ✅ OK |  |
| TRAILING_STOPLOSS_DIP | NUMBER(14,4) | NUMBER(14,4) | NOT NULL | NOT NULL | ✅ OK |  |
| CLIENT_ID | NUMBER(20,0) | NUMBER(20,0) | NOT NULL | NOT NULL | ✅ OK |  |
| FLAG_ID | NUMBER(2,0) | NUMBER(2,0) | NULL | NULL | ✅ OK |  |
| SYMBOL_ID | NUMBER(15,0) | NUMBER(15,0) | NOT NULL | NOT NULL | ✅ OK |  |
| MARKET_ID | NUMBER(4,0) | NUMBER(4,0) | NOT NULL | NOT NULL | ✅ OK |  |
| EXCHANGE_ID | NUMBER(4,0) | NUMBER(4,0) | NOT NULL | NOT NULL | ✅ OK |  |
| BROKER_ID | NUMBER(5,0) | NUMBER(5,0) | NOT NULL | NOT NULL | ✅ OK |  |
| USER_ID | NUMBER(30,0) | NUMBER(30,0) | NOT NULL | NOT NULL | ✅ OK |  |
| STATE | NUMBER(1,0) | NUMBER(1,0) | NOT NULL | NOT NULL | ✅ OK |  |
| TRADER_ID | NUMBER(30,0) | NUMBER(30,0) | NULL | NULL | ✅ OK |  |
| ORDER_TYPE | NUMBER(1,0) | NUMBER(1,0) | NOT NULL | NOT NULL | ✅ OK |  |
| COUNTER_ORDER_NO | NUMBER(10,0) | NUMBER(10,0) | NOT NULL | NOT NULL | ✅ OK |  |
| COUNTER_USER_ID | NUMBER(30,0) | NUMBER(30,0) | NOT NULL | NOT NULL | ✅ OK |  |
| COUNTER_CLIENT_ID | NUMBER(20,0) | NUMBER(20,0) | NULL | NULL | ✅ OK |  |
| COUNTER_BROKER_ID | NUMBER(5,0) | NUMBER(5,0) | NOT NULL | NOT NULL | ✅ OK |  |
| NEGOTIATED_STATE | NUMBER(1,0) | NUMBER(1,0) | NOT NULL | NOT NULL | ✅ OK |  |
| PRICE_TYPE | NUMBER(1,0) | NUMBER(1,0) | NOT NULL | NOT NULL | ✅ OK |  |
| CUSTODIAN_ID | NUMBER(20,0) | NUMBER(20,0) | NOT NULL | NOT NULL | ✅ OK |  |
| COUNTER_CUSTODIAN_ID | NUMBER(20,0) | NUMBER(20,0) | NULL | NULL | ✅ OK |  |
| YIELD | NUMBER(15,4) | NUMBER(15,4) | NULL | NULL | ✅ OK |  |
| ACCRUED_PROFIT | NUMBER(16,4) | NUMBER(16,4) | NULL | NULL | ✅ OK |  |
| VALUE | NUMBER(20,4) | NUMBER(20,4) | NULL | NULL | ✅ OK |  |
| PRICING_MECHANISM | NUMBER(1,0) | NUMBER(1,0) | NULL | NULL | ✅ OK |  |
| SETTLEMENT_TYPE_ID | NUMBER(4,0) | NUMBER(4,0) | NULL | NULL | ✅ OK |  |
| SWIFT_REF_NO | VARCHAR2(20) | VARCHAR2(20) | NULL | NULL | ✅ OK |  |
| NEGOTIATED_STATUS | NUMBER(1,0) | NUMBER(1,0) | NULL | NULL | ✅ OK |  |
| INTERNAL_REF_NO | VARCHAR2(25) | VARCHAR2(25) | NULL | NULL | ✅ OK |  |
| PRINCIPAL_AMOUNT | — | NUMBER(10,0) | — | NOT NULL | 🆕 NEW COL | Column exists in live DB but not in schema card |
| INVESTMENT_AMOUNT | — | NUMBER(15,4) | — | NULL | 🆕 NEW COL | Column exists in live DB but not in schema card |
| SETTLEMENT_DATE | — | DATE | — | NULL | 🆕 NEW COL | Column exists in live DB but not in schema card |
| DISCOUNT_RATE | — | NUMBER(14,4) | — | NULL | 🆕 NEW COL | Column exists in live DB but not in schema card |

### ATS.ORDERS

**Status:** ⚠️ Changed  
**Grain (from card):** order_event  
**Date Key:** ENTRY_DATETIME  
**New columns (live DB only):** ACCOUNT_CATEGORY, DISCOUNT_RATE  

| Column | Schema Card Type | Live DB Type | Card Nullable | Live Nullable | Status | Notes |
|--------|-----------------|-------------|--------------|--------------|--------|-------|
| ENTRY_DATETIME | TIMESTAMP(6) | TIMESTAMP(6) | NOT NULL | NOT NULL | ✅ OK | PK |
| ORDER_NO | NUMBER(10,0) | NUMBER(10,0) | NOT NULL | NOT NULL | ✅ OK | PK |
| VOLUME | NUMBER(10,0) | NUMBER(10,0) | NOT NULL | NOT NULL | ✅ OK |  |
| PRICE | NUMBER(14,4) | NUMBER(14,4) | NOT NULL | NOT NULL | ✅ OK |  |
| IS_SHORT | NVARCHAR2(1) | NVARCHAR2(2) | NOT NULL | NOT NULL | ⚠️ CHANGED | Type: `NVARCHAR2(1)` → `NVARCHAR2(2)` |
| DISCLOSED_VOLUME | NUMBER(10,0) | NUMBER(10,0) | NOT NULL | NOT NULL | ✅ OK |  |
| SIDE | NVARCHAR2(1) | NVARCHAR2(2) | NOT NULL | NOT NULL | ⚠️ CHANGED | Type: `NVARCHAR2(1)` → `NVARCHAR2(2)` |
| TIF | DATE | DATE | NULL | NULL | ✅ OK |  |
| REF_NO | VARCHAR2(20) | VARCHAR2(20) | NULL | NULL | ✅ OK |  |
| TRIGGER_PRICE | NUMBER(14,4) | NUMBER(14,4) | NOT NULL | NOT NULL | ✅ OK |  |
| TRAILING_STOPLOSS_DIP | NUMBER(14,4) | NUMBER(14,4) | NOT NULL | NOT NULL | ✅ OK |  |
| CLIENT_ID | NUMBER(20,0) | NUMBER(20,0) | NOT NULL | NOT NULL | ✅ OK | FK→ATS.EDS_CLIENTS(CLIENT_ID) |
| FLAG_ID | NUMBER(2,0) | NUMBER(2,0) | NULL | NULL | ✅ OK | FK→ATS.FLAGS(FLAG_ID) |
| SYMBOL_ID | NUMBER(15,0) | NUMBER(15,0) | NOT NULL | NOT NULL | ✅ OK | PK, FK→ATS.SYMBOL_MARKETS(SYMBOL_ID) |
| MARKET_ID | NUMBER(4,0) | NUMBER(4,0) | NOT NULL | NOT NULL | ✅ OK | PK, FK→ATS.SYMBOL_MARKETS(MARKET_ID) |
| EXCHANGE_ID | NUMBER(4,0) | NUMBER(4,0) | NOT NULL | NOT NULL | ✅ OK | PK, FK→ATS.SYMBOL_MARKETS(EXCHANGE_ID) |
| BROKER_ID | NUMBER(5,0) | NUMBER(5,0) | NOT NULL | NOT NULL | ✅ OK | FK→ATS.SUBSCRIBED_BROKERS(BROKER_ID) |
| USER_ID | NUMBER(30,0) | NUMBER(30,0) | NOT NULL | NOT NULL | ✅ OK | FK→ATS.USERS(USER_ID) |
| STATE | NUMBER(1,0) | NUMBER(1,0) | NOT NULL | NOT NULL | ✅ OK |  |
| TRADER_ID | NUMBER(30,0) | NUMBER(30,0) | NULL | NULL | ✅ OK | FK→ATS.USERS(USER_ID) |
| ORDER_TYPE | NUMBER(1,0) | NUMBER(1,0) | NOT NULL | NOT NULL | ✅ OK |  |
| PRICE_TYPE | NUMBER(1,0) | NUMBER(1,0) | NOT NULL | NOT NULL | ✅ OK |  |
| STATE_TIME | TIMESTAMP(6) | TIMESTAMP(6) | NULL | NULL | ✅ OK |  |
| QUOTE_ID | NUMBER(10,0) | NUMBER(10,0) | NULL | NULL | ✅ OK |  |
| CUSTODIAN_ID | NUMBER(20,0) | NUMBER(20,0) | NULL | NULL | ✅ OK |  |
| MF_VOLUME | NUMBER(10,0) | NUMBER(10,0) | NULL | NULL | ✅ OK |  |
| QUEUING_TIME | TIMESTAMP(6) | TIMESTAMP(6) | NULL | NULL | ✅ OK |  |
| FIX_SESSION | VARCHAR2(200) | VARCHAR2(200) | NULL | NULL | ✅ OK |  |
| ORIGINATOR | NUMBER(1,0) | NUMBER(1,0) | NULL | NULL | ✅ OK |  |
| YIELD | NUMBER(15,4) | NUMBER(15,4) | NULL | NULL | ✅ OK |  |
| ACCRUED_PROFIT | NUMBER(24,6) | NUMBER(24,6) | NULL | NULL | ✅ OK |  |
| VALUE | NUMBER(24,6) | NUMBER(24,6) | NULL | NULL | ✅ OK |  |
| PRICING_MECHANISM | NUMBER(1,0) | NUMBER(1,0) | NULL | NULL | ✅ OK |  |
| SWIFT_REF_NO | VARCHAR2(20) | VARCHAR2(20) | NULL | NULL | ✅ OK |  |
| INTERNAL_REF_NO | VARCHAR2(25) | VARCHAR2(25) | NULL | NULL | ✅ OK |  |
| ACTUAL_VOLUME | NUMBER(10,0) | NUMBER(10,0) | NOT NULL | NOT NULL | ✅ OK |  |
| ACCOUNT_CATEGORY | — | VARCHAR2(50) | — | NULL | 🆕 NEW COL | Column exists in live DB but not in schema card |
| DISCOUNT_RATE | — | NUMBER(14,4) | — | NULL | 🆕 NEW COL | Column exists in live DB but not in schema card |

### ATS.ORDER_STATES

**Status:** ✅ Matched  

| Column | Schema Card Type | Live DB Type | Card Nullable | Live Nullable | Status | Notes |
|--------|-----------------|-------------|--------------|--------------|--------|-------|
| STATE_ID | NUMBER(2,0) | NUMBER(2,0) | NOT NULL | NOT NULL | ✅ OK | PK |
| STATE_CODE | VARCHAR2(32) | VARCHAR2(32) | NOT NULL | NOT NULL | ✅ OK |  |

### ATS.ORDER_TYPES

**Status:** ✅ Matched  

| Column | Schema Card Type | Live DB Type | Card Nullable | Live Nullable | Status | Notes |
|--------|-----------------|-------------|--------------|--------------|--------|-------|
| ID | NUMBER(4,0) | NUMBER(4,0) | NOT NULL | NOT NULL | ✅ OK | PK |
| CODE | VARCHAR2(20) | VARCHAR2(20) | NOT NULL | NOT NULL | ✅ OK |  |
| DESCRIPTION | VARCHAR2(100) | VARCHAR2(100) | NULL | NULL | ✅ OK |  |

### ATS.REJECTED_ORDERS

**Status:** ⚠️ Changed  
**Grain (from card):** rejection_event  
**Date Key:** ENTRY_DATETIME  
**New columns (live DB only):** DISCOUNT_RATE  

| Column | Schema Card Type | Live DB Type | Card Nullable | Live Nullable | Status | Notes |
|--------|-----------------|-------------|--------------|--------------|--------|-------|
| ENTRY_DATETIME | TIMESTAMP(6) | TIMESTAMP(6) | NOT NULL | NOT NULL | ✅ OK |  |
| ORDER_NO | NUMBER(10,0) | NUMBER(10,0) | NOT NULL | NOT NULL | ✅ OK |  |
| VOLUME | NUMBER(10,0) | NUMBER(10,0) | NOT NULL | NOT NULL | ✅ OK |  |
| PRICE | NUMBER(14,4) | NUMBER(14,4) | NOT NULL | NOT NULL | ✅ OK |  |
| IS_SHORT | NVARCHAR2(1) | NVARCHAR2(2) | NOT NULL | NOT NULL | ⚠️ CHANGED | Type: `NVARCHAR2(1)` → `NVARCHAR2(2)` |
| DISCLOSED_VOLUME | NUMBER(10,0) | NUMBER(10,0) | NOT NULL | NOT NULL | ✅ OK |  |
| SIDE | NVARCHAR2(1) | NVARCHAR2(2) | NOT NULL | NOT NULL | ⚠️ CHANGED | Type: `NVARCHAR2(1)` → `NVARCHAR2(2)` |
| TIF | DATE | DATE | NULL | NULL | ✅ OK |  |
| REF_NO | VARCHAR2(20) | VARCHAR2(20) | NULL | NULL | ✅ OK |  |
| TRIGGER_PRICE | NUMBER(14,4) | NUMBER(14,4) | NOT NULL | NOT NULL | ✅ OK |  |
| TRAILING_STOPLOSS_DIP | NUMBER(14,4) | NUMBER(14,4) | NOT NULL | NOT NULL | ✅ OK |  |
| CLIENT_ID | NUMBER(20,0) | NUMBER(20,0) | NOT NULL | NOT NULL | ✅ OK |  |
| FLAG_ID | NUMBER(2,0) | NUMBER(2,0) | NULL | NULL | ✅ OK |  |
| SYMBOL_ID | NUMBER(15,0) | NUMBER(15,0) | NOT NULL | NOT NULL | ✅ OK |  |
| MARKET_ID | NUMBER(4,0) | NUMBER(4,0) | NOT NULL | NOT NULL | ✅ OK |  |
| EXCHANGE_ID | NUMBER(4,0) | NUMBER(4,0) | NOT NULL | NOT NULL | ✅ OK |  |
| BROKER_ID | NUMBER(5,0) | NUMBER(5,0) | NOT NULL | NOT NULL | ✅ OK |  |
| USER_ID | NUMBER(30,0) | NUMBER(30,0) | NOT NULL | NOT NULL | ✅ OK |  |
| STATE | NUMBER(1,0) | NUMBER(1,0) | NOT NULL | NOT NULL | ✅ OK |  |
| TRADER_ID | NUMBER(30,0) | NUMBER(30,0) | NULL | NULL | ✅ OK |  |
| ORDER_TYPE | NUMBER(1,0) | NUMBER(1,0) | NOT NULL | NOT NULL | ✅ OK |  |
| PRICE_TYPE | NUMBER(1,0) | NUMBER(1,0) | NOT NULL | NOT NULL | ✅ OK |  |
| REJECTION_ID | NUMBER(2,0) | NUMBER(2,0) | NULL | NULL | ✅ OK |  |
| SOURCE_ID | NUMBER(2,0) | NUMBER(2,0) | NULL | NULL | ✅ OK |  |
| STATE_TIME | TIMESTAMP(6) | TIMESTAMP(6) | NULL | NULL | ✅ OK |  |
| QUOTE_ID | NUMBER(10,0) | NUMBER(10,0) | NULL | NULL | ✅ OK |  |
| CUSTODIAN_ID | NUMBER(20,0) | NUMBER(20,0) | NULL | NULL | ✅ OK |  |
| YIELD | NUMBER(15,4) | NUMBER(15,4) | NULL | NULL | ✅ OK |  |
| ACCRUED_PROFIT | NUMBER(16,4) | NUMBER(16,4) | NULL | NULL | ✅ OK |  |
| VALUE | NUMBER(20,4) | NUMBER(20,4) | NULL | NULL | ✅ OK |  |
| PRICING_MECHANISM | NUMBER(1,0) | NUMBER(1,0) | NULL | NULL | ✅ OK |  |
| CLIENT_CODE | NVARCHAR2(30) | NVARCHAR2(60) | NULL | NULL | ⚠️ CHANGED | Type: `NVARCHAR2(30)` → `NVARCHAR2(60)` |
| INTERNAL_REF_NO | VARCHAR2(25) | VARCHAR2(25) | NULL | NULL | ✅ OK |  |
| ACTUAL_VOLUME | NUMBER(10,0) | NUMBER(10,0) | NOT NULL | NOT NULL | ✅ OK |  |
| DISCOUNT_RATE | — | NUMBER(14,4) | — | NULL | 🆕 NEW COL | Column exists in live DB but not in schema card |

### ATS.REJECTIONS

**Status:** ✅ Matched  

| Column | Schema Card Type | Live DB Type | Card Nullable | Live Nullable | Status | Notes |
|--------|-----------------|-------------|--------------|--------------|--------|-------|
| REJECTION_ID | NUMBER(2,0) | NUMBER(2,0) | NOT NULL | NOT NULL | ✅ OK | PK |
| DESCRIPTION | VARCHAR2(250) | VARCHAR2(250) | NOT NULL | NOT NULL | ✅ OK |  |

### ATS.REPO_CONTRACTS

**Status:** ⚠️ Changed  
**Grain (from card):** repo_leg  
**Date Key:** ENTRY_DATETIME  
**New columns (live DB only):** ID, TENOR_OPTION_ID, TENOR_DAYS, DEPO_STATUS  
**Removed columns (card only):** NEW_CONTARCT_ID  

| Column | Schema Card Type | Live DB Type | Card Nullable | Live Nullable | Status | Notes |
|--------|-----------------|-------------|--------------|--------------|--------|-------|
| ENTRY_DATETIME | TIMESTAMP(6) | TIMESTAMP(6) | NULL | NULL | ✅ OK |  |
| CONTRACT_NO | VARCHAR2(25) | VARCHAR2(25) | NULL | NULL | ✅ OK |  |
| SELLER_ORDER_NO | NUMBER(10,0) | NUMBER(10,0) | NULL | NULL | ✅ OK |  |
| BUYER_ORDER_NO | NUMBER(10,0) | NUMBER(10,0) | NULL | NULL | ✅ OK |  |
| PRICE | NUMBER(16,4) | NUMBER(14,4) | NULL | NULL | ⚠️ CHANGED | Type: `NUMBER(16,4)` → `NUMBER(14,4)` |
| VOLUME | NUMBER(10,0) | NUMBER(10,0) | NULL | NULL | ✅ OK |  |
| EXCHANGE_ID | NUMBER(4,0) | NUMBER(4,0) | NULL | NULL | ✅ OK |  |
| BUYER_CLIENT_ID | NUMBER(20,0) | NUMBER(20,0) | NULL | NULL | ✅ OK |  |
| SELLER_CLIENT_ID | NUMBER(20,0) | NUMBER(20,0) | NULL | NULL | ✅ OK |  |
| SYMBOL_ID | NUMBER(15,0) | NUMBER(15,0) | NULL | NULL | ✅ OK |  |
| MARKET_ID | NUMBER(4,0) | NUMBER(4,0) | NULL | NULL | ✅ OK |  |
| BUYER_BROKER_ID | NUMBER(5,0) | NUMBER(5,0) | NULL | NULL | ✅ OK |  |
| SELLER_BROKER_ID | NUMBER(5,0) | NUMBER(5,0) | NULL | NULL | ✅ OK |  |
| BUYER_USER_ID | NUMBER(30,0) | NUMBER(30,0) | NULL | NULL | ✅ OK |  |
| SELLER_USER_ID | NUMBER(30,0) | NUMBER(30,0) | NULL | NULL | ✅ OK |  |
| TRADE_TYPE | NUMBER(1,0) | NUMBER(1,0) | NULL | NULL | ✅ OK |  |
| STATE_ID | NUMBER(2,0) | NUMBER(2,0) | NULL | NULL | ✅ OK |  |
| BUYER_REMAINING_VOLUME | NUMBER(10,0) | NUMBER(10,0) | NULL | NULL | ✅ OK |  |
| SELLER_REMAINING_VOLUME | NUMBER(10,0) | NUMBER(10,0) | NULL | NULL | ✅ OK |  |
| BUYER_CUSTODIAN_ID | NUMBER(20,0) | NUMBER(20,0) | NULL | NULL | ✅ OK |  |
| SELLER_CUSTODIAN_ID | NUMBER(20,0) | NUMBER(20,0) | NULL | NULL | ✅ OK |  |
| ACCRUED_PROFIT | NUMBER(16,4) | NUMBER(16,4) | NULL | NULL | ✅ OK |  |
| YIELD | NUMBER(15,4) | NUMBER(15,4) | NULL | NULL | ✅ OK |  |
| VALUE | NUMBER(20,4) | NUMBER(20,4) | NULL | NULL | ✅ OK |  |
| PRICING_MECHANISM | NUMBER(1,0) | NUMBER(1,0) | NULL | NULL | ✅ OK |  |
| PRICING_MODEL | NUMBER(1,0) | NUMBER(1,0) | NULL | NULL | ✅ OK |  |
| SETTLEMENT_TYPE_ID | NUMBER(4,0) | NUMBER(4,0) | NULL | NULL | ✅ OK |  |
| SETTLEMENT_AMOUNT | NUMBER(20,4) | NUMBER(20,4) | NULL | NULL | ✅ OK |  |
| LEG | NUMBER(1,0) | NUMBER(1,0) | NULL | NULL | ✅ OK |  |
| TERMINATION_DATE | DATE | DATE | NULL | NULL | ✅ OK |  |
| REPURCHASE_PRICE | NUMBER(16,4) | NUMBER(14,4) | NULL | NULL | ⚠️ CHANGED | Type: `NUMBER(16,4)` → `NUMBER(14,4)` |
| TICKET_NO | NUMBER(10,0) | NUMBER(10,0) | NULL | NULL | ✅ OK |  |
| INITIAL_DATE | DATE | DATE | NULL | NULL | ✅ OK |  |
| TRADE_STATE | VARCHAR2(32) | VARCHAR2(32) | NULL | NULL | ✅ OK |  |
| IS_PROCESSED | VARCHAR2(1) | VARCHAR2(1) | NULL | NULL | ✅ OK |  |
| DIRTY_PRICE | NUMBER(16,4) | NUMBER(14,4) | NULL | NULL | ⚠️ CHANGED | Type: `NUMBER(16,4)` → `NUMBER(14,4)` |
| REPO_TYPE | VARCHAR2(16) | VARCHAR2(16) | NULL | NULL | ✅ OK |  |
| REPURCHASE_ACCRUED_PROFIT | NUMBER(16,4) | NUMBER(16,4) | NULL | NULL | ✅ OK |  |
| REPURCHASE_SETTLEMENT_AMOUNT | NUMBER(20,4) | NUMBER(20,4) | NULL | NULL | ✅ OK |  |
| REPO_HAIRCUT | NUMBER(8,4) | NUMBER(8,4) | NULL | NULL | ✅ OK |  |
| REPURCHASE_DIRTY_PRICE | NUMBER(16,4) | NUMBER(14,4) | NULL | NULL | ⚠️ CHANGED | Type: `NUMBER(16,4)` → `NUMBER(14,4)` |
| REPO_RATE | NUMBER(16,4) | NUMBER(8,4) | NULL | NULL | ⚠️ CHANGED | Type: `NUMBER(16,4)` → `NUMBER(8,4)` |
| PREVIOUS_CONTRACT_NO | VARCHAR2(25) | VARCHAR2(25) | NULL | NULL | ✅ OK |  |
| NEW_CONTRACT_ID | VARCHAR2(25) | VARCHAR2(25) | NULL | NULL | ✅ OK |  |
| CONTRACT_MODIFY_DATE | DATE | DATE | NULL | NULL | ✅ OK |  |
| PREVIOUS_REPURCHASE_AMOUNT | NUMBER(20,4) | NUMBER(20,4) | NULL | NULL | ✅ OK |  |
| PAR_VALUE | NUMBER(16,4) | NUMBER(16,4) | NULL | NULL | ✅ OK |  |
| MARKET_VALUE | NUMBER(20,4) | NUMBER(20,4) | NULL | NULL | ✅ OK |  |
| ACCRUED_DAYS | NUMBER | NUMBER | NULL | NULL | ✅ OK |  |
| NEW_CONTARCT_ID | VARCHAR2(25) | — | NULL | — | ❌ REMOVED | Column missing from live DB |
| ID | — | NUMBER(20,0) | — | NOT NULL | 🆕 NEW COL | Column exists in live DB but not in schema card |
| TENOR_OPTION_ID | — | NUMBER(5,0) | — | NULL | 🆕 NEW COL | Column exists in live DB but not in schema card |
| TENOR_DAYS | — | NUMBER(5,0) | — | NULL | 🆕 NEW COL | Column exists in live DB but not in schema card |
| DEPO_STATUS | — | VARCHAR2(15) | — | NULL | 🆕 NEW COL | Column exists in live DB but not in schema card |

### ATS.REPO_CONTRACTS_CANCELLED

**Status:** ✅ Matched  
**Grain (from card):** repo_cancel_leg  
**Date Key:** ENTRY_DATETIME  

| Column | Schema Card Type | Live DB Type | Card Nullable | Live Nullable | Status | Notes |
|--------|-----------------|-------------|--------------|--------------|--------|-------|
| ENTRY_DATETIME | TIMESTAMP(6) | TIMESTAMP(6) | NULL | NULL | ✅ OK |  |
| TRADE_DATETIME | TIMESTAMP(6) | TIMESTAMP(6) | NULL | NULL | ✅ OK |  |
| CONTRACT_NO | VARCHAR2(25) | VARCHAR2(25) | NULL | NULL | ✅ OK |  |
| SELLER_ORDER_NO | NUMBER(10,0) | NUMBER(10,0) | NULL | NULL | ✅ OK |  |
| BUYER_ORDER_NO | NUMBER(10,0) | NUMBER(10,0) | NULL | NULL | ✅ OK |  |
| PRICE | NUMBER(14,4) | NUMBER(14,4) | NULL | NULL | ✅ OK |  |
| VOLUME | NUMBER(10,0) | NUMBER(10,0) | NULL | NULL | ✅ OK |  |
| EXCHANGE_ID | NUMBER(4,0) | NUMBER(4,0) | NULL | NULL | ✅ OK |  |
| BUYER_CLIENT_ID | NUMBER(20,0) | NUMBER(20,0) | NULL | NULL | ✅ OK |  |
| SELLER_CLIENT_ID | NUMBER(20,0) | NUMBER(20,0) | NULL | NULL | ✅ OK |  |
| SYMBOL_ID | NUMBER(15,0) | NUMBER(15,0) | NULL | NULL | ✅ OK |  |
| MARKET_ID | NUMBER(4,0) | NUMBER(4,0) | NULL | NULL | ✅ OK |  |
| BUYER_BROKER_ID | NUMBER(5,0) | NUMBER(5,0) | NULL | NULL | ✅ OK |  |
| SELLER_BROKER_ID | NUMBER(5,0) | NUMBER(5,0) | NULL | NULL | ✅ OK |  |
| BUYER_USER_ID | NUMBER(30,0) | NUMBER(30,0) | NULL | NULL | ✅ OK |  |
| SELLER_USER_ID | NUMBER(30,0) | NUMBER(30,0) | NULL | NULL | ✅ OK |  |
| TRADE_TYPE | NUMBER(1,0) | NUMBER(1,0) | NULL | NULL | ✅ OK |  |
| STATE_ID | NUMBER(2,0) | NUMBER(2,0) | NULL | NULL | ✅ OK |  |
| BUYER_REMAINING_VOLUME | NUMBER(10,0) | NUMBER(10,0) | NULL | NULL | ✅ OK |  |
| SELLER_REMAINING_VOLUME | NUMBER(10,0) | NUMBER(10,0) | NULL | NULL | ✅ OK |  |
| BUYER_CUSTODIAN_ID | NUMBER(20,0) | NUMBER(20,0) | NULL | NULL | ✅ OK |  |
| SELLER_CUSTODIAN_ID | NUMBER(20,0) | NUMBER(20,0) | NULL | NULL | ✅ OK |  |
| ACCRUED_PROFIT | NUMBER(16,4) | NUMBER(16,4) | NULL | NULL | ✅ OK |  |
| YIELD | NUMBER(15,4) | NUMBER(15,4) | NULL | NULL | ✅ OK |  |
| VALUE | NUMBER(15,4) | NUMBER(15,4) | NULL | NULL | ✅ OK |  |
| PRICING_MECHANISM | NUMBER(1,0) | NUMBER(1,0) | NULL | NULL | ✅ OK |  |
| PRICING_MODEL | NUMBER(1,0) | NUMBER(1,0) | NULL | NULL | ✅ OK |  |
| SETTLEMENT_TYPE_ID | NUMBER(4,0) | NUMBER(4,0) | NULL | NULL | ✅ OK |  |
| SETTLEMENT_AMOUNT | NUMBER(20,4) | NUMBER(20,4) | NULL | NULL | ✅ OK |  |
| LEG | NUMBER(1,0) | NUMBER(1,0) | NULL | NULL | ✅ OK |  |
| TERMINATION_DATE | DATE | DATE | NULL | NULL | ✅ OK |  |
| REPURCHASE_PRICE | NUMBER(14,4) | NUMBER(14,4) | NULL | NULL | ✅ OK |  |
| TICKET_NO | NUMBER(10,0) | NUMBER(10,0) | NULL | NULL | ✅ OK |  |
| INITIAL_DATE | DATE | DATE | NULL | NULL | ✅ OK |  |
| TRADE_STATE | VARCHAR2(32) | VARCHAR2(32) | NULL | NULL | ✅ OK |  |
| IS_PROCESSED | VARCHAR2(1) | VARCHAR2(1) | NULL | NULL | ✅ OK |  |
| REPO_RATE | NUMBER(8,4) | NUMBER(8,4) | NULL | NULL | ✅ OK |  |
| DIRTY_PRICE | NUMBER(14,4) | NUMBER(14,4) | NULL | NULL | ✅ OK |  |
| REPO_TYPE | VARCHAR2(16) | VARCHAR2(16) | NULL | NULL | ✅ OK |  |
| REPURCHASE_ACCRUED_PROFIT | NUMBER(15,4) | NUMBER(15,4) | NULL | NULL | ✅ OK |  |
| REPURCHASE_SETTLEMENT_AMOUNT | NUMBER(20,4) | NUMBER(20,4) | NULL | NULL | ✅ OK |  |
| REPO_HAIRCUT | NUMBER(8,4) | NUMBER(8,4) | NULL | NULL | ✅ OK |  |
| REPURCHASE_DIRTY_PRICE | NUMBER(14,4) | NUMBER(14,4) | NULL | NULL | ✅ OK |  |
| PREVIOUS_CONTRACT_NO | VARCHAR2(25) | VARCHAR2(25) | NULL | NULL | ✅ OK |  |
| NEW_CONTRACT_ID | VARCHAR2(25) | VARCHAR2(25) | NULL | NULL | ✅ OK |  |
| CONTRACT_MODIFY_DATE | DATE | DATE | NULL | NULL | ✅ OK |  |
| PREVIOUS_REPURCHASE_AMOUNT | NUMBER(20,4) | NUMBER(20,4) | NULL | NULL | ✅ OK |  |
| PAR_VALUE | NUMBER(16,4) | NUMBER(16,4) | NULL | NULL | ✅ OK |  |
| MARKET_VALUE | NUMBER(20,4) | NUMBER(20,4) | NULL | NULL | ✅ OK |  |
| ACCRUED_DAYS | NUMBER | NUMBER | NULL | NULL | ✅ OK |  |

### ATS.REPO_LOG

**Status:** ⚠️ Changed  
**Grain (from card):** repo_log_event  
**Date Key:** ENTRY_DATETIME  
**New columns (live DB only):** TENOR_OPTION_ID, TENOR_DAYS  

| Column | Schema Card Type | Live DB Type | Card Nullable | Live Nullable | Status | Notes |
|--------|-----------------|-------------|--------------|--------------|--------|-------|
| ENTRY_DATETIME | TIMESTAMP(6) | TIMESTAMP(6) | NULL | NULL | ✅ OK |  |
| ORDER_NO | NUMBER(10,0) | NUMBER(10,0) | NULL | NULL | ✅ OK |  |
| VOLUME | NUMBER(10,0) | NUMBER(10,0) | NULL | NULL | ✅ OK |  |
| PRICE | NUMBER(16,4) | NUMBER(14,4) | NULL | NULL | ⚠️ CHANGED | Type: `NUMBER(16,4)` → `NUMBER(14,4)` |
| SIDE | NVARCHAR2(1) | NVARCHAR2(2) | NULL | NULL | ⚠️ CHANGED | Type: `NVARCHAR2(1)` → `NVARCHAR2(2)` |
| CONTRACT_ID | VARCHAR2(20) | VARCHAR2(20) | NULL | NULL | ✅ OK |  |
| CLIENT_ID | NUMBER(20,0) | NUMBER(20,0) | NULL | NULL | ✅ OK |  |
| SYMBOL_ID | NUMBER(15,0) | NUMBER(15,0) | NULL | NULL | ✅ OK |  |
| MARKET_ID | NUMBER(4,0) | NUMBER(4,0) | NULL | NULL | ✅ OK |  |
| EXCHANGE_ID | NUMBER(4,0) | NUMBER(4,0) | NULL | NULL | ✅ OK |  |
| BROKER_ID | NUMBER(5,0) | NUMBER(5,0) | NULL | NULL | ✅ OK |  |
| USER_ID | NUMBER(30,0) | NUMBER(30,0) | NULL | NULL | ✅ OK |  |
| PRIVATE_ORDER_STATE | NUMBER(2,0) | NUMBER(2,0) | NULL | NULL | ✅ OK |  |
| TRADER_ID | NUMBER(30,0) | NUMBER(30,0) | NULL | NULL | ✅ OK |  |
| ORDER_TYPE | NUMBER(1,0) | NUMBER(1,0) | NULL | NULL | ✅ OK |  |
| COUNTER_ORDER_NO | NUMBER(10,0) | NUMBER(10,0) | NULL | NULL | ✅ OK |  |
| COUNTER_USER_ID | NUMBER(30,0) | NUMBER(30,0) | NULL | NULL | ✅ OK |  |
| COUNTER_CLIENT_ID | NUMBER(20,0) | NUMBER(20,0) | NULL | NULL | ✅ OK |  |
| COUNTER_BROKER_ID | NUMBER(5,0) | NUMBER(5,0) | NULL | NULL | ✅ OK |  |
| NEGOTIATED_STATE | NUMBER(1,0) | NUMBER(1,0) | NULL | NULL | ✅ OK |  |
| CUSTODIAN_ID | NUMBER(20,0) | NUMBER(20,0) | NULL | NULL | ✅ OK |  |
| COUNTER_CUSTODIAN_ID | NUMBER(20,0) | NUMBER(20,0) | NULL | NULL | ✅ OK |  |
| YIELD | NUMBER(15,4) | NUMBER(15,4) | NULL | NULL | ✅ OK |  |
| ACCRUED_PROFIT | NUMBER(16,4) | NUMBER(16,4) | NULL | NULL | ✅ OK |  |
| VALUE | NUMBER(20,4) | NUMBER(20,4) | NULL | NULL | ✅ OK |  |
| PRICING_MECHANISM | NUMBER(1,0) | NUMBER(1,0) | NULL | NULL | ✅ OK |  |
| SETTLEMENT_TYPE_ID | NUMBER(4,0) | NUMBER(4,0) | NULL | NULL | ✅ OK |  |
| LEG | NUMBER(1,0) | NUMBER(1,0) | NULL | NULL | ✅ OK |  |
| TERMINATION_DATE | DATE | DATE | NULL | NULL | ✅ OK |  |
| REPURCHASE_PRICE | NUMBER(16,4) | NUMBER(14,4) | NULL | NULL | ⚠️ CHANGED | Type: `NUMBER(16,4)` → `NUMBER(14,4)` |
| PREVIOUS_REP_PRICE | NUMBER(16,4) | NUMBER(14,4) | NULL | NULL | ⚠️ CHANGED | Type: `NUMBER(16,4)` → `NUMBER(14,4)` |
| REF_NO | VARCHAR2(12) | VARCHAR2(12) | NULL | NULL | ✅ OK |  |
| INITIATOR | NUMBER(1,0) | NUMBER(1,0) | NULL | NULL | ✅ OK |  |
| INITIAL_DATE | DATE | DATE | NULL | NULL | ✅ OK |  |
| PUBLIC_ORDER_STATE | NUMBER(2,0) | NUMBER(2,0) | NULL | NULL | ✅ OK |  |
| NEGOTIATED_STATUS | NUMBER(1,0) | NUMBER(1,0) | NULL | NULL | ✅ OK |  |
| REPO_RATE | NUMBER(8,4) | NUMBER(8,4) | NULL | NULL | ✅ OK |  |
| SETTLEMENT_AMOUNT | NUMBER(20,4) | NUMBER(20,4) | NULL | NULL | ✅ OK |  |
| DIRTY_PRICE | NUMBER(16,4) | NUMBER(14,4) | NULL | NULL | ⚠️ CHANGED | Type: `NUMBER(16,4)` → `NUMBER(14,4)` |
| REPO_TYPE | VARCHAR2(16) | VARCHAR2(16) | NULL | NULL | ✅ OK |  |
| REPURCHASE_ACCRUED_PROFIT | NUMBER(16,4) | NUMBER(16,4) | NULL | NULL | ✅ OK |  |
| REPURCHASE_SETTLEMENT_AMOUNT | NUMBER(20,4) | NUMBER(20,4) | NULL | NULL | ✅ OK |  |
| REPO_HAIRCUT | NUMBER(8,4) | NUMBER(8,4) | NULL | NULL | ✅ OK |  |
| REPURCHASE_DIRTY_PRICE | NUMBER(16,4) | NUMBER(14,4) | NULL | NULL | ⚠️ CHANGED | Type: `NUMBER(16,4)` → `NUMBER(14,4)` |
| NEW_CONTRACT_ID | VARCHAR2(25) | VARCHAR2(25) | NULL | NULL | ✅ OK |  |
| CONTRACT_MODIFY_DATE | DATE | DATE | NULL | NULL | ✅ OK |  |
| PREVIOUS_REPURCHASE_AMOUNT | NUMBER(20,4) | NUMBER(20,4) | NULL | NULL | ✅ OK |  |
| PAR_VALUE | NUMBER(16,4) | NUMBER(16,4) | NULL | NULL | ✅ OK |  |
| MARKET_VALUE | NUMBER(20,4) | NUMBER(20,4) | NULL | NULL | ✅ OK |  |
| ACCRUED_DAYS | NUMBER | NUMBER | NULL | NULL | ✅ OK |  |
| FIX_REF_NO | VARCHAR2(20) | VARCHAR2(20) | NULL | NULL | ✅ OK |  |
| ORIGINATOR | NUMBER(1,0) | NUMBER(1,0) | NULL | NULL | ✅ OK |  |
| FIX_SESSION | VARCHAR2(200) | VARCHAR2(200) | NULL | NULL | ✅ OK |  |
| TENOR_OPTION_ID | — | NUMBER(5,0) | — | NULL | 🆕 NEW COL | Column exists in live DB but not in schema card |
| TENOR_DAYS | — | NUMBER(5,0) | — | NULL | 🆕 NEW COL | Column exists in live DB but not in schema card |

### ATS.SETTLEMENT_LEVY_DATA

**Status:** ✅ Matched  
**Grain (from card):** levy_settlement_event  
**Date Key:** TRANSACTION_DATE  

| Column | Schema Card Type | Live DB Type | Card Nullable | Live Nullable | Status | Notes |
|--------|-----------------|-------------|--------------|--------------|--------|-------|
| TRANSACTION_ID | NUMBER(14,0) | NUMBER(14,0) | NULL | NULL | ✅ OK |  |
| TRANSACTION_DATE | DATE | DATE | NULL | NULL | ✅ OK |  |
| TICKET_NO | NUMBER(10,0) | NUMBER(10,0) | NULL | NULL | ✅ OK |  |
| PRICE | NUMBER(14,4) | NUMBER(14,4) | NULL | NULL | ✅ OK |  |
| VOLUME | NUMBER(10,0) | NUMBER(10,0) | NULL | NULL | ✅ OK |  |
| AMOUNT | NUMBER(15,4) | NUMBER(15,4) | NULL | NULL | ✅ OK |  |
| BROKER_ID | NUMBER(5,0) | NUMBER(5,0) | NULL | NULL | ✅ OK |  |
| CLIENT_ID | NUMBER(20,0) | NUMBER(20,0) | NULL | NULL | ✅ OK |  |
| LEVY_AMOUNT | NUMBER(14,4) | NUMBER(14,4) | NULL | NULL | ✅ OK |  |
| LEVY_ID | NUMBER(8,0) | NUMBER(8,0) | NULL | NULL | ✅ OK |  |
| BUY_SELL | VARCHAR2(1) | VARCHAR2(1) | NULL | NULL | ✅ OK |  |
| MARKET | VARCHAR2(14) | VARCHAR2(14) | NULL | NULL | ✅ OK |  |
| LEVY_ACCOUNT | VARCHAR2(30) | VARCHAR2(30) | NULL | NULL | ✅ OK |  |
| LEVY_ENTRY_DATE | TIMESTAMP(6) | TIMESTAMP(6) | NULL | NULL | ✅ OK |  |
| ENTRY_USER | VARCHAR2(30) | VARCHAR2(30) | NULL | NULL | ✅ OK |  |

### ATS.SETTLEMENT_TYPES

**Status:** ⚠️ Changed  

| Column | Schema Card Type | Live DB Type | Card Nullable | Live Nullable | Status | Notes |
|--------|-----------------|-------------|--------------|--------------|--------|-------|
| SETTLEMENT_TYPE | NVARCHAR2(64) | NVARCHAR2(128) | NOT NULL | NOT NULL | ⚠️ CHANGED | Type: `NVARCHAR2(64)` → `NVARCHAR2(128)` |
| SETTLEMENT_DESC | NVARCHAR2(256) | NVARCHAR2(512) | NULL | NULL | ⚠️ CHANGED | Type: `NVARCHAR2(256)` → `NVARCHAR2(512)` |
| TRADE_DAYS | NUMBER(3,0) | NUMBER(3,0) | NOT NULL | NOT NULL | ✅ OK |  |
| SETTLEMENT_DAYS | NUMBER(3,0) | NUMBER(3,0) | NOT NULL | NOT NULL | ✅ OK |  |
| SETTLEMENT_TYPE_ID | NUMBER(4,0) | NUMBER(4,0) | NOT NULL | NOT NULL | ✅ OK | PK |
| ACTIVE | NCHAR(1) | NCHAR(2) | NOT NULL | NOT NULL | ⚠️ CHANGED | Type: `NCHAR(1)` → `NCHAR(2)` |
| CREATION_DATE | DATE | DATE | NOT NULL | NOT NULL | ✅ OK |  |
| MODIFIED_BY | VARCHAR2(32) | VARCHAR2(32) | NOT NULL | NOT NULL | ✅ OK |  |
| MODIFIED_DATE | DATE | DATE | NOT NULL | NOT NULL | ✅ OK |  |

### ATS.SUBSCRIBED_BROKERS

**Status:** ⚠️ Changed  
**New columns (live DB only):** IS_PRIMARY_DEALER, ALLOW_CONTRIBUTION, APPROVAL_REQUIRED  

| Column | Schema Card Type | Live DB Type | Card Nullable | Live Nullable | Status | Notes |
|--------|-----------------|-------------|--------------|--------------|--------|-------|
| BROKER_CODE | NVARCHAR2(35) | NVARCHAR2(70) | NOT NULL | NOT NULL | ⚠️ CHANGED | Type: `NVARCHAR2(35)` → `NVARCHAR2(70)` |
| BROKER_ID | NUMBER(5,0) | NUMBER(5,0) | NOT NULL | NOT NULL | ✅ OK | PK |
| CASH | NUMBER(15,0) | NUMBER(15,0) | NULL | NULL | ✅ OK |  |
| CREDIT_LINE_LIMIT | NUMBER(20,4) | NUMBER(20,4) | NULL | NULL | ✅ OK |  |
| CM_ID | NUMBER(5,0) | NUMBER(5,0) | NULL | NULL | ✅ OK |  |
| EXCHANGE_ID | NUMBER(5,0) | NUMBER(5,0) | NULL | NULL | ✅ OK | FK→ATS.EXCHANGES(EXCHANGE_ID) |
| ACTIVE | NUMBER(1,0) | NUMBER(1,0) | NOT NULL | NOT NULL | ✅ OK |  |
| BYPASS_CASH_LIMIT | NUMBER(1,0) | NUMBER(1,0) | NULL | NULL | ✅ OK |  |
| BYPASS_RISK | NUMBER(1,0) | NUMBER(1,0) | NULL | NULL | ✅ OK |  |
| CREATION_DATE | DATE | DATE | NOT NULL | NOT NULL | ✅ OK |  |
| MODIFIED_BY | VARCHAR2(32) | VARCHAR2(32) | NOT NULL | NOT NULL | ✅ OK |  |
| MODIFIED_DATE | DATE | DATE | NOT NULL | NOT NULL | ✅ OK |  |
| MOBILE | VARCHAR2(25) | VARCHAR2(25) | NULL | NULL | ✅ OK |  |
| EMAIL | VARCHAR2(100) | VARCHAR2(100) | NULL | NULL | ✅ OK |  |
| BROKER_NAME | NVARCHAR2(200) | NVARCHAR2(400) | NULL | NULL | ⚠️ CHANGED | Type: `NVARCHAR2(200)` → `NVARCHAR2(400)` |
| BROKER_TYPE_ID | NUMBER(3,0) | NUMBER(3,0) | NOT NULL | NOT NULL | ✅ OK | FK→ATS.BROKER_TYPES(BROKER_TYPE_ID) |
| BYPASS_CREDIT_LINE_LIMIT | NUMBER(1,0) | NUMBER(1,0) | NULL | NULL | ✅ OK |  |
| BYPASS_SHORT_SELL | NUMBER(1,0) | NUMBER(1,0) | NULL | NULL | ✅ OK |  |
| ADDRESS | NVARCHAR2(264) | NVARCHAR2(528) | NULL | NULL | ⚠️ CHANGED | Type: `NVARCHAR2(264)` → `NVARCHAR2(528)` |
| COUNTRY | NVARCHAR2(64) | NVARCHAR2(128) | NULL | NULL | ⚠️ CHANGED | Type: `NVARCHAR2(64)` → `NVARCHAR2(128)` |
| FAX | NVARCHAR2(100) | NVARCHAR2(200) | NULL | NULL | ⚠️ CHANGED | Type: `NVARCHAR2(100)` → `NVARCHAR2(200)` |
| TRADER_ID | NUMBER(30,0) | NUMBER(30,0) | NULL | NULL | ✅ OK |  |
| IS_PRIMARY_DEALER | — | VARCHAR2(1) | — | NULL | 🆕 NEW COL | Column exists in live DB but not in schema card |
| ALLOW_CONTRIBUTION | — | VARCHAR2(1) | — | NULL | 🆕 NEW COL | Column exists in live DB but not in schema card |
| APPROVAL_REQUIRED | — | NUMBER(1,0) | — | NULL | 🆕 NEW COL | Column exists in live DB but not in schema card |

### ATS.SYMBOLS

**Status:** ⚠️ Changed  
**New columns (live DB only):** YEAR_DAYS_CONVENTION, MONEY_MARKET_TYPE_ID, TENURE_DAYS, DAY_COUNT_CONVENTION, BENCHMARK, ISSUED_QUANTITY, ALLOW_DAY_TRADING  
**Removed columns (card only):** SETTLEMENT_TYPE_ID  

| Column | Schema Card Type | Live DB Type | Card Nullable | Live Nullable | Status | Notes |
|--------|-----------------|-------------|--------------|--------------|--------|-------|
| SYMBOL | NVARCHAR2(64) | NVARCHAR2(128) | NOT NULL | NOT NULL | ⚠️ CHANGED | Type: `NVARCHAR2(64)` → `NVARCHAR2(128)` |
| SYMBOL_ID | NUMBER(15,0) | NUMBER(15,0) | NOT NULL | NOT NULL | ✅ OK | PK |
| COMPANY_ID | NUMBER(15,0) | NUMBER(15,0) | NULL | NULL | ✅ OK | FK→ATS.COMPANIES(COMPANY_ID) |
| FACE_VALUE | NUMBER(14,4) | NUMBER(14,4) | NULL | NULL | ✅ OK |  |
| OUTSTANDING_SHARES | NUMBER(12,0) | NUMBER(12,0) | NULL | NULL | ✅ OK |  |
| SETTLEMENT_TYPE_ID | NUMBER(4,0) | — | NOT NULL | — | ❌ REMOVED | Column missing from live DB |
| SYMBOL_TYPE_ID | NUMBER(2,0) | NUMBER(2,0) | NOT NULL | NOT NULL | ✅ OK | FK→ATS.SYMBOL_TYPES(SYMBOL_TYPE_ID) |
| SYMBOL_GROUP_ID | NUMBER(4,0) | NUMBER(4,0) | NOT NULL | NOT NULL | ✅ OK | FK→ATS.SYMBOL_GROUPS(SYMBOL_GROUP_ID) |
| SYMBOL_CATEGORY_ID | NUMBER(2,0) | NUMBER(2,0) | NULL | NULL | ✅ OK |  |
| ACTIVE | NUMBER(1,0) | NUMBER(1,0) | NOT NULL | NOT NULL | ✅ OK |  |
| CREATION_DATE | DATE | DATE | NOT NULL | NOT NULL | ✅ OK |  |
| MODIFIED_BY | VARCHAR2(32) | VARCHAR2(32) | NOT NULL | NOT NULL | ✅ OK |  |
| MODIFIED_DATE | DATE | DATE | NOT NULL | NOT NULL | ✅ OK |  |
| CURRENCY_ID | NUMBER(4,0) | NUMBER(4,0) | NOT NULL | NOT NULL | ✅ OK | FK→ATS.CURRENCY(CURRENCY_ID) |
| FIRST_TRADING_DAY | DATE | DATE | NOT NULL | NOT NULL | ✅ OK |  |
| ISSUE_PRICE | NUMBER(14,4) | NUMBER(14,4) | NOT NULL | NOT NULL | ✅ OK |  |
| ISIN | NVARCHAR2(12) | NVARCHAR2(30) | NOT NULL | NOT NULL | ⚠️ CHANGED | Type: `NVARCHAR2(12)` → `NVARCHAR2(30)` |
| ISSUER_ID | NUMBER(6,0) | NUMBER(6,0) | NULL | NULL | ✅ OK | FK→ATS.ISSUER(ISSUER_ID) |
| CFI | NVARCHAR2(20) | NVARCHAR2(40) | NULL | NULL | ⚠️ CHANGED | Type: `NVARCHAR2(20)` → `NVARCHAR2(40)` |
| FISN | NVARCHAR2(35) | NVARCHAR2(70) | NULL | NULL | ⚠️ CHANGED | Type: `NVARCHAR2(35)` → `NVARCHAR2(70)` |
| LEI | NVARCHAR2(20) | NVARCHAR2(40) | NULL | NULL | ⚠️ CHANGED | Type: `NVARCHAR2(20)` → `NVARCHAR2(40)` |
| HAIRCUT | NUMBER(2,0) | NUMBER(2,0) | NOT NULL | NOT NULL | ✅ OK |  |
| FREE_FLOAT_SHARES | NUMBER(15,0) | NUMBER(15,0) | NULL | NULL | ✅ OK |  |
| AUTHORIZED_CAPITAL | NUMBER(15,0) | NUMBER(15,0) | NULL | NULL | ✅ OK |  |
| ETF_TYPE_ID | NUMBER(2,0) | NUMBER(2,0) | NULL | NULL | ✅ OK | FK→ATS.ETF_TYPE(ETF_TYPE_ID) |
| YEAR_DAYS_CONVENTION | — | NUMBER(15,0) | — | NULL | 🆕 NEW COL | Column exists in live DB but not in schema card |
| MONEY_MARKET_TYPE_ID | — | NUMBER(4,0) | — | NULL | 🆕 NEW COL | Column exists in live DB but not in schema card |
| TENURE_DAYS | — | NUMBER(3,0) | — | NULL | 🆕 NEW COL | Column exists in live DB but not in schema card |
| DAY_COUNT_CONVENTION | — | VARCHAR2(10) | — | NULL | 🆕 NEW COL | Column exists in live DB but not in schema card |
| BENCHMARK | — | VARCHAR2(1) | — | NULL | 🆕 NEW COL | Column exists in live DB but not in schema card |
| ISSUED_QUANTITY | — | NUMBER(12,0) | — | NULL | 🆕 NEW COL | Column exists in live DB but not in schema card |
| ALLOW_DAY_TRADING | — | NUMBER(1,0) | — | NULL | 🆕 NEW COL | Column exists in live DB but not in schema card |

### ATS.SYMBOL_DAILY_INDICATORS

**Status:** ⚠️ Changed  
**Grain (from card):** symbol_day  
**Date Key:** STATS_DATE  
**New columns (live DB only):** DISCOUNT_RATE  

| Column | Schema Card Type | Live DB Type | Card Nullable | Live Nullable | Status | Notes |
|--------|-----------------|-------------|--------------|--------------|--------|-------|
| STATS_DATE | DATE | DATE | NOT NULL | NOT NULL | ✅ OK | PK |
| OPEN_PRICE | NUMBER(14,4) | NUMBER(14,4) | NOT NULL | NOT NULL | ✅ OK |  |
| CLOSE_PRICE | NUMBER(14,4) | NUMBER(14,4) | NOT NULL | NOT NULL | ✅ OK |  |
| LOW_PRICE | NUMBER(14,4) | NUMBER(14,4) | NOT NULL | NOT NULL | ✅ OK |  |
| HIGH_PRICE | NUMBER(14,4) | NUMBER(14,4) | NOT NULL | NOT NULL | ✅ OK |  |
| TURNOVER | NUMBER(10,0) | NUMBER(10,0) | NOT NULL | NOT NULL | ✅ OK |  |
| TURNOVER_VALUE | NUMBER(20,4) | NUMBER(20,4) | NULL | NULL | ✅ OK |  |
| TRADES_COUNT | NUMBER(10,0) | NUMBER(10,0) | NOT NULL | NOT NULL | ✅ OK |  |
| AVERAGE_PRICE | NUMBER(14,4) | NUMBER(14,4) | NOT NULL | NOT NULL | ✅ OK |  |
| CHANGE_PRICE | NUMBER(14,4) | NUMBER(14,4) | NOT NULL | NOT NULL | ✅ OK |  |
| PERCENTAGE_CHANGE | NUMBER(9,4) | NUMBER(14,4) | NULL | NULL | ⚠️ CHANGED | Type: `NUMBER(9,4)` → `NUMBER(14,4)` |
| MARKET_ID | NUMBER(4,0) | NUMBER(4,0) | NOT NULL | NOT NULL | ✅ OK | PK, FK→ATS.MARKETS(MARKET_ID) |
| SYMBOL_ID | NUMBER(15,0) | NUMBER(15,0) | NOT NULL | NOT NULL | ✅ OK | PK, FK→ATS.SYMBOLS(SYMBOL_ID) |
| EXCHANGE_ID | NUMBER(4,0) | NUMBER(4,0) | NOT NULL | NOT NULL | ✅ OK | PK, FK→ATS.EXCHANGES(EXCHANGE_ID) |
| OPEN_PRICE_YIELD | NUMBER(15,4) | NUMBER(15,4) | NULL | NULL | ✅ OK |  |
| YIELD | NUMBER(15,4) | NUMBER(15,4) | NULL | NULL | ✅ OK |  |
| DISCOUNT_RATE | — | NUMBER(14,4) | — | NULL | 🆕 NEW COL | Column exists in live DB but not in schema card |

### ATS.SYMBOL_INDICATORS

**Status:** ⚠️ Changed  
**Grain (from card):** symbol_timestamp  
**Date Key:** ENTRY_DATETIME  
**New columns (live DB only):** PERCENTAGE_CHANGE, DISCOUNT_RATE  

| Column | Schema Card Type | Live DB Type | Card Nullable | Live Nullable | Status | Notes |
|--------|-----------------|-------------|--------------|--------------|--------|-------|
| ENTRY_DATETIME | TIMESTAMP(6) | TIMESTAMP(6) | NOT NULL | NOT NULL | ✅ OK |  |
| OPEN | NUMBER(14,4) | NUMBER(14,4) | NOT NULL | NOT NULL | ✅ OK |  |
| HIGH | NUMBER(14,4) | NUMBER(14,4) | NOT NULL | NOT NULL | ✅ OK |  |
| LOW | NUMBER(14,4) | NUMBER(14,4) | NOT NULL | NOT NULL | ✅ OK |  |
| CLOSE | NUMBER(14,4) | NUMBER(14,4) | NOT NULL | NOT NULL | ✅ OK |  |
| AVG | NUMBER(14,4) | NUMBER(14,4) | NOT NULL | NOT NULL | ✅ OK |  |
| VOLUME | NUMBER(10,0) | NUMBER(10,0) | NOT NULL | NOT NULL | ✅ OK |  |
| VALUE | NUMBER(15,4) | NUMBER(15,4) | NULL | NULL | ✅ OK |  |
| SYMBOL_ID | NUMBER(15,0) | NUMBER(15,0) | NOT NULL | NOT NULL | ✅ OK | FK→ATS.SYMBOL_MARKETS(SYMBOL_ID) |
| MARKET_ID | NUMBER(4,0) | NUMBER(4,0) | NOT NULL | NOT NULL | ✅ OK | FK→ATS.SYMBOL_MARKETS(MARKET_ID) |
| EXCHANGE_ID | NUMBER(4,0) | NUMBER(4,0) | NOT NULL | NOT NULL | ✅ OK | FK→ATS.SYMBOL_MARKETS(EXCHANGE_ID) |
| TRADES_COUNT | NUMBER(10,0) | NUMBER(10,0) | NULL | NULL | ✅ OK |  |
| CHANGE_PRICE | NUMBER(14,4) | NUMBER(14,4) | NULL | NULL | ✅ OK |  |
| OPEN_PRICE_YIELD | NUMBER(15,4) | NUMBER(15,4) | NULL | NULL | ✅ OK |  |
| YIELD | NUMBER(15,4) | NUMBER(15,4) | NULL | NULL | ✅ OK |  |
| PERCENTAGE_CHANGE | — | NUMBER(14,4) | — | NULL | 🆕 NEW COL | Column exists in live DB but not in schema card |
| DISCOUNT_RATE | — | NUMBER(14,4) | — | NULL | 🆕 NEW COL | Column exists in live DB but not in schema card |

### ATS.SYMBOL_MARKETS

**Status:** ⚠️ Changed  
**New columns (live DB only):** MAXIMUM_TENURE, SETTLEMENT_TYPE_ID, ACTIVE, PRECISION, CLOSING_PRICE_MECHANISM, ANONYMOUS_TRADING, NEGO_APPLY_DYN_CIR_BREAKER, NEG_BOARD_LOT, MIN_NEG_VOLUME, MIN_NEG_VALUE, NEG_MAX_VALUE, NEG_MAX_VOLUME, APPLY_DYNAMIC_CIRCUIT_BREAKERS, NEG_ANONYMOUS_TRADING, MIN_VOL_FOR_CLOSE_PRICE  

| Column | Schema Card Type | Live DB Type | Card Nullable | Live Nullable | Status | Notes |
|--------|-----------------|-------------|--------------|--------------|--------|-------|
| TICK_SIZE | NUMBER(8,4) | NUMBER(8,4) | NOT NULL | NOT NULL | ✅ OK |  |
| BOARD_LOT | NUMBER(6,0) | NUMBER(6,0) | NOT NULL | NOT NULL | ✅ OK |  |
| UPPER_CIRCUIT_BREAKER_LIMIT | NUMBER(14,4) | NUMBER(14,4) | NOT NULL | NOT NULL | ✅ OK |  |
| LOWER_CIRCUIT_BREAKER_LIMIT | NUMBER(14,4) | NUMBER(14,4) | NOT NULL | NOT NULL | ✅ OK |  |
| UPPER_ORDER_VALUE_LIMIT | NUMBER(15,4) | NUMBER(15,4) | NOT NULL | NOT NULL | ✅ OK |  |
| LOWER_ORDER_VALUE_LIMIT | NUMBER(15,4) | NUMBER(15,4) | NOT NULL | NOT NULL | ✅ OK |  |
| UPPER_ORDER_VOLUME_LIMIT | NUMBER(10,0) | NUMBER(15,0) | NOT NULL | NOT NULL | ⚠️ CHANGED | Type: `NUMBER(10,0)` → `NUMBER(15,0)` |
| LOWER_ORDER_VOLUME_LIMIT | NUMBER(10,0) | NUMBER(15,0) | NOT NULL | NOT NULL | ⚠️ CHANGED | Type: `NUMBER(10,0)` → `NUMBER(15,0)` |
| MARKET_ID | NUMBER(4,0) | NUMBER(4,0) | NOT NULL | NOT NULL | ✅ OK | PK, FK→ATS.MARKETS(MARKET_ID) |
| SYMBOL_ID | NUMBER(15,0) | NUMBER(15,0) | NOT NULL | NOT NULL | ✅ OK | PK, FK→ATS.SYMBOLS(SYMBOL_ID) |
| FIFTY_TWO_WEEK_HIGH | NUMBER(10,4) | NUMBER(10,4) | NULL | NULL | ✅ OK |  |
| FIFTY_TWO_WEEK_LOW | NUMBER(10,4) | NUMBER(10,4) | NULL | NULL | ✅ OK |  |
| EXCHANGE_ID | NUMBER(4,0) | NUMBER(4,0) | NOT NULL | NOT NULL | ✅ OK | PK, FK→ATS.EXCHANGES(EXCHANGE_ID) |
| CLOSE_PRICE | NUMBER(16,4) | NUMBER(16,4) | NULL | NULL | ✅ OK |  |
| STATE | NUMBER(1,0) | NUMBER(1,0) | NULL | NULL | ✅ OK | 0=Open, 1=Suspended, 2=Deleted |
| EXCHANGE_MARKET_ID | NUMBER(10,0) | NUMBER(10,0) | NOT NULL | NOT NULL | ✅ OK | FK→ATS.EXCHANGE_MARKETS(EXCHANGE_MARKET_ID) |
| CREATION_DATE | DATE | DATE | NOT NULL | NOT NULL | ✅ OK |  |
| MODIFIED_BY | VARCHAR2(32) | VARCHAR2(32) | NOT NULL | NOT NULL | ✅ OK |  |
| MODIFIED_DATE | DATE | DATE | NOT NULL | NOT NULL | ✅ OK |  |
| MARKET_CONFIG_OVERRIDE | NUMBER(1,0) | NUMBER(1,0) | NOT NULL | NOT NULL | ✅ OK |  |
| UPPER_VOLUME_ALERT_LIMIT | NUMBER(10,0) | NUMBER(10,0) | NOT NULL | NOT NULL | ✅ OK |  |
| LOWER_VOLUME_ALERT_LIMIT | NUMBER(10,0) | NUMBER(10,0) | NOT NULL | NOT NULL | ✅ OK |  |
| UPPER_VALUE_ALERT_LIMIT | NUMBER(15,4) | NUMBER(15,4) | NOT NULL | NOT NULL | ✅ OK |  |
| LOWER_VALUE_ALERT_LIMIT | NUMBER(15,4) | NUMBER(15,4) | NOT NULL | NOT NULL | ✅ OK |  |
| MBO_DEPTH | NUMBER(4,0) | NUMBER(4,0) | NOT NULL | NOT NULL | ✅ OK |  |
| MBP_DEPTH | NUMBER(4,0) | NUMBER(4,0) | NOT NULL | NOT NULL | ✅ OK |  |
| ALLOW_SHORT_SELL | NUMBER(1,0) | NUMBER(1,0) | NOT NULL | NOT NULL | ✅ OK |  |
| UPPER_CIRCUIT_PERCENT | NUMBER(3,0) | NUMBER(3,0) | NOT NULL | NOT NULL | ✅ OK |  |
| LOWER_CIRCUIT_PERCENT | NUMBER(3,0) | NUMBER(3,0) | NOT NULL | NOT NULL | ✅ OK |  |
| QUOTE_SPREAD | NUMBER(14,4) | NUMBER(14,4) | NULL | NULL | ✅ OK |  |
| REASON | NVARCHAR2(160) | NVARCHAR2(320) | NULL | NULL | ⚠️ CHANGED | Type: `NVARCHAR2(160)` → `NVARCHAR2(320)` |
| FIXED_TICK_SIZE | NUMBER(1,0) | NUMBER(1,0) | NULL | NULL | ✅ OK |  |
| NEG_UPPER_CIRCUIT_BREAKER_LIMT | NUMBER(14,4) | NUMBER(14,4) | NULL | NULL | ✅ OK |  |
| NEG_LOWER_CIRCUIT_BREAKER_LIMT | NUMBER(14,4) | NUMBER(14,4) | NULL | NULL | ✅ OK |  |
| NEG_UPPER_CIRCUIT_PERCENT | NUMBER(3,0) | NUMBER(3,0) | NULL | NULL | ✅ OK |  |
| NEG_LOWER_CIRCUIT_PERCENT | NUMBER(3,0) | NUMBER(3,0) | NULL | NULL | ✅ OK |  |
| MIN_TRADE_VOLUME | NUMBER(15,0) | NUMBER(15,0) | NULL | NULL | ✅ OK |  |
| NO_OF_DAYS | NUMBER(10,0) | NUMBER(10,0) | NULL | NULL | ✅ OK |  |
| DYN_UPPER_CIRCUIT_PERCENT | NUMBER(3,0) | NUMBER(3,0) | NULL | NULL | ✅ OK |  |
| DYN_LOWER_CIRCUIT_PERCENT | NUMBER(3,0) | NUMBER(3,0) | NULL | NULL | ✅ OK |  |
| NEG_DYN_LOWER_CIRCUIT_PERCENT | NUMBER(3,0) | NUMBER(3,0) | NULL | NULL | ✅ OK |  |
| NEG_DYN_UPPER_CIRCUIT_PERCENT | NUMBER(3,0) | NUMBER(3,0) | NULL | NULL | ✅ OK |  |
| MAXIMUM_TENURE | — | NUMBER(6,0) | — | NULL | 🆕 NEW COL | Column exists in live DB but not in schema card |
| SETTLEMENT_TYPE_ID | — | NUMBER(4,0) | — | NULL | 🆕 NEW COL | Column exists in live DB but not in schema card |
| ACTIVE | — | NUMBER(1,0) | — | NOT NULL | 🆕 NEW COL | Column exists in live DB but not in schema card |
| PRECISION | — | NUMBER(2,0) | — | NOT NULL | 🆕 NEW COL | Column exists in live DB but not in schema card |
| CLOSING_PRICE_MECHANISM | — | NUMBER(4,0) | — | NOT NULL | 🆕 NEW COL | Column exists in live DB but not in schema card |
| ANONYMOUS_TRADING | — | VARCHAR2(1) | — | NULL | 🆕 NEW COL | Column exists in live DB but not in schema card |
| NEGO_APPLY_DYN_CIR_BREAKER | — | VARCHAR2(1) | — | NULL | 🆕 NEW COL | Column exists in live DB but not in schema card |
| NEG_BOARD_LOT | — | NUMBER(6,0) | — | NULL | 🆕 NEW COL | Column exists in live DB but not in schema card |
| MIN_NEG_VOLUME | — | NUMBER(15,0) | — | NULL | 🆕 NEW COL | Column exists in live DB but not in schema card |
| MIN_NEG_VALUE | — | NUMBER(15,4) | — | NULL | 🆕 NEW COL | Column exists in live DB but not in schema card |
| NEG_MAX_VALUE | — | NUMBER(20,4) | — | NULL | 🆕 NEW COL | Column exists in live DB but not in schema card |
| NEG_MAX_VOLUME | — | NUMBER(15,0) | — | NULL | 🆕 NEW COL | Column exists in live DB but not in schema card |
| APPLY_DYNAMIC_CIRCUIT_BREAKERS | — | NUMBER(1,0) | — | NULL | 🆕 NEW COL | Column exists in live DB but not in schema card |
| NEG_ANONYMOUS_TRADING | — | VARCHAR2(1) | — | NULL | 🆕 NEW COL | Column exists in live DB but not in schema card |
| MIN_VOL_FOR_CLOSE_PRICE | — | NUMBER(10,0) | — | NULL | 🆕 NEW COL | Column exists in live DB but not in schema card |

### ATS.SYMBOL_TYPES

**Status:** ⚠️ Changed  

| Column | Schema Card Type | Live DB Type | Card Nullable | Live Nullable | Status | Notes |
|--------|-----------------|-------------|--------------|--------------|--------|-------|
| SYMBOL_TYPE_ID | NUMBER(2,0) | NUMBER(2,0) | NOT NULL | NOT NULL | ✅ OK | PK |
| SYMBOL_TYPE | NVARCHAR2(20) | NVARCHAR2(40) | NOT NULL | NOT NULL | ⚠️ CHANGED | Type: `NVARCHAR2(20)` → `NVARCHAR2(40)` |

### ATS.TRADES

**Status:** ⚠️ Changed  
**Grain (from card):** trade_event  
**Date Key:** ENTRY_DATETIME  
**New columns (live DB only):** REJECTION_ID, CSD_REJECTION_REASON, DEPO_STATUS, DISCOUNT_RATE, PRINCIPAL_AMOUNT, BOND_VOLUME_MECHANISM  

| Column | Schema Card Type | Live DB Type | Card Nullable | Live Nullable | Status | Notes |
|--------|-----------------|-------------|--------------|--------------|--------|-------|
| ENTRY_DATETIME | TIMESTAMP(6) | TIMESTAMP(6) | NOT NULL | NOT NULL | ✅ OK | PK |
| TICKET_NO | NUMBER(10,0) | NUMBER(10,0) | NOT NULL | NOT NULL | ✅ OK | PK |
| SELLER_ORDER_NO | NUMBER(10,0) | NUMBER(10,0) | NOT NULL | NOT NULL | ✅ OK |  |
| BUYER_ORDER_NO | NUMBER(10,0) | NUMBER(10,0) | NOT NULL | NOT NULL | ✅ OK |  |
| PRICE | NUMBER(16,4) | NUMBER(14,4) | NOT NULL | NOT NULL | ⚠️ CHANGED | Type: `NUMBER(16,4)` → `NUMBER(14,4)` |
| VOLUME | NUMBER(10,0) | NUMBER(10,0) | NOT NULL | NOT NULL | ✅ OK |  |
| EXCHANGE_ID | NUMBER(4,0) | NUMBER(4,0) | NOT NULL | NOT NULL | ✅ OK | PK, FK→ATS.SYMBOL_MARKETS(EXCHANGE_ID) |
| BUYER_CLIENT_ID | NUMBER(20,0) | NUMBER(20,0) | NOT NULL | NOT NULL | ✅ OK | FK→ATS.EDS_CLIENTS(CLIENT_ID) |
| SELLER_CLIENT_ID | NUMBER(20,0) | NUMBER(20,0) | NOT NULL | NOT NULL | ✅ OK | FK→ATS.EDS_CLIENTS(CLIENT_ID) |
| SYMBOL_ID | NUMBER(15,0) | NUMBER(15,0) | NOT NULL | NOT NULL | ✅ OK | PK, FK→ATS.SYMBOL_MARKETS(SYMBOL_ID) |
| MARKET_ID | NUMBER(4,0) | NUMBER(4,0) | NOT NULL | NOT NULL | ✅ OK | PK, FK→ATS.SYMBOL_MARKETS(MARKET_ID) |
| BUYER_BROKER_ID | NUMBER(5,0) | NUMBER(5,0) | NOT NULL | NOT NULL | ✅ OK | FK→ATS.SUBSCRIBED_BROKERS(BROKER_ID) |
| SELLER_BROKER_ID | NUMBER(5,0) | NUMBER(5,0) | NOT NULL | NOT NULL | ✅ OK | FK→ATS.SUBSCRIBED_BROKERS(BROKER_ID) |
| BUYER_USER_ID | NUMBER(30,0) | NUMBER(30,0) | NOT NULL | NOT NULL | ✅ OK | FK→ATS.USERS(USER_ID) |
| SELLER_USER_ID | NUMBER(30,0) | NUMBER(30,0) | NOT NULL | NOT NULL | ✅ OK | FK→ATS.USERS(USER_ID) |
| TRADE_TYPE | NUMBER(1,0) | NUMBER(1,0) | NOT NULL | NOT NULL | ✅ OK |  |
| IS_SHORT | NVARCHAR2(1) | NVARCHAR2(2) | NOT NULL | NOT NULL | ⚠️ CHANGED | Type: `NVARCHAR2(1)` → `NVARCHAR2(2)` |
| STATE_ID | NUMBER(2,0) | NUMBER(2,0) | NOT NULL | NOT NULL | ✅ OK | FK→ATS.TRADE_STATES(STATE_ID) |
| BUYER_REMAINING_VOLUME | NUMBER(10,0) | NUMBER(10,0) | NOT NULL | NOT NULL | ✅ OK |  |
| SELLER_REMAINING_VOLUME | NUMBER(10,0) | NUMBER(10,0) | NOT NULL | NOT NULL | ✅ OK |  |
| BUYER_CUSTODIAN_ID | NUMBER(20,0) | NUMBER(20,0) | NULL | NULL | ✅ OK |  |
| SELLER_CUSTODIAN_ID | NUMBER(20,0) | NUMBER(20,0) | NULL | NULL | ✅ OK |  |
| ACCRUED_PROFIT | NUMBER(24,6) | NUMBER(24,6) | NULL | NULL | ✅ OK |  |
| YIELD | NUMBER(15,4) | NUMBER(15,4) | NULL | NULL | ✅ OK |  |
| VALUE | NUMBER(24,6) | NUMBER(24,6) | NULL | NULL | ✅ OK |  |
| PRICING_MECHANISM | NUMBER(1,0) | NUMBER(1,0) | NULL | NULL | ✅ OK |  |
| PRICING_MODEL | NUMBER(1,0) | NUMBER(1,0) | NULL | NULL | ✅ OK |  |
| SETTLEMENT_TYPE_ID | NUMBER(4,0) | NUMBER(4,0) | NULL | NULL | ✅ OK |  |
| SETTLEMENT_AMOUNT | NUMBER(24,6) | NUMBER(24,6) | NULL | NULL | ✅ OK |  |
| CONTRACT_ID | VARCHAR2(25) | VARCHAR2(25) | NULL | NULL | ✅ OK |  |
| INITIAL_DATE | DATE | DATE | NULL | NULL | ✅ OK |  |
| TERMINATION_DATE | DATE | DATE | NULL | NULL | ✅ OK |  |
| LEG | NUMBER(1,0) | NUMBER(1,0) | NULL | NULL | ✅ OK |  |
| REPURCHASE_PRICE | NUMBER(16,4) | NUMBER(14,4) | NULL | NULL | ⚠️ CHANGED | Type: `NUMBER(16,4)` → `NUMBER(14,4)` |
| DIRTY_PRICE | NUMBER(16,4) | NUMBER(14,4) | NULL | NULL | ⚠️ CHANGED | Type: `NUMBER(16,4)` → `NUMBER(14,4)` |
| BUYER_TRADER_ID | NUMBER(30,0) | NUMBER(30,0) | NULL | NULL | ✅ OK |  |
| SELLER_TRADER_ID | NUMBER(30,0) | NUMBER(30,0) | NULL | NULL | ✅ OK |  |
| REJECTION_ID | — | NUMBER(4,0) | — | NULL | 🆕 NEW COL | Column exists in live DB but not in schema card |
| CSD_REJECTION_REASON | — | VARCHAR2(400) | — | NULL | 🆕 NEW COL | Column exists in live DB but not in schema card |
| DEPO_STATUS | — | VARCHAR2(15) | — | NULL | 🆕 NEW COL | Column exists in live DB but not in schema card |
| DISCOUNT_RATE | — | NUMBER(15,4) | — | NULL | 🆕 NEW COL | Column exists in live DB but not in schema card |
| PRINCIPAL_AMOUNT | — | NUMBER(10,0) | — | NOT NULL | 🆕 NEW COL | Column exists in live DB but not in schema card |
| BOND_VOLUME_MECHANISM | — | NUMBER(1,0) | — | NOT NULL | 🆕 NEW COL | Column exists in live DB but not in schema card |

### ATS.TRADE_STATES

**Status:** ✅ Matched  

| Column | Schema Card Type | Live DB Type | Card Nullable | Live Nullable | Status | Notes |
|--------|-----------------|-------------|--------------|--------------|--------|-------|
| STATE_ID | NUMBER(2,0) | NUMBER(2,0) | NOT NULL | NOT NULL | ✅ OK | PK |
| STATE_CODE | VARCHAR2(32) | VARCHAR2(32) | NOT NULL | NOT NULL | ✅ OK |  |

### ATS.USERS

**Status:** ⚠️ Changed  
**New columns (live DB only):** ALLOW_ORDER_APPROVAL  

| Column | Schema Card Type | Live DB Type | Card Nullable | Live Nullable | Status | Notes |
|--------|-----------------|-------------|--------------|--------------|--------|-------|
| USER_ID | NUMBER(30,0) | NUMBER(30,0) | NOT NULL | NOT NULL | ✅ OK | PK |
| USER_NAME | NVARCHAR2(32) | NVARCHAR2(64) | NOT NULL | NOT NULL | ⚠️ CHANGED | Type: `NVARCHAR2(32)` → `NVARCHAR2(64)` |
| PASSWORD | NVARCHAR2(32) | NVARCHAR2(64) | NOT NULL | NOT NULL | ⚠️ CHANGED | Type: `NVARCHAR2(32)` → `NVARCHAR2(64)` |
| EMAIL | NVARCHAR2(256) | NVARCHAR2(512) | NULL | NULL | ⚠️ CHANGED | Type: `NVARCHAR2(256)` → `NVARCHAR2(512)` |
| USER_TYPE_ID | NUMBER(3,0) | NUMBER(3,0) | NULL | NULL | ✅ OK | FK→ATS.USER_TYPES(TYPE_ID) |
| BROKER_ID | NUMBER(5,0) | NUMBER(5,0) | NULL | NULL | ✅ OK | FK→ATS.SUBSCRIBED_BROKERS(BROKER_ID) |
| LAST_LOGIN_DATETIME | DATE | DATE | NULL | NULL | ✅ OK |  |
| LAST_LOGIN_IP | NVARCHAR2(15) | NVARCHAR2(30) | NULL | NULL | ⚠️ CHANGED | Type: `NVARCHAR2(15)` → `NVARCHAR2(30)` |
| SKIN | NVARCHAR2(30) | NVARCHAR2(60) | NULL | NULL | ⚠️ CHANGED | Type: `NVARCHAR2(30)` → `NVARCHAR2(60)` |
| STATUS | NUMBER(2,0) | NUMBER(2,0) | NULL | NULL | ✅ OK | FK→ATS.USER_STATUS(ID), 1=Active, 0=Suspended |
| TWO_FACTOR_AUTH | NUMBER(1,0) | NUMBER(1,0) | NULL | NULL | ✅ OK |  |
| PWD_OTP_FLAG | NUMBER(1,0) | NUMBER(1,0) | NULL | NULL | ✅ OK |  |
| PWD_EXPIRY_DATE | DATE | DATE | NOT NULL | NOT NULL | ✅ OK |  |
| CREATION_DATE | DATE | DATE | NOT NULL | NOT NULL | ✅ OK |  |
| MODIFIED_BY | VARCHAR2(32) | VARCHAR2(32) | NOT NULL | NOT NULL | ✅ OK |  |
| MODIFIED_DATE | DATE | DATE | NOT NULL | NOT NULL | ✅ OK |  |
| MOBILE | VARCHAR2(15) | VARCHAR2(15) | NULL | NULL | ✅ OK |  |
| IP_ADDRESS | VARCHAR2(20) | VARCHAR2(20) | NULL | NULL | ✅ OK |  |
| MAC_ADDRESS | VARCHAR2(60) | VARCHAR2(60) | NULL | NULL | ✅ OK |  |
| COMPLETE_NAME | VARCHAR2(64) | VARCHAR2(64) | NOT NULL | NOT NULL | ✅ OK |  |
| SEND_SMS | NVARCHAR2(1) | NVARCHAR2(2) | NOT NULL | NOT NULL | ⚠️ CHANGED | Type: `NVARCHAR2(1)` → `NVARCHAR2(2)` |
| LOGIN_SMS | NVARCHAR2(1) | NVARCHAR2(2) | NOT NULL | NOT NULL | ⚠️ CHANGED | Type: `NVARCHAR2(1)` → `NVARCHAR2(2)` |
| SMS_AUTH_SUBSCRIPTION | NVARCHAR2(1) | NVARCHAR2(2) | NOT NULL | NOT NULL | ⚠️ CHANGED | Type: `NVARCHAR2(1)` → `NVARCHAR2(2)` |
| USER_EXPIRY | NVARCHAR2(1) | NVARCHAR2(2) | NULL | NULL | ⚠️ CHANGED | Type: `NVARCHAR2(1)` → `NVARCHAR2(2)` |
| ALLOW_ORDER_APPROVAL | — | NUMBER(1,0) | — | NULL | 🆕 NEW COL | Column exists in live DB but not in schema card |

---

## Tables Only in Live DB (not in Schema Card)

- `ATS.ACCOUNT_CATEGORIES`
- `ATS.ACT_QCDSTAB`
- `ATS.AQ$_ACT_QCDSTAB_G`
- `ATS.AQ$_ACT_QCDSTAB_H`
- `ATS.AQ$_ACT_QCDSTAB_I`
- `ATS.AQ$_ACT_QCDSTAB_L`
- `ATS.AQ$_ACT_QCDSTAB_S`
- `ATS.AQ$_ACT_QCDSTAB_T`
- `ATS.AQ$_ACT_QTAB_G`
- `ATS.AQ$_ACT_QTAB_H`
- `ATS.AQ$_ACT_QTAB_I`
- `ATS.AQ$_ACT_QTAB_L`
- `ATS.AQ$_ACT_QTAB_S`
- `ATS.AQ$_ACT_QTAB_T`
- `ATS.AQ$_ATS_TRADES_QTAB_G`
- `ATS.AQ$_ATS_TRADES_QTAB_H`
- `ATS.AQ$_ATS_TRADES_QTAB_I`
- `ATS.AQ$_ATS_TRADES_QTAB_L`
- `ATS.AQ$_ATS_TRADES_QTAB_S`
- `ATS.AQ$_ATS_TRADES_QTAB_T`
- `ATS.AQ$_CLIENTS_ACCOUNTS_QTAB_G`
- `ATS.AQ$_CLIENTS_ACCOUNTS_QTAB_H`
- `ATS.AQ$_CLIENTS_ACCOUNTS_QTAB_I`
- `ATS.AQ$_CLIENTS_ACCOUNTS_QTAB_L`
- `ATS.AQ$_CLIENTS_ACCOUNTS_QTAB_S`
- `ATS.AQ$_CLIENTS_ACCOUNTS_QTAB_T`
- `ATS.AQ$_DEP_TRANS_QTAB_G`
- `ATS.AQ$_DEP_TRANS_QTAB_H`
- `ATS.AQ$_DEP_TRANS_QTAB_I`
- `ATS.AQ$_DEP_TRANS_QTAB_L`
- `ATS.AQ$_DEP_TRANS_QTAB_S`
- `ATS.AQ$_DEP_TRANS_QTAB_T`
- `ATS.AQ$_MARKET_STAT_QTAB_G`
- `ATS.AQ$_MARKET_STAT_QTAB_H`
- `ATS.AQ$_MARKET_STAT_QTAB_I`
- `ATS.AQ$_MARKET_STAT_QTAB_L`
- `ATS.AQ$_MARKET_STAT_QTAB_S`
- `ATS.AQ$_MARKET_STAT_QTAB_T`
- `ATS.AQ$_PROC_STATUS_QTAB_G`
- `ATS.AQ$_PROC_STATUS_QTAB_H`
- `ATS.AQ$_PROC_STATUS_QTAB_I`
- `ATS.AQ$_PROC_STATUS_QTAB_L`
- `ATS.AQ$_PROC_STATUS_QTAB_S`
- `ATS.AQ$_PROC_STATUS_QTAB_T`
- `ATS.ATS_BASKETS`
- `ATS.ATS_CONFIG`
- `ATS.ATS_DASHBORAD`
- `ATS.ATS_LEVY_DATA`
- `ATS.ATS_TRADES_QTAB`
- `ATS.AUDIT_LOG`
- `ATS.BOND_CATEGORY`
- `ATS.BOND_COUPON_RATES`
- `ATS.BOND_PAYMENT_SCHEDULE`
- `ATS.BOND_PAYMENT_SCHEDULE_05SEP`
- `ATS.BOND_PAYMENT_SCHEDULE_2SEP25`
- `ATS.BOND_PAYMENT_SCHEDULE_BK05SEP25`
- `ATS.BOND_REDEEM_TYPES`
- `ATS.BOND_SUB_CATEGORY`
- `ATS.BOND_TYPES`
- `ATS.BROKER_EXPOSURE`
- `ATS.BROKER_EXPOSURE_DETAIL`
- `ATS.BROKER_MARKETWISE_EXPOSURE`
- `ATS.BROKER_TYPES`
- `ATS.CAPITAL_TAX_RANGES`
- `ATS.CASH_CONTRACTS`
- `ATS.CASH_DETAILS`
- `ATS.CASH_EVENT_LOGS`
- `ATS.CASH_LOG`
- `ATS.CIRCUIT_BREAKER_RANGES_OVERRIDE`
- `ATS.CLEARING_CALENDAR`
- `ATS.CLEARING_MEMBERS`
- `ATS.CLIENTS_ACCOUNTS_QTAB`
- `ATS.CLIENTS_ASSOCIATION`
- `ATS.CLIENTS_ASSOCIATION_BKP_20260107`
- `ATS.CLIENTS_SEN`
- `ATS.CLIENTS_T`
- `ATS.CLIENTS_TEMP`
- `ATS.CLIENT_AVAILABLE_COLLATERALS`
- `ATS.CLIENT_AVAILABLE_HOLDING`
- `ATS.CLIENT_TERMINAL_BINDING`
- `ATS.CLOSING_PRICE_MECHANISM`
- `ATS.COLLATERAL_TYPES`
- `ATS.COMPANIES`
- `ATS.COMPANIES_EXCHANGES`
- `ATS.COMPANIES_INFO`
- `ATS.CONTACT_ENTITIES`
- `ATS.CONTRACT_NOTIFICATION`
- `ATS.CONTRACT_NOTIFICATION_HISTORY`
- `ATS.COUNTRIES`
- `ATS.COUPON_FREQUENCY`
- `ATS.CP_TEMP`
- `ATS.CURRENCY`
- `ATS.CURRENCY_RATES`
- `ATS.DAY_COUNT_CONVENTION`
- `ATS.DEPO_TRANS_PENDING`
- `ATS.DEPO_TRANS_STATS`
- `ATS.DEP_TRANS_QTAB`
- `ATS.DUMMY`
- `ATS.EDS_CLIENTS_BKP_20260107`
- `ATS.EMAIL_SUBSCRIBERS`
- `ATS.ERROR_LOG`
- `ATS.ETF_TYPE`
- `ATS.EXCHANGE_INDICATORS`
- `ATS.EXCHANGE_MARKETS`
- `ATS.EXCHANGE_MARKET_TENOR_OPTIONS`
- `ATS.EXCHANGE_PARAMS_DETAIL`
- `ATS.EXCHANGE_PARAMS_MASTER`
- `ATS.EXCHANGE_SCHEDULES`
- `ATS.EXCHANGE_STATES`
- `ATS.EXCHMKT_ORDER_QUALIFIERS`
- `ATS.EXCHMKT_ORDER_TYPES`
- `ATS.EXCHMKT_TIF_OPTIONS`
- `ATS.FAVOURITE_SECURITIES`
- `ATS.FIX_CONNECTION_INFO`
- `ATS.FUND_PORTFOLIO`
- `ATS.FUTURE_CONTRACTS`
- `ATS.FUTURE_NET_POSITION`
- `ATS.INDEX_COMPOSITION`
- `ATS.INDEX_COMPOSITION_DETAIL`
- `ATS.INDEX_INDICATORS`
- `ATS.INDICES`
- `ATS.INSTRUMENT_SEN`
- `ATS.INSTRUMENT_SEN_05_SEP`
- `ATS.INSTRUMENT_SEN_29_AUG`
- `ATS.INSTRUMENT_SEN_DEL`
- `ATS.ISSUER`
- `ATS.ISSUER_BKP_20260107`
- `ATS.ISSUER_SEN`
- `ATS.JAVA$OPTIONS`
- `ATS.LEVY_DATA_LOG`
- `ATS.LEVY_EXCHANGE_RATE`
- `ATS.LEVY_PERCENT_OFF`
- `ATS.LEVY_PROC_STATUS`
- `ATS.LEVY_RECURRENCE`
- `ATS.LOAN_FEE_TYPES`
- `ATS.LOG_TEMP`
- `ATS.MARKETS`
- `ATS.MARKET_MAKER_ISSUERS`
- `ATS.MARKET_MAKER_SYMBOLS`
- `ATS.MARKET_SCHEDULES`
- `ATS.MARKET_STATES`
- `ATS.MARKET_STATE_INFO`
- `ATS.MARKET_STAT_QTAB`
- `ATS.MARKET_TYPES`
- `ATS.MENU_ITEMS`
- `ATS.MODULE`
- `ATS.MODULES`
- `ATS.MODULE_INSTANCES`
- `ATS.MODULE_INST_SYMBOL_GROUPS`
- `ATS.MODULE_INST_USER_RANGES`
- `ATS.MODULE_OPTIONS`
- `ATS.MONEY_MARKET_TYPE`
- `ATS.MTM`
- `ATS.NEGOTIATED_CAP_RANGES`
- `ATS.NEGOTIATED_ORDER_STATES`
- `ATS.NEGOTIATED_TRADES_TEMP`
- `ATS.NEGOTIATED_VOLUME_BASE`
- `ATS.NET_POSITION`
- `ATS.NON_BUSINESS_DAYS`
- `ATS.NOTIFICATION_SUBSCRIBERS`
- `ATS.NOTIFICATION_TYPES`
- `ATS.OPTION_PRIVS`
- `ATS.ORDERS_ARCHIVED_PROD`
- `ATS.ORDER_MAPPING_T`
- `ATS.ORDER_QUALIFIERS`
- `ATS.PARTICIPANTS_SEN`
- `ATS.PARTICIPANTS_SEN_29_AUG`
- `ATS.PARTICIPANTS_TEMP`
- `ATS.PARTICIPANT_ALLOWED_MARKETS`
- `ATS.PARTICIPANT_DEFAULT_COUNTERPARTY`
- `ATS.PARTICIPANT_DEFAULT_COUNTERPARTY_BK`
- `ATS.PASSWORD_POLICY`
- `ATS.PRICE_MOVEMENT_BANDS`
- `ATS.PRICE_TICK_RANGES`
- `ATS.PRICE_TICK_RANGES_DETAIL`
- `ATS.PROCEDURE_STATUS`
- `ATS.PROCESSES_LOG`
- `ATS.PROC_STATUS_QTAB`
- `ATS.QUOTE_ALERT_LOGS`
- `ATS.REFRENCE_PRICE`
- `ATS.REGISTRARS`
- `ATS.REJECTED_ORDERS_ARCHIVED_PROD`
- `ATS.RELATIONS`
- `ATS.REMAINING_ORDERS`
- `ATS.REPO_CONTRACTS_ZESHAN`
- `ATS.REPO_EVENT_LOGS`
- `ATS.REPO_EVENT_LOGS_ZESHAN`
- `ATS.RES_MATURITY_CB_RANGES`
- `ATS.RES_MATURITY_CB_RANGES_OVERRIDE`
- `ATS.RMS_CONFIGURATION`
- `ATS.ROLES`
- `ATS.ROLES_PRIVS`
- `ATS.ROLE_DETAIL`
- `ATS.ROLE_MENU_ACCESS`
- `ATS.ROME_MODULES`
- `ATS.ROME_PRIVILEGES`
- `ATS.ROME_ROLES`
- `ATS.ROME_ROLE_PRIVS`
- `ATS.ROME_USERS_ROLES`
- `ATS.SDI_TEMP`
- `ATS.SEARCH_GRID`
- `ATS.SEARCH_GRID_COLUMNS`
- `ATS.SECTORS`
- `ATS.SECURITY_TEMP`
- `ATS.SLB_CONTRACTS`
- `ATS.SLB_FEE_LOGS`
- `ATS.SLB_LOG`
- `ATS.SLB_TENORS`
- `ATS.STATS_TABLE`
- `ATS.SUBSCRIBED_BROKERS_BK`
- `ATS.SUBSCRIBED_BROKERS_BKP_20260107`
- `ATS.SYMBOLS_05SEP`
- `ATS.SYMBOLS_BKP_20260107`
- `ATS.SYMBOL_05SEP`
- `ATS.SYMBOL_CATEGORY`
- `ATS.SYMBOL_CHART_CANDLESTICK_15D`
- `ATS.SYMBOL_CHART_CANDLESTICK_15M`
- `ATS.SYMBOL_CHART_CANDLESTICK_1D`
- `ATS.SYMBOL_CHART_CANDLESTICK_1H`
- `ATS.SYMBOL_CHART_CANDLESTICK_1M`
- `ATS.SYMBOL_CHART_CANDLESTICK_1MO`
- `ATS.SYMBOL_CHART_CANDLESTICK_1W`
- `ATS.SYMBOL_CHART_CANDLESTICK_1Y`
- `ATS.SYMBOL_CHART_CANDLESTICK_2Y`
- `ATS.SYMBOL_CHART_CANDLESTICK_3Y`
- `ATS.SYMBOL_CHART_CANDLESTICK_4H`
- `ATS.SYMBOL_CHART_CANDLESTICK_4Y`
- `ATS.SYMBOL_CHART_CANDLESTICK_5M`
- `ATS.SYMBOL_CHART_CANDLESTICK_5Y`
- `ATS.SYMBOL_CHART_CANDLESTICK_6MO`
- `ATS.SYMBOL_CLEARING_SCHEDULES`
- `ATS.SYMBOL_DAILY_INDICATORS_05_SEP`
- `ATS.SYMBOL_DAILY_INDICATORS_BKP_20260107`
- `ATS.SYMBOL_EXCHANGES`
- `ATS.SYMBOL_FISDETAIL`
- `ATS.SYMBOL_FISDETAIL_05SEP`
- `ATS.SYMBOL_FISDETAIL_BKP_20260107`
- `ATS.SYMBOL_GROUPS`
- `ATS.SYMBOL_MARKETS_05SEP`
- `ATS.SYMBOL_MARKETS_BKP_20260107`
- `ATS.SYMBOL_ORDERS_YIELD`
- `ATS.SYMBOL_RISK_CONFIGURATION`
- `ATS.SYMBOL_SCHEDULES`
- `ATS.SYMBOL_STATES`
- `ATS.SYMBOL_TRADES_YIELD`
- `ATS.SYSTEM_CONFIG_PARAMS`
- `ATS.SYS_IOT_OVER_143671`
- `ATS.SYS_IOT_OVER_143676`
- `ATS.SYS_IOT_OVER_143681`
- `ATS.SYS_IOT_OVER_143702`
- `ATS.SYS_IOT_OVER_143705`
- `ATS.SYS_IOT_OVER_143726`
- `ATS.SYS_IOT_OVER_143731`
- `ATS.TEMP_TBL`
- `ATS.TENOR_OPTIONS`
- `ATS.TIF_OPTIONS`
- `ATS.TRADES_SCONV`
- `ATS.TRADES_SCONV_BK`
- `ATS.TRADES_TEMP`
- `ATS.TRADE_MODIFICATION_HIST`
- `ATS.TRADE_TYPES`
- `ATS.TRANSACTIONS_LEVY_DATA`
- `ATS.TRANSACTION_TYPES`
- `ATS.TRN_CODE`
- `ATS.USERS_BKP_20260107`
- `ATS.USERS_REQ`
- `ATS.USERS_ROLES`
- `ATS.USERS_ROLES_BKP_20260107`
- `ATS.USERS_SEN`
- `ATS.USER_ALERTS`
- `ATS.USER_STATUS`
- `ATS.USER_TRADES`
- `ATS.USER_TYPES`
- `ATS.WEEKLY_OFF_DAYS`
- `ATS.YIELD_CONTRIBUTIONS`
- `ATS.YIELD_CONTRIBUTION_INDICATORS`

## Tables Only in Schema Card (missing from Live DB)

_None – all schema card tables present in DB._

---

## Critical Guardrails and Notes from Schema Card

1. **No `ORDER_NO` on TRADES** – Do NOT use `TRADES.ORDER_NO` (does not exist). Link orders via `TRADES.BUYER_ORDER_NO` / `TRADES.SELLER_ORDER_NO` → `ORDERS.ORDER_NO`.

2. **TRADES profit** – For broker/client profit questions use `SUM(ACCRUED_PROFIT)`, NOT `SUM(VALUE)` or notional.

3. **Output guardrail** – Final user-facing outputs must be business-friendly: use labels/names over IDs (e.g. `EDS_CLIENTS.NAME`, `SUBSCRIBED_BROKERS.BROKER_NAME`, `SYMBOLS.SYMBOL`, `EXCHANGES.EXCHANGE_NAME`, `ORDER_STATES.STATE_CODE`, `TRADE_STATES.STATE_CODE`, `SETTLEMENT_TYPES.SETTLEMENT_TYPE`).

4. **REPO_CONTRACTS leg pairing** – `LEG=1` is the initial leg, `LEG=2` is repurchase. Use `INITIAL_DATE` / `TERMINATION_DATE` for active-contract filters.

5. **NEGOTIATED_TRADES party columns** – Uses `CLIENT_ID` / `COUNTER_CLIENT_ID`, NOT `BUYER_*` / `SELLER_*`.

6. **SETTLEMENT_LEVY_DATA date grain** – `TRANSACTION_DATE` is the primary date key for levy amount queries.

7. **Typo in schema card** – `REPO_CONTRACTS.NEW_CONTARCT_ID` is a known typo (should be `NEW_CONTRACT_ID`); both column names may exist in the live DB.

8. **ANSI joins only** – Use standard `JOIN ... ON ...` syntax; never use Oracle legacy `(+)` join syntax.
