#!/usr/bin/env python3
"""
scripts/rebuild_indexes.py — Build / rebuild FAISS RAG indexes.

Embeddings use sentence-transformers (BAAI/bge-small-en-v1.5 by default).
No Ollama required for this step.

Run:
    python scripts/rebuild_indexes.py            # build if missing
    python scripts/rebuild_indexes.py --force    # force full rebuild
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import argparse
import logging

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s"
)
logger = logging.getLogger(__name__)


def main():
    parser = argparse.ArgumentParser(description="Build FAISS RAG indexes")
    parser.add_argument("--force", action="store_true",
                        help="Force rebuild even if indexes already exist")
    args = parser.parse_args()

    from core.config import get_settings
    s = get_settings()

    logger.info("=== RAG Index Builder ===")
    logger.info("Embedding model : %s", s.EMBEDDING_MODEL)
    logger.info("Few-shots JSONL : %s", s.FEWSHOTS_JSONL)
    logger.info("Glossary  JSONL : %s", s.GLOSSARY_JSONL)
    logger.info("Output dir      : %s / %s", s.FAISS_FEWSHOTS_DIR, s.FAISS_GLOSSARY_DIR)
    logger.info("")

    # Pre-check JSONL files exist
    from pathlib import Path
    for label, path in [("Few-shots", s.FEWSHOTS_JSONL), ("Glossary", s.GLOSSARY_JSONL)]:
        p = Path(path)
        if not p.exists():
            logger.error("%s file not found: %s", label, path)
            sys.exit(1)
        # count = sum(1 for l in p.read_text().splitlines() if l.strip())
        # New - explicitly use UTF-8 (most common for .jsonl / modern text files)
        try:
            text = p.read_text(encoding="utf-8")
            count = sum(1 for l in text.splitlines() if l.strip())
        except UnicodeDecodeError:
            logger.warning(f"UTF-8 decoding failed for {path} — trying latin1 fallback (lossy)")
            text = p.read_text(encoding="latin1")           # worst case fallback
            count = sum(1 for l in text.splitlines() if l.strip())
        logger.info("%s: %d documents found", label, count)

    # Pre-load the embedding model so the user sees it downloading if needed
    logger.info("")
    logger.info("Loading embedding model (downloads ~33 MB on first run)…")
    from rag.embedder import get_embedder
    get_embedder()
    logger.info("Embedding model ready ✓")
    logger.info("")

    # Build indexes
    from rag.faiss_store import initialize_rag
    initialize_rag(rebuild=True)

    logger.info("")
    logger.info("=== Done! ===")
    logger.info("Indexes saved:")
    logger.info("  Few-shots → %s", s.FAISS_FEWSHOTS_DIR)
    logger.info("  Glossary  → %s", s.FAISS_GLOSSARY_DIR)
    logger.info("")
    logger.info("Next step:  python run.py")


if __name__ == "__main__":
    main()
