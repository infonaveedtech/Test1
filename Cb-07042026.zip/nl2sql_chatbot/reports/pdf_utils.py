# import os
# import shutil
# from jinja2 import Environment, FileSystemLoader, select_autoescape, TemplateNotFound

# # TEMPLATES_DIR = os.path.join(os.path.dirname(__file__), "..", "templates")
# TEMPLATES_DIR = os.path.join(os.path.dirname(__file__), "templates")
# TEMPLATES_DIR = os.path.abspath(TEMPLATES_DIR)

# _jenv = Environment(
#     loader=FileSystemLoader(TEMPLATES_DIR),
#     autoescape=select_autoescape(["html"]),
# )

# def render_report_html(context: dict) -> str:
#     layout_type = (context or {}).get("layout_type") or "flat"
#     layout_type = str(layout_type).lower()

#     if layout_type == "grouped":
#         try:
#             tpl = _jenv.get_template("report_grouped.html")
#         except TemplateNotFound:
#             tpl = _jenv.get_template("report.html")
#     else:
#         tpl = _jenv.get_template("report.html")

#     return tpl.render(**context)


# try:
#     import pdfkit
# except ImportError:
#     pdfkit = None


# # def resolve_wkhtmltopdf_path() -> str | None:
# #     """
# #     Resolution order:
# #     1. WKHTMLTOPDF_PATH from environment / .env
# #     2. PATH lookup
# #     """
# #     env_path = os.getenv("WKHTMLTOPDF_PATH", "").strip()
# #     if env_path:
# #         env_path = os.path.expanduser(os.path.expandvars(env_path))
# #         if os.path.isfile(env_path):
# #             return env_path

# #     discovered = shutil.which("wkhtmltopdf")
# #     if discovered:
# #         return discovered

# #     discovered = shutil.which("wkhtmltopdf.exe")
# #     if discovered:
# #         return discovered

# #     return None

# from core.config import get_settings

# def resolve_wkhtmltopdf_path() -> str | None:
#     """
#     Resolution order (stable across machines):
#     1. App settings (.env via pydantic)
#     2. Process env
#     3. System PATH
#     """
#     settings = get_settings()

#     # ✅ 1. From .env (MOST RELIABLE)
#     if settings.WKHTMLTOPDF_PATH:
#         path = os.path.expandvars(os.path.expanduser(settings.WKHTMLTOPDF_PATH.strip()))
#         if os.path.isfile(path):
#             return path

#     # ✅ 2. Direct env fallback
#     env_path = os.getenv("WKHTMLTOPDF_PATH", "").strip()
#     if env_path:
#         env_path = os.path.expandvars(os.path.expanduser(env_path))
#         if os.path.isfile(env_path):
#             return env_path

#     # ✅ 3. PATH fallback
#     return shutil.which("wkhtmltopdf") or shutil.which("wkhtmltopdf.exe")

# def _get_pdfkit_config():
#     if pdfkit is None:
#         raise RuntimeError("pdfkit is not installed. Run: pip install pdfkit")

#     wkhtml_path = resolve_wkhtmltopdf_path()
#     if not wkhtml_path:
#         raise RuntimeError(
#             "wkhtmltopdf could not be found. "
#             "Set WKHTMLTOPDF_PATH in your .env or make wkhtmltopdf available in PATH."
#         )

#     return pdfkit.configuration(wkhtmltopdf=wkhtml_path)


# def html_to_pdf_bytes(html: str) -> bytes:
#     if pdfkit is None:
#         raise RuntimeError("pdfkit is not installed. Run: pip install pdfkit")

#     config = _get_pdfkit_config()

#     options = {
#         "page-size": "A4",
#         "margin-top": "10mm",
#         "margin-right": "10mm",
#         "margin-bottom": "10mm",
#         "margin-left": "10mm",
#         "encoding": "UTF-8",
#         "enable-local-file-access": "",
#     }

#     return pdfkit.from_string(html, False, options=options, configuration=config)


# def build_report_pdf(context: dict) -> bytes:
#     html = render_report_html(context)
#     return html_to_pdf_bytes(html)

import os
import shutil
from pathlib import Path

from jinja2 import Environment, FileSystemLoader, select_autoescape, TemplateNotFound

from core.config import get_settings

# reports/templates
TEMPLATES_DIR = Path(__file__).resolve().parent / "templates"

_jenv = Environment(
    loader=FileSystemLoader(str(TEMPLATES_DIR)),
    autoescape=select_autoescape(["html"]),
)


def render_report_html(context: dict) -> str:
    layout_type = str((context or {}).get("layout_type") or "flat").lower()

    if layout_type == "grouped":
        try:
            tpl = _jenv.get_template("report_grouped.html")
        except TemplateNotFound:
            tpl = _jenv.get_template("report.html")
    else:
        tpl = _jenv.get_template("report.html")

    return tpl.render(**context)


try:
    import pdfkit
except ImportError:
    pdfkit = None


def _safe_settings_attr(settings, name: str, default=None):
    return getattr(settings, name, default)


def resolve_wkhtmltopdf_path() -> str | None:
    """
    Resolution order:
    1. App settings (.env via pydantic), if field exists
    2. Process env
    3. System PATH
    """

    settings = get_settings()

    # 1) From Settings model, but safely
    settings_path = _safe_settings_attr(settings, "WKHTMLTOPDF_PATH", None)
    if settings_path:
        candidate = os.path.expandvars(os.path.expanduser(str(settings_path).strip()))
        if os.path.isfile(candidate):
            return candidate

    # 2) Direct environment fallback
    env_path = os.getenv("WKHTMLTOPDF_PATH", "").strip()
    if env_path:
        candidate = os.path.expandvars(os.path.expanduser(env_path))
        if os.path.isfile(candidate):
            return candidate

    # 3) PATH fallback
    discovered = shutil.which("wkhtmltopdf") or shutil.which("wkhtmltopdf.exe")
    if discovered:
        return discovered

    return None


def _get_pdfkit_config():
    if pdfkit is None:
        raise RuntimeError("pdfkit is not installed. Run: pip install pdfkit")

    wkhtml_path = resolve_wkhtmltopdf_path()
    if not wkhtml_path:
        raise RuntimeError(
            "wkhtmltopdf could not be found. "
            "Set WKHTMLTOPDF_PATH in .env, or install wkhtmltopdf and add it to PATH."
        )

    return pdfkit.configuration(wkhtmltopdf=wkhtml_path)


def html_to_pdf_bytes(html: str) -> bytes:
    if pdfkit is None:
        raise RuntimeError("pdfkit is not installed. Run: pip install pdfkit")

    config = _get_pdfkit_config()

    options = {
        "page-size": "A4",
        "margin-top": "10mm",
        "margin-right": "10mm",
        "margin-bottom": "10mm",
        "margin-left": "10mm",
        "encoding": "UTF-8",
        "enable-local-file-access": "",
    }

    return pdfkit.from_string(html, False, options=options, configuration=config)


def build_report_pdf(context: dict) -> bytes:
    html = render_report_html(context)
    return html_to_pdf_bytes(html)