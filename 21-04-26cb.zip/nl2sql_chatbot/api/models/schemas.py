"""
api/models/schemas.py — All Pydantic request/response models.
"""
from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional
from pydantic import BaseModel, Field


# ── Sessions ──────────────────────────────────────────────────────────────────

class CreateSessionRequest(BaseModel):
    title: str = Field("New Chat", description="Optional display title for the session.")


class SetSessionStarRequest(BaseModel):
    starred: bool


class SessionResponse(BaseModel):
    session_id: str
    title: str
    created_at: float
    updated_at: float
    starred: bool = False


class SessionListResponse(BaseModel):
    sessions: List[SessionResponse]
    total: int


# ── Chat ──────────────────────────────────────────────────────────────────────

class ChatRequest(BaseModel):
    session_id: str = Field(..., description="Session to send this message to.")
    message: str = Field(..., min_length=1, description="User's natural language message.")
    clarifications: Optional[List[str]] = Field(
        None, description="Answers to previous clarification questions."
    )
    row_limit: int = Field(200, ge=1, le=5000)


class DataResult(BaseModel):
    columns: List[str]
    rows: List[List[Any]]
    row_count: int
    row_limit: int
    truncated: bool


class ChatResponse(BaseModel):
    run_id: str
    session_id: str
    status: Literal["success", "clarification", "direct", "error"]
    message: str = Field(..., description="Primary response text to display in chat.")
    summary: str = ""
    key_facts: List[str] = []
    follow_up_suggestions: List[str] = []
    clarification_questions: List[str] = []
    data: Optional[DataResult] = None
    intent: str = ""
    timing_ms: Dict[str, float] = {}


# ── Runs ──────────────────────────────────────────────────────────────────────

class RunDetailResponse(BaseModel):
    run_id: str
    session_id: str
    question: str
    intent: Optional[str] = None
    rephrased_query: Optional[str] = None
    plan_envelope: Optional[Dict[str, Any]] = None
    composed_sql: Optional[str] = None
    verified_sql: Optional[str] = None
    db_columns: Optional[List[str]] = None
    db_rows: Optional[List[List[Any]]] = None
    db_row_count: Optional[int] = None
    answer_text: Optional[str] = None
    answer_summary: Optional[str] = None
    answer_key_facts: Optional[List[str]] = None
    status: str
    error_message: Optional[str] = None
    timing_ms: Optional[Dict[str, Any]] = None
    created_at: float
    completed_at: Optional[float] = None


class RunListResponse(BaseModel):
    runs: List[RunDetailResponse]
    total: int


# ── Export ────────────────────────────────────────────────────────────────────

class ExportRequest(BaseModel):
    run_id: str
    format: Literal["pdf", "docx", "csv"] = "pdf"
    title: str = "Analytics Report"
    generated_by: str = "Chatbot"
    show_sql: bool = False


class ExportResponse(BaseModel):
    run_id: str
    format: str
    filename: str
    mime: str
    file_base64: str


# ── Health ────────────────────────────────────────────────────────────────────

class HealthResponse(BaseModel):
    status: str
    ollama: bool
    oracle: bool
    rag_fewshots: bool
    rag_glossary: bool
    version: str = "2.0.0"