from pathlib import Path

from .report_utils import (
    build_report_context,
    apply_column_customizations,
    apply_layout_grouping,
    build_docx_bytes,
    build_csv_bytes,
)
from .pdf_utils import build_report_pdf, render_report_html


def generate_report(
    run_data: dict,
    format: str = "pdf",
    title: str | None = None,
    generated_by: str | None = None,
) -> bytes:

    fmt = (format or "pdf").lower()

    # ✅ FIX: robust mapping (THIS FIXES TABLE ISSUE)
    question = (
        run_data.get("question")
        or run_data.get("user_message")
        or run_data.get("prompt")
        or ""
    )

    sql = (
        run_data.get("sql")
        or run_data.get("final_sql")
        or run_data.get("verified_sql")
        or ""
    )

    columns = (
        run_data.get("columns")
        or run_data.get("db_columns")
        or run_data.get("result_columns")
        or []
    )

    rows = (
        run_data.get("rows")
        or run_data.get("db_rows")
        or run_data.get("result_rows")
        or []
    )

    timing = run_data.get("timing_ms") or {}

    ctx = build_report_context(
        title=title or "Analytics Report",  # ✅ don't use raw question as title
        question=question,
        sql=sql,
        columns=columns,
        rows=rows,
        model=run_data.get("model", ""),
        gen_ms=run_data.get("gen_ms") or timing.get("generation"),
        exec_ms=run_data.get("exec_ms") or timing.get("execution"),
        rows_est=run_data.get("rows_est") or run_data.get("db_row_count") or len(rows),
        generated_by=generated_by or "AI Reporting System",
    )

    # ✅ FIX: correct row count
    ctx["rows_returned"] = run_data.get("db_row_count") or len(rows)

    # ✅ FIX: absolute logo path (THIS FIXES LOGO ISSUE)
    logo_path = Path(__file__).resolve().parent / "templates" / "assets" / "2.png"
    if logo_path.exists():
        ctx["logo_url"] = logo_path.as_uri()
    else:
        ctx["logo_url"] = ""

    ctx = apply_column_customizations(ctx, run_data.get("column_rules"))
    ctx = apply_layout_grouping(ctx, run_data.get("layout"))

    if fmt == "pdf":
        return build_report_pdf(ctx)

    if fmt == "docx":
        return build_docx_bytes(ctx)

    if fmt == "csv":
        return build_csv_bytes(ctx["columns"], ctx["rows"])

    if fmt == "html":
        return render_report_html(ctx).encode("utf-8")

    raise ValueError(f"Unsupported format: {format}")