Alright, Now here is what ive found recently. 

We were using a db schema, That is avaialble into the schema card as well, Based on that we have the Glossary and Fewshot docs which helps us to ive to the model to see what kinda query it will make to get that data, Now.. it comes out that the DB schema has updated, with multiple tables gone, updated and newer tables came as well.

Now most of them are type changes, and i dont tink we will have to update so many things for them. But the main updations would be in the places where the old columns are removed right, 

So this is the first thing that we need to do, I have a comparison of our DB with the schema card we are using. 

Lets identify those columns , see where they were used in glossary, fewshots, agentic prompts, schema card, OR anywhere else in the code. And then we will be able to 