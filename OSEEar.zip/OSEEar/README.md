## Price Tag Reader (Gemini)

### Setup
1) Create venv:
- python -m venv .venv
- Windows: .venv\Scripts\activate
- Mac/Linux: source .venv/bin/activate

2) Install deps:
- pip install -r requirements.txt

3) Add env:
- copy .env.example to .env
- set GEMINI_API_KEY

4) Put images:
- data/images/sample.jpg

5) Run smoke test:
- python scripts/run_single_image.py