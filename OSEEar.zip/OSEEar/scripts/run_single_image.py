import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT))

import cv2

from src.config import get_settings
from src.tiling import generate_tiles, visualize_tiles


def main():

    settings = get_settings()

    img_path = Path("data/images/Image (2).jpg")

    image = cv2.imread(str(img_path))

    tiles = generate_tiles(
        image=image,
        grid=settings.tile_grid,
        overlap=settings.tile_overlap,
    )

    print(f"Generated {len(tiles)} tiles")

    for tile in tiles:
        print(
            tile.tile_id,
            f"offset=({tile.offset_x},{tile.offset_y})",
            f"size=({tile.width}x{tile.height})",
        )

    vis = visualize_tiles(image, tiles)

    out_path = Path(settings.output_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    vis_file = out_path / "tiles_visualization.jpg"

    cv2.imwrite(str(vis_file), vis)

    print(f"Saved visualization to: {vis_file}")


if __name__ == "__main__":
    main()