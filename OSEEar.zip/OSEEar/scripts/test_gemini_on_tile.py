import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT))

import cv2

from src.config import get_settings
from src.tiling import generate_tiles
from src.providers.gemini_provider import GeminiProvider


def main():
    s = get_settings()

    img_path = Path("data/images/Image (2).jpg")
    image = cv2.imread(str(img_path))
    if image is None:
        raise RuntimeError(f"Failed to load image: {img_path}")

    tiles = generate_tiles(image, grid=s.tile_grid, overlap=s.tile_overlap)
    print(f"Tiles: {len(tiles)}")

    provider = GeminiProvider(api_key=s.gemini_api_key, model=s.gemini_model)

    # Test only the first tile to verify integration
    tile = tiles[0]
    print(f"Calling Gemini on {tile.tile_id} size={tile.width}x{tile.height} ...")

    tags = provider.infer_tile(tile, max_tags_hint=s.max_tags_per_tile)

    print(f"Returned tags: {len(tags)}")
    if tags:
        print("First tag:", tags[0].model_dump())


if __name__ == "__main__":
    main()