from __future__ import annotations

import math
from dataclasses import dataclass
from typing import List, Tuple

import numpy as np
import cv2


@dataclass
class Tile:
    tile_id: str
    image: np.ndarray
    offset_x: int
    offset_y: int
    width: int
    height: int


def parse_grid(grid: str) -> Tuple[int, int]:
    """
    Parse grid string like '2x2' or '3x3'
    """
    try:
        rows, cols = grid.lower().split("x")
        return int(rows), int(cols)
    except Exception:
        raise ValueError(f"Invalid tile_grid format: {grid}. Use format like '2x2' or '3x3'")


def generate_tiles(
    image: np.ndarray,
    grid: str = "2x2",
    overlap: float = 0.15,
) -> List[Tile]:
    """
    Split image into overlapping tiles.

    Returns list of Tile objects with image data and offsets.
    """

    img_h, img_w = image.shape[:2]

    rows, cols = parse_grid(grid)

    # base tile size without overlap
    base_tile_w = math.ceil(img_w / cols)
    base_tile_h = math.ceil(img_h / rows)

    # overlap in pixels
    overlap_w = int(base_tile_w * overlap)
    overlap_h = int(base_tile_h * overlap)

    tiles: List[Tile] = []

    tile_index = 0

    for row in range(rows):
        for col in range(cols):

            x0 = col * base_tile_w - overlap_w
            y0 = row * base_tile_h - overlap_h

            x1 = (col + 1) * base_tile_w + overlap_w
            y1 = (row + 1) * base_tile_h + overlap_h

            # clamp to image bounds
            x0 = max(0, x0)
            y0 = max(0, y0)

            x1 = min(img_w, x1)
            y1 = min(img_h, y1)

            tile_img = image[y0:y1, x0:x1].copy()

            tile = Tile(
                tile_id=f"tile_{tile_index:03d}",
                image=tile_img,
                offset_x=x0,
                offset_y=y0,
                width=x1 - x0,
                height=y1 - y0,
            )

            tiles.append(tile)

            tile_index += 1

    return tiles


def visualize_tiles(image: np.ndarray, tiles: List[Tile]) -> np.ndarray:
    """
    Debug function: draw tile boundaries on original image
    """

    vis = image.copy()

    for tile in tiles:

        x0 = tile.offset_x
        y0 = tile.offset_y

        x1 = x0 + tile.width
        y1 = y0 + tile.height

        cv2.rectangle(
            vis,
            (x0, y0),
            (x1, y1),
            (0, 255, 0),
            2,
        )

        cv2.putText(
            vis,
            tile.tile_id,
            (x0 + 5, y0 + 25),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.6,
            (0, 255, 0),
            2,
            cv2.LINE_AA,
        )

    return vis