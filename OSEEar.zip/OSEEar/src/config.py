import os
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()


@dataclass(frozen=True)
class Settings:
    gemini_api_key: str
    gemini_model: str = "gemini-2.0-flash"

    # tiling
    tile_grid: str = "2x2"          # "2x2" or "3x3"
    tile_overlap: float = 0.15      # 0.0 - 0.3

    # merging
    iou_threshold: float = 0.5
    min_conf: float = 0.35

    # limits
    max_tags_per_tile: int = 300

    # output
    output_dir: str = "data/outputs"


def get_settings() -> Settings:
    api_key = os.getenv("GEMINI_API_KEY", "").strip()
    if not api_key:
        raise RuntimeError(
            "GEMINI_API_KEY is missing. Create a .env file and set GEMINI_API_KEY."
        )

    return Settings(
        gemini_api_key=api_key,
        gemini_model=os.getenv("GEMINI_MODEL", "gemini-2.0-flash").strip(),
        tile_grid=os.getenv("TILE_GRID", "2x2").strip(),
        tile_overlap=float(os.getenv("TILE_OVERLAP", "0.15")),
        iou_threshold=float(os.getenv("IOU_THRESHOLD", "0.5")),
        min_conf=float(os.getenv("MIN_CONF", "0.35")),
        max_tags_per_tile=int(os.getenv("MAX_TAGS_PER_TILE", "300")),
        output_dir=os.getenv("OUTPUT_DIR", "data/outputs").strip(),
    )