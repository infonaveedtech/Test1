from __future__ import annotations

import json
import re
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

import cv2
import numpy as np
from google import genai
from google.genai import types

from src.schemas import BBox, PriceRead, TagDetection
from src.tiling import Tile


# -----------------------------
# Prompt (single pass per tile)
# -----------------------------
DETECT_AND_READ_PROMPT = """
Analyze this retail shelf image tile.

Task:
1) Detect ALL shelf price tags visible in the tile (the small labels attached to shelf edges).
2) For each detected price tag, extract the price shown on the tag.

Rules:
- Only include shelf price tags (ignore product/package text).
- Return bounding boxes in PIXEL coordinates relative to THIS TILE.
- Use bbox format: { "x": int, "y": int, "w": int, "h": int }
- If the price is unreadable, set raw_price=null and normalized_price=null and set read_conf=0.
- confidence/read_conf must be between 0 and 1.

Return STRICT JSON only, no markdown, in this schema:

{
  "tags": [
    {
      "bbox": {"x": 0, "y": 0, "w": 0, "h": 0},
      "raw_price": "$7.40",
      "normalized_price": 7.40,
      "det_conf": 0.80,
      "read_conf": 0.75
    }
  ]
}

Important:
- Do not output any extra keys outside this structure.
- Do not include comments.
"""


# -----------------------------
# Helpers
# -----------------------------
def _encode_image_to_jpeg_bytes(image_bgr: np.ndarray, quality: int = 90) -> bytes:
    """
    Convert OpenCV BGR image to JPEG bytes for Gemini input.
    """
    ok, buf = cv2.imencode(".jpg", image_bgr, [int(cv2.IMWRITE_JPEG_QUALITY), quality])
    if not ok:
        raise RuntimeError("Failed to encode tile image to JPEG.")
    return buf.tobytes()


def _strip_code_fences(text: str) -> str:
    """
    Gemini sometimes returns JSON inside ```json ... ``` fences.
    """
    text = text.strip()
    # Remove ```json ... ``` or ``` ... ```
    if text.startswith("```"):
        text = re.sub(r"^```[a-zA-Z]*\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
    return text.strip()


def _safe_json_loads(text: str) -> Dict[str, Any]:
    """
    Robust JSON parsing:
    - strips code fences
    - handles quoted JSON (JSON string containing JSON)
    """
    cleaned = _strip_code_fences(text)

    # First parse attempt
    try:
        obj = json.loads(cleaned)
    except json.JSONDecodeError:
        # Sometimes model adds leading/trailing text; try extracting the largest JSON object
        match = re.search(r"\{.*\}", cleaned, flags=re.DOTALL)
        if not match:
            raise
        obj = json.loads(match.group(0))

    # If JSON is returned as a STRING (e.g. "\"{...}\""), parse again
    if isinstance(obj, str):
        obj = json.loads(obj)

    if not isinstance(obj, dict):
        raise ValueError("Parsed JSON is not an object.")
    return obj


def _normalize_bbox(b: Dict[str, Any], tile_w: int, tile_h: int) -> Optional[BBox]:
    """
    Clamp bbox to tile bounds and validate.
    """
    try:
        x = int(b["x"])
        y = int(b["y"])
        w = int(b["w"])
        h = int(b["h"])
    except Exception:
        return None

    if w <= 0 or h <= 0:
        return None

    # Clamp
    x = max(0, min(x, tile_w - 1))
    y = max(0, min(y, tile_h - 1))
    w = max(1, min(w, tile_w - x))
    h = max(1, min(h, tile_h - y))

    return BBox(x=x, y=y, w=w, h=h)


# -----------------------------
# Provider
# -----------------------------
@dataclass
class GeminiProvider:
    api_key: str
    model: str = "gemini-2.0-flash"

    def __post_init__(self) -> None:
        # Explicitly pass api_key (don’t rely on env)
        self.client = genai.Client(api_key=self.api_key)

    def infer_tile(self, tile: Tile, max_tags_hint: int = 300) -> List[TagDetection]:
        """
        Single Gemini call for one tile. Returns TagDetection list (tile-relative bboxes).
        """
        jpeg_bytes = _encode_image_to_jpeg_bytes(tile.image)

        image_part = types.Part.from_bytes(
            data=jpeg_bytes,
            mime_type="image/jpeg",
        )

        # Ask for JSON output
        # Note: response_mime_type='application/json' helps structured output mode. :contentReference[oaicite:1]{index=1}
        resp = self.client.models.generate_content(
            model=self.model,
            contents=[image_part, DETECT_AND_READ_PROMPT],
            config={
                "temperature": 0.0,
                "response_mime_type": "application/json",
                # Keep output bounded (still may be large if many tags)
                "max_output_tokens": 8192,
            },
        )

        if not getattr(resp, "text", None):
            return []

        data = _safe_json_loads(resp.text)

        tags_raw = data.get("tags", [])
        if not isinstance(tags_raw, list):
            return []

        out: List[TagDetection] = []
        tile_h, tile_w = tile.image.shape[:2]

        for i, t in enumerate(tags_raw[:max_tags_hint]):
            if not isinstance(t, dict):
                continue

            bbox = _normalize_bbox(t.get("bbox", {}), tile_w=tile_w, tile_h=tile_h)
            if bbox is None:
                continue

            det_conf = float(t.get("det_conf", 0.0) or 0.0)
            read_conf = float(t.get("read_conf", 0.0) or 0.0)

            raw_price = t.get("raw_price", None)
            normalized_price = t.get("normalized_price", None)

            # Normalize types
            if raw_price is not None and not isinstance(raw_price, str):
                raw_price = str(raw_price)

            if normalized_price is not None:
                try:
                    normalized_price = float(normalized_price)
                except Exception:
                    normalized_price = None

            read = PriceRead(
                raw_price=raw_price,
                normalized_price=normalized_price,
                currency=None,
                read_conf=max(0.0, min(1.0, read_conf)),
                reason=None if normalized_price is not None else "unreadable_or_missing",
            )

            det = TagDetection(
                id=f"{tile.tile_id}_tag_{i:03d}",
                bbox=bbox,
                det_conf=max(0.0, min(1.0, det_conf)),
                read=read,
            )
            out.append(det)

        return out