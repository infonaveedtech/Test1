from __future__ import annotations
from typing import List, Optional, Literal
from pydantic import BaseModel, Field


class BBox(BaseModel):
    # Pixel coordinates
    x: int = Field(ge=0)
    y: int = Field(ge=0)
    w: int = Field(gt=0)
    h: int = Field(gt=0)

    def x2(self) -> int:
        return self.x + self.w

    def y2(self) -> int:
        return self.y + self.h


class PriceRead(BaseModel):
    raw_price: Optional[str] = None
    normalized_price: Optional[float] = None
    currency: Optional[str] = None
    read_conf: float = Field(default=0.0, ge=0.0, le=1.0)
    reason: Optional[str] = None  # if unreadable


class TagDetection(BaseModel):
    id: str
    bbox: BBox
    det_conf: float = Field(ge=0.0, le=1.0)
    read: PriceRead


class TileMeta(BaseModel):
    tile_id: str
    offset_x: int
    offset_y: int
    tile_w: int
    tile_h: int
    grid: str  # e.g., "2x2"
    overlap: float


class TileResult(BaseModel):
    tile: TileMeta
    tags: List[TagDetection] = Field(default_factory=list)


class ExtractRequest(BaseModel):
    image_path: str
    provider: Literal["gemini"] = "gemini"
    return_annotated: bool = True
    return_json: bool = True


class ExtractResponse(BaseModel):
    image_w: int
    image_h: int
    tags: List[TagDetection]
    annotated_image_path: Optional[str] = None
    json_path: Optional[str] = None