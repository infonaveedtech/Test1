# app.py
import streamlit as st
from datetime import datetime, timedelta, date

from src.pipelines.db import _connect
from src.pipelines.monitor_window import get_monitor_rows_with_fallback
from src.pipelines.compare_core import load_baseline, build_embedding_from_rows, cosine_sim, top_deviations

st.set_page_config(page_title="Client Surveillance", layout="wide")
st.title("Client Surveillance: Baseline vs Monitor")

with st.sidebar:
    client_id = st.text_input("Client ID", value="1760981")
    monitor_start = st.date_input("Monitor start date", value=date(2022, 1, 3))
    weeks = st.selectbox("Window (weeks)", [1, 2, 4, 8, 12], index=2)
    threshold = st.slider("Threshold", 0.0, 1.0, 0.85, 0.01)
    search_days = st.selectbox("Fallback search range (±days)", [30, 60, 90, 180, 365], index=3)
    run = st.button("Run")

if run:
    cid = int(client_id)
    start_ts = datetime.combine(monitor_start, datetime.min.time())

    conn = _connect()

    baseline = load_baseline(conn, cid)
    if not baseline:
        st.error("No baseline found for this client. Build baseline first.")
        st.stop()

    rows, used_start, used_end, fallback_used = get_monitor_rows_with_fallback(
        conn, cid, start_ts, weeks=weeks, search_days=search_days
    )
    
        # show baseline row info
    st.subheader("Baseline row")
    st.json({
    "client_id": baseline["client_id"],
    "baseline_start": str(baseline["baseline_start"]),
    "baseline_end": str(baseline["baseline_end"]),
    "model_version": baseline["model_version"],
    "feature_set_hash": baseline["feature_set_hash"],
    "created_at": str(baseline["created_at"]),
    })


    if not rows:
        st.error("No monitor data found (even after fallback). Increase fallback range.")
        st.stop()
        
    from src.pipelines.monitor_window import fetch_trade_week_features

    base_rows = fetch_trade_week_features(conn, cid, baseline["baseline_start"], baseline["baseline_end"])
    _, baseline_means = build_embedding_from_rows(base_rows, baseline["feature_cols"])


    monitor_emb, monitor_means = build_embedding_from_rows(rows, baseline["feature_cols"])
    
    if len(baseline["embedding"]) != len(monitor_emb):
        st.error(
            f"Embedding length mismatch: "
            f"baseline={len(baseline['embedding'])}, "
            f"monitor={len(monitor_emb)}"
        )
        st.stop()
    
    sim = cosine_sim(baseline["embedding"], monitor_emb)

    # --- DEBUG: feature availability and norms ---
    st.subheader("DEBUG: vectors")

    feature_cols = baseline["feature_cols"]

    row_keys = set(rows[0].keys()) if rows else set()
    missing = [c for c in feature_cols if c not in row_keys]
    present = [c for c in feature_cols if c in row_keys]

    st.write("Baseline feature_cols count:", len(feature_cols))
    st.write("Monitor row keys count:", len(row_keys))
    st.write("Features present in monitor rows:", len(present))
    st.write("Features missing from monitor rows:", len(missing))
    if missing:
        st.write("Missing features:", missing[:50])

    st.write("Baseline embedding length:", len(baseline["embedding"]))
    st.write("Monitor embedding length:", len(monitor_emb))

    import math
    bn = math.sqrt(sum(x*x for x in baseline["embedding"])) if baseline["embedding"] else 0.0
    mn = math.sqrt(sum(x*x for x in monitor_emb)) if monitor_emb else 0.0
    st.write("Baseline embedding norm:", bn)
    st.write("Monitor embedding norm:", mn)

    dot = sum(x*y for x,y in zip(baseline["embedding"], monitor_emb)) if baseline["embedding"] and monitor_emb else 0.0
    st.write("Dot product:", dot)

    
    
    flagged = sim < threshold

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Cosine similarity", f"{sim:.8f}")
    c2.metric("Flag", "YES" if flagged else "NO")
    c3.metric("Threshold", f"{threshold:.2f}")
    c4.metric("Weeks used", str(len(rows)))

    st.caption(
        f"Requested: {start_ts.date()} → {(start_ts + timedelta(days=weeks*7)).date()} | "
        f"Used: {used_start.date()} → {used_end.date()} "
        f"{'(fallback)' if fallback_used else ''}"
    )

    st.subheader("Weekly feature rows")
    st.dataframe(rows)

    st.subheader("Top deviations")
    # st.dataframe(top_deviations(monitor_vec, baseline["mean"], baseline["std"], top_k=12))
    st.dataframe(top_deviations(monitor_means, baseline_means, top_k=12))

