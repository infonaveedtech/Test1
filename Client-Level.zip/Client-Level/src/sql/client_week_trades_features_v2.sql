WITH base_trades AS (
  SELECT
    t.BUYER_CLIENT_ID AS client_id,
    'B'              AS side,
    t.ENTRY_DATETIME AS entry_datetime,
    t.SYMBOL_ID      AS symbol_id,
    t.EXCHANGE_ID    AS exchange_id,
    t.MARKET_ID      AS market_id,
    t.PRICE          AS price,
    t.VOLUME         AS volume
  FROM ATS.TRADES t
  WHERE t.ENTRY_DATETIME >= :start_ts
    AND t.ENTRY_DATETIME <  :end_ts

  UNION ALL

  SELECT
    t.SELLER_CLIENT_ID AS client_id,
    'S'               AS side,
    t.ENTRY_DATETIME  AS entry_datetime,
    t.SYMBOL_ID       AS symbol_id,
    t.EXCHANGE_ID     AS exchange_id,
    t.MARKET_ID       AS market_id,
    t.PRICE           AS price,
    t.VOLUME          AS volume
  FROM ATS.TRADES t
  WHERE t.ENTRY_DATETIME >= :start_ts
    AND t.ENTRY_DATETIME <  :end_ts
),
bucketed AS (
  SELECT
    client_id,
    side,
    TRUNC(entry_datetime, 'IW') AS week_start,
    TRUNC(entry_datetime)       AS trade_day,
    symbol_id,
    market_id,
    (price * volume)            AS notional,
    price,
    volume
  FROM base_trades
),

client_week AS (
  SELECT
    client_id,
    week_start,
    market_id,

    COUNT(*)                                  AS trades_total,
    SUM(volume)                               AS volume_total,
    SUM(notional)                             AS notional_total,
    AVG(price)                                AS avg_price_simple,

    COUNT(DISTINCT trade_day)                 AS active_days,
    COUNT(DISTINCT symbol_id)                 AS unique_symbols,

    SUM(CASE WHEN side='B' THEN 1 ELSE 0 END) AS trades_buy,
    SUM(CASE WHEN side='S' THEN 1 ELSE 0 END) AS trades_sell,
    SUM(CASE WHEN side='B' THEN volume ELSE 0 END) AS volume_buy,
    SUM(CASE WHEN side='S' THEN volume ELSE 0 END) AS volume_sell

  FROM bucketed
  GROUP BY client_id, week_start, market_id
),

market_week AS (
  -- weekly market totals from daily indicators
  SELECT
    TRUNC(di.STATS_DATE, 'IW') AS week_start,
    di.MARKET_ID               AS market_id,
    
    -- Fixed: SYMBOL_DAILY_INDICATORS has no VOLUME column
    SUM(di.TURNOVER)           AS market_volume_total,      -- volume in shares/units
    SUM(di.TURNOVER_VALUE)     AS market_turnover_total,    -- monetary turnover/value
    SUM(di.TRADES_COUNT)       AS market_trades_total
    
  FROM ATS.SYMBOL_DAILY_INDICATORS di
  WHERE di.STATS_DATE >= TRUNC(:start_ts)
    AND di.STATS_DATE <  TRUNC(:end_ts)
  GROUP BY TRUNC(di.STATS_DATE, 'IW'), di.MARKET_ID
)

SELECT
  cw.client_id,
  cw.week_start,
  cw.market_id,

  cw.trades_total,
  cw.volume_total,
  cw.notional_total,
  cw.avg_price_simple,
  cw.active_days,
  cw.unique_symbols,
  cw.trades_buy,
  cw.trades_sell,
  cw.volume_buy,
  cw.volume_sell,

  mw.market_volume_total,
  mw.market_turnover_total,
  mw.market_trades_total,

  CASE
    WHEN mw.market_volume_total > 0 THEN cw.volume_total / mw.market_volume_total
    ELSE NULL
  END AS client_volume_share_week,

  CASE
    WHEN mw.market_turnover_total > 0 THEN cw.notional_total / mw.market_turnover_total
    ELSE NULL
  END AS client_turnover_share_week

FROM client_week cw
LEFT JOIN market_week mw
  ON mw.week_start = cw.week_start
 AND mw.market_id  = cw.market_id
ORDER BY cw.week_start DESC, cw.volume_total DESC;