WITH
-- =========================
-- TRADES → client-week
-- =========================
base_trades AS (
  SELECT
    t.BUYER_CLIENT_ID AS client_id,
    'B'              AS side,
    t.ENTRY_DATETIME AS entry_datetime,
    t.SYMBOL_ID      AS symbol_id,
    t.MARKET_ID      AS market_id,
    t.PRICE          AS price,
    t.VOLUME         AS volume
  FROM ATS.TRADES t
  WHERE t.ENTRY_DATETIME >= :start_ts
    AND t.ENTRY_DATETIME <  :end_ts

  UNION ALL

  SELECT
    t.SELLER_CLIENT_ID AS client_id,
    'S'                AS side,
    t.ENTRY_DATETIME   AS entry_datetime,
    t.SYMBOL_ID        AS symbol_id,
    t.MARKET_ID        AS market_id,
    t.PRICE            AS price,
    t.VOLUME           AS volume
  FROM ATS.TRADES t
  WHERE t.ENTRY_DATETIME >= :start_ts
    AND t.ENTRY_DATETIME <  :end_ts
),
trades_bucketed AS (
  SELECT
    client_id,
    side,
    TRUNC(entry_datetime, 'IW') AS week_start,
    TRUNC(entry_datetime)       AS trade_day,
    symbol_id,
    market_id,
    (price * volume)            AS notional,
    price,
    volume
  FROM base_trades
),
client_week_trades AS (
  SELECT
    client_id,
    week_start,
    market_id,
    COUNT(*)                                  AS trades_total,
    SUM(volume)                               AS trade_volume_total,
    SUM(notional)                             AS trade_notional_total,
    AVG(price)                                AS trade_avg_price_simple,
    COUNT(DISTINCT trade_day)                 AS trade_active_days,
    COUNT(DISTINCT symbol_id)                 AS trade_unique_symbols,
    SUM(CASE WHEN side='B' THEN 1 ELSE 0 END) AS trades_buy,
    SUM(CASE WHEN side='S' THEN 1 ELSE 0 END) AS trades_sell,
    SUM(CASE WHEN side='B' THEN volume ELSE 0 END) AS trade_volume_buy,
    SUM(CASE WHEN side='S' THEN volume ELSE 0 END) AS trade_volume_sell
  FROM trades_bucketed
  GROUP BY client_id, week_start, market_id
),

-- =========================
-- ORDERS → client-week
-- =========================
orders_base AS (
  SELECT
    o.CLIENT_ID          AS client_id,
    TRUNC(o.ENTRY_DATETIME, 'IW') AS week_start,
    o.MARKET_ID,
    o.SYMBOL_ID,
    o.SIDE               AS side,
    o.VOLUME,
    o.PRICE,
    (o.VOLUME * o.PRICE) AS order_notional,
    o.IS_SHORT,
    COALESCE(st.STATE_CODE, 'UNKNOWN') AS state_code,
    COALESCE(ot.CODE, 'UNKNOWN')       AS order_type_code,
    f.FLAG_CODE
  FROM ATS.ORDERS o
  LEFT JOIN ATS.ORDER_STATES st ON st.STATE_ID = o.STATE
  LEFT JOIN ATS.ORDER_TYPES  ot ON ot.ID      = o.ORDER_TYPE
  LEFT JOIN ATS.FLAGS        f  ON f.FLAG_ID  = o.FLAG_ID
  WHERE o.ENTRY_DATETIME >= :start_ts
    AND o.ENTRY_DATETIME <  :end_ts
),
client_week_orders AS (
  SELECT
    client_id,
    week_start,
    market_id,
    COUNT(*)                        AS orders_total,
    SUM(volume)                     AS order_volume_total,
    SUM(order_notional)             AS order_notional_total,
    AVG(price)                      AS order_avg_price,
    SUM(CASE WHEN side = 'B' THEN 1 ELSE 0 END) AS orders_buy,
    SUM(CASE WHEN side = 'S' THEN 1 ELSE 0 END) AS orders_sell,
    SUM(CASE WHEN UPPER(state_code) LIKE '%CANCEL%' THEN 1 ELSE 0 END) AS orders_cancel,
    SUM(CASE WHEN UPPER(state_code) LIKE '%REJECT%' THEN 1 ELSE 0 END) AS orders_reject,
    SUM(CASE WHEN UPPER(state_code) LIKE '%FILL%'   THEN 1 ELSE 0 END) AS orders_fill_like,
    SUM(CASE WHEN is_short = '1' THEN 1 ELSE 0 END) AS orders_short,
    COUNT(DISTINCT symbol_id)       AS order_unique_symbols
  FROM orders_base
  GROUP BY client_id, week_start, market_id
),

-- =========================
-- MARKET totals (weekly)
-- =========================
market_week AS (
  SELECT
    TRUNC(di.STATS_DATE, 'IW') AS week_start,
    di.MARKET_ID               AS market_id,
    SUM(di.TURNOVER)           AS market_volume_total,
    SUM(di.TURNOVER_VALUE)     AS market_turnover_total,
    SUM(di.TRADES_COUNT)       AS market_trades_total
  FROM ATS.SYMBOL_DAILY_INDICATORS di
  WHERE di.STATS_DATE >= TRUNC(:start_ts)
    AND di.STATS_DATE <  TRUNC(:end_ts)
  GROUP BY TRUNC(di.STATS_DATE, 'IW'), di.MARKET_ID
)

SELECT
  t.client_id,
  c.NAME                  AS client_name,           -- ← NEW: Client name
  t.week_start,
  t.market_id,
  mk.MARKET_DESC          AS market_name,           -- ← Market name (from previous suggestion)

  -- trades
  t.trades_total,
  t.trade_volume_total,
  t.trade_notional_total,
  t.trade_avg_price_simple,
  t.trade_active_days,
  t.trade_unique_symbols,
  t.trades_buy,
  t.trades_sell,
  t.trade_volume_buy,
  t.trade_volume_sell,

  -- orders
  o.orders_total,
  o.order_volume_total,
  o.order_notional_total,
  o.order_avg_price,
  o.orders_buy,
  o.orders_sell,
  o.orders_cancel,
  o.orders_reject,
  o.orders_fill_like,
  o.orders_short,
  o.order_unique_symbols,

  -- ratios
  CASE WHEN o.orders_total > 0 THEN o.orders_cancel * 1.0 / o.orders_total ELSE NULL END AS cancel_ratio,
  CASE WHEN t.trades_total > 0 THEN o.orders_total * 1.0 / t.trades_total ELSE NULL END AS order_to_trade_ratio,

  -- market
  mw.market_volume_total,
  mw.market_turnover_total,
  mw.market_trades_total,
  CASE WHEN mw.market_volume_total > 0 THEN t.trade_volume_total * 1.0 / mw.market_volume_total ELSE NULL END AS client_volume_share_week

FROM client_week_trades t
LEFT JOIN client_week_orders o
  ON o.client_id = t.client_id
 AND o.week_start = t.week_start
 AND o.market_id  = t.market_id
LEFT JOIN market_week mw
  ON mw.week_start = t.week_start
 AND mw.market_id  = t.market_id
LEFT JOIN ATS.EDS_CLIENTS c                     -- ← NEW
  ON c.CLIENT_ID = t.client_id
LEFT JOIN ATS.MARKETS mk                        -- ← Market name
  ON mk.MARKET_ID = t.market_id

-- NEW: Optional single-client filter (very useful for debugging & pipeline)
WHERE (:client_id IS NULL OR t.client_id = :client_id)

ORDER BY t.week_start DESC, t.trade_volume_total DESC;