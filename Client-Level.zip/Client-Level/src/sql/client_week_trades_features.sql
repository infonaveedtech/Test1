WITH base_trades AS (
  -- buyer side
  SELECT
    t.BUYER_CLIENT_ID AS client_id,
    'B'              AS side,
    t.ENTRY_DATETIME AS entry_datetime,
    t.SYMBOL_ID      AS symbol_id,
    t.EXCHANGE_ID    AS exchange_id,
    t.MARKET_ID      AS market_id,
    t.PRICE          AS price,
    t.VOLUME         AS volume
  FROM ATS.TRADES t
  WHERE t.ENTRY_DATETIME >= :start_ts
    AND t.ENTRY_DATETIME <  :end_ts

  UNION ALL

  -- seller side
  SELECT
    t.SELLER_CLIENT_ID AS client_id,
    'S'               AS side,
    t.ENTRY_DATETIME  AS entry_datetime,
    t.SYMBOL_ID       AS symbol_id,
    t.EXCHANGE_ID     AS exchange_id,
    t.MARKET_ID       AS market_id,
    t.PRICE           AS price,
    t.VOLUME          AS volume
  FROM ATS.TRADES t
  WHERE t.ENTRY_DATETIME >= :start_ts
    AND t.ENTRY_DATETIME <  :end_ts
),
bucketed AS (
  SELECT
    client_id,
    side,
    TRUNC(entry_datetime, 'IW') AS week_start,
    TRUNC(entry_datetime)       AS trade_day,
    symbol_id,
    (price * volume)            AS notional,
    price,
    volume
  FROM base_trades
)
SELECT
  client_id,
  week_start,

  COUNT(*)                                  AS trades_total,
  SUM(volume)                               AS volume_total,
  SUM(notional)                             AS notional_total,
  AVG(price)                                AS avg_price_simple,

  COUNT(DISTINCT trade_day)                 AS active_days,
  COUNT(DISTINCT symbol_id)                 AS unique_symbols,

  -- buy/sell splits
  SUM(CASE WHEN side='B' THEN 1 ELSE 0 END) AS trades_buy,
  SUM(CASE WHEN side='S' THEN 1 ELSE 0 END) AS trades_sell,
  SUM(CASE WHEN side='B' THEN volume ELSE 0 END) AS volume_buy,
  SUM(CASE WHEN side='S' THEN volume ELSE 0 END) AS volume_sell

FROM bucketed
GROUP BY client_id, week_start
ORDER BY week_start DESC, volume_total DESC
