-- src/sql/client_week_trades_features_only.sql
WITH base_trades AS (
  SELECT
    t.BUYER_CLIENT_ID AS client_id,
    t.ENTRY_DATETIME  AS entry_datetime,
    t.SYMBOL_ID       AS symbol_id,
    t.MARKET_ID       AS market_id,
    t.PRICE           AS price,
    t.VOLUME          AS volume
  FROM ATS.TRADES t
  WHERE t.ENTRY_DATETIME >= :start_ts
    AND t.ENTRY_DATETIME <  :end_ts
    AND (:client_id IS NULL OR t.BUYER_CLIENT_ID = :client_id)
),
bucketed AS (
  SELECT
    client_id,
    TRUNC(entry_datetime, 'IW') AS week_start,
    symbol_id,
    market_id,
    price,
    volume,
    (price * volume) AS notional,
    TRUNC(entry_datetime) AS trade_day
  FROM base_trades
)
SELECT
  client_id,
  week_start,
  market_id,
  COUNT(*)                  AS trades_total,
  SUM(volume)               AS trade_volume_total,
  SUM(notional)             AS trade_notional_total,
  AVG(price)                AS trade_avg_price_simple,
  COUNT(DISTINCT trade_day) AS trade_active_days,
  COUNT(DISTINCT symbol_id) AS trade_unique_symbols
FROM bucketed
GROUP BY client_id, week_start, market_id
ORDER BY week_start DESC
