# src/db.py
import os
import oracledb
from dotenv import load_dotenv
from contextlib import contextmanager

load_dotenv()

def _connect():
    dsn = os.getenv("ORACLE_DSN")
    user = os.getenv("ORACLE_USER")
    pwd = os.getenv("ORACLE_PASSWORD")
    owner = os.getenv("ORACLE_OWNER", user)

    if not dsn or not user or not pwd:
        raise RuntimeError(
            "Missing Oracle environment variables. "
            "Ensure ORACLE_DSN / ORACLE_USER / ORACLE_PASSWORD are set in .env"
        )

    conn = oracledb.connect(user=user, password=pwd, dsn=dsn)

    # Optional schema switch
    if owner:
        cur = conn.cursor()
        cur.execute(f"ALTER SESSION SET CURRENT_SCHEMA = {owner}")
        cur.close()

    return conn

@contextmanager
def oracle_cursor():
    conn = _connect()
    cur = conn.cursor()
    try:
        yield cur
    finally:
        try:
            cur.close()
        finally:
            conn.close()

def fetchmany(sql: str, params: dict | None = None, row_limit: int = 200):
    sql = sql.strip().rstrip(";")
    with oracle_cursor() as cur:
        cur.execute(sql, params or {})
        rows = cur.fetchmany(row_limit)
        cols = [d[0] for d in cur.description]
    return {"columns": cols, "rows": rows, "row_limit": row_limit}


def execute(sql: str, params: dict | None = None):
    sql = sql.strip().rstrip(";")
    with oracle_cursor() as cur:
        cur.execute(sql, params or {})
        cur.connection.commit()

def executemany(sql: str, rows: list[dict], batch_size: int = 2000):
    sql = sql.strip().rstrip(";")
    if not rows:
        return 0
    with oracle_cursor() as cur:
        total = 0
        for i in range(0, len(rows), batch_size):
            chunk = rows[i:i+batch_size]
            cur.executemany(sql, chunk)
            total += len(chunk)
        cur.connection.commit()
    return total


def fetch_one_clob(sql: str, params: dict | None = None):
    sql = sql.strip().rstrip(";")
    with oracle_cursor() as cur:
        cur.execute(sql, params or {})
        row = cur.fetchone()
        if not row:
            return None
        val = row[0]
        # Read LOB while connection is still open
        if hasattr(val, "read"):
            return val.read()
        return val

def _clob_to_str(v):
    # oracledb LOB has .read()
    if v is None:
        return None
    if hasattr(v, "read"):
        return v.read()
    return v

def fetchall(conn, sql: str, params: dict):
    cur = conn.cursor()
    cur.execute(sql, params or {})
    cols = [d[0].upper() for d in cur.description]
    out = []
    for r in cur.fetchall():
        row = {}
        for i, col in enumerate(cols):
            row[col] = _clob_to_str(r[i])
        out.append(row)
    return out

