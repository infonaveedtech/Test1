import json
import hashlib
from datetime import datetime, timezone
from collections import defaultdict
import math

import numpy as np

from db import fetchmany, executemany

MODEL_VERSION = "v0_feature_vector"
TARGET_TABLE = "CLIENT_BASELINE_EMBEDDINGS"

EMBED_COLS = [
  # Trades (activity + direction)
  "TRADES_TOTAL",
  "TRADE_VOLUME_TOTAL",
  "TRADE_NOTIONAL_TOTAL",
  "TRADE_AVG_PRICE_SIMPLE",
  "TRADE_ACTIVE_DAYS",
  "TRADE_UNIQUE_SYMBOLS",
  "TRADES_BUY",
  "TRADES_SELL",
  "TRADE_VOLUME_BUY",
  "TRADE_VOLUME_SELL",

  # Orders (intent + friction)
  "ORDERS_TOTAL",
  "ORDERS_CANCEL",
  "ORDERS_REJECT",
  "ORDERS_FILL_LIKE",
  "ORDERS_SHORT",
  "ORDER_UNIQUE_SYMBOLS",

  # Ratios (behavioral signatures)
  "CANCEL_RATIO",
  "ORDER_TO_TRADE_RATIO",

  # Market/participation (optional but valuable)
  "CLIENT_VOLUME_SHARE_WEEK",
]


# EMBED_COLS = [
#     "TRADES_TOTAL",
#     "TRADE_VOLUME_TOTAL",
#     "TRADE_NOTIONAL_TOTAL",
#     "TRADE_AVG_PRICE_SIMPLE",
#     "TRADE_ACTIVE_DAYS",
#     "TRADE_UNIQUE_SYMBOLS",
# ]


def feature_set_hash(cols):
    h = hashlib.sha256(",".join(cols).encode("utf-8")).hexdigest()
    return h

def safe_float(x):
    return 0.0 if x is None else float(x)

def l2_normalize(v):
    n = math.sqrt(float(np.dot(v, v)))
    if n == 0:
        return v
    return v / n

def main():
    # Baseline window (example: Jan 2022, but YOU will set 4 weeks you want)
    baseline_start = datetime(2022, 1, 3, tzinfo=timezone.utc)   # Monday
    baseline_end   = datetime(2022, 1, 31, tzinfo=timezone.utc)  # exclusive end (4 weeks)

    # Pull rows from the table you already populated
    sql = """
      SELECT *
      FROM CLIENT_WEEK_FEATURES
      WHERE WEEK_START >= :start_dt AND WEEK_START < :end_dt
    """
    res = fetchmany(sql, params={"start_dt": baseline_start, "end_dt": baseline_end}, row_limit=2000000)

    cols = [c.upper() for c in res["columns"]]
    rows = res["rows"]




    # Map column index
    idx = {c: i for i, c in enumerate(cols)}
    missing = [c for c in EMBED_COLS if c.upper() not in idx]
    print("Missing EMBED_COLS in CLIENT_WEEK_FEATURES:", missing)

    # Group per client: each client has multiple week rows (and maybe market rows)
    per_client = defaultdict(list)
    for r in rows:
        client_id = int(r[idx["CLIENT_ID"]])
        per_client[client_id].append(r)

    fs_hash = feature_set_hash([c.upper() for c in EMBED_COLS])

    upserts = []
    for client_id, client_rows in per_client.items():
        # Build matrix of features
        X = []
        weights = []
        for r in client_rows:
            vec = [safe_float(r[idx[c]]) for c in EMBED_COLS]
            X.append(vec)
            # weight by notional if present
            weights.append(safe_float(r[idx.get("TRADE_NOTIONAL_TOTAL")]))

        X = np.array(X, dtype=float)
        w = np.array(weights, dtype=float)
        if w.sum() <= 0:
            w = np.ones(len(X), dtype=float)

        # baseline scaling stats (per client)
        # mu = np.average(X, axis=0, weights=w)
        # var = np.average((X - mu) ** 2, axis=0, weights=w)
        # sigma = np.sqrt(var + 1e-12)
        # --- Simple baseline embedding: weighted raw centroid (no mean/std) ---
        centroid_raw = np.average(X, axis=0, weights=w)
        centroid_raw = l2_normalize(centroid_raw)


        # # normalized vectors, then baseline centroid
        # Xn = (X - mu) / (sigma + 1e-8)
        # centroid = np.average(Xn, axis=0, weights=w)
        # centroid = l2_normalize(centroid)

        # payload = {
        #     "model_version": MODEL_VERSION,
        #     "feature_cols": EMBED_COLS,
        #     "feature_set_hash": fs_hash,
        #     "baseline_mean": mu.tolist(),
        #     "baseline_std": sigma.tolist(),
        #     "embedding": centroid.tolist(),
        # }

        # upserts.append({
        #     "CLIENT_ID": client_id,
        #     "BASELINE_START": baseline_start,
        #     "BASELINE_END": baseline_end,
        #     "MODEL_VERSION": MODEL_VERSION,
        #     "FEATURE_SET_HASH": fs_hash,
        #     "EMBEDDING_JSON": json.dumps(payload),
        # })
        
        feature_keys = [c.upper() for c in EMBED_COLS]

        # mean_map = {feature_keys[i]: float(mu[i]) for i in range(len(feature_keys))}
        # std_map  = {feature_keys[i]: float(sigma[i]) for i in range(len(feature_keys))}

        upserts.append({
            "CLIENT_ID": client_id,
            "BASELINE_START": baseline_start,
            "BASELINE_END": baseline_end,
            "MODEL_VERSION": MODEL_VERSION,
            "FEATURE_SET_HASH": fs_hash,
            "EMBEDDING_JSON": json.dumps({
                "model_version": MODEL_VERSION,
                "feature_cols": [c.upper() for c in EMBED_COLS],
                "feature_set_hash": fs_hash,
                "embedding": centroid_raw.tolist(),
            }),
        })



    merge_sql = f"""
    MERGE INTO {TARGET_TABLE} t
    USING (
      SELECT
        :CLIENT_ID AS CLIENT_ID,
        :BASELINE_START AS BASELINE_START,
        :BASELINE_END AS BASELINE_END,
        :MODEL_VERSION AS MODEL_VERSION,
        :FEATURE_SET_HASH AS FEATURE_SET_HASH,
        :EMBEDDING_JSON AS EMBEDDING_JSON
      FROM dual
    ) s
    ON (
      t.CLIENT_ID = s.CLIENT_ID AND
      t.MODEL_VERSION = s.MODEL_VERSION AND
      t.BASELINE_START = s.BASELINE_START AND
      t.BASELINE_END = s.BASELINE_END
    )
    WHEN MATCHED THEN UPDATE SET
      t.FEATURE_SET_HASH = s.FEATURE_SET_HASH,
      t.EMBEDDING_JSON = s.EMBEDDING_JSON
    WHEN NOT MATCHED THEN INSERT (
      CLIENT_ID, BASELINE_START, BASELINE_END, MODEL_VERSION,
      FEATURE_SET_HASH, EMBEDDING_JSON
    ) VALUES (
      s.CLIENT_ID, s.BASELINE_START, s.BASELINE_END, s.MODEL_VERSION,
      s.FEATURE_SET_HASH, s.EMBEDDING_JSON
    )
    """
    
    # merge_sql = f"""
    # MERGE INTO {TARGET_TABLE} t
    # USING (
    # SELECT
    #     :CLIENT_ID AS CLIENT_ID,
    #     :BASELINE_START AS BASELINE_START,
    #     :BASELINE_END AS BASELINE_END,
    #     :MODEL_VERSION AS MODEL_VERSION,
    #     :FEATURE_SET_HASH AS FEATURE_SET_HASH,
    #     :EMBEDDING_JSON AS EMBEDDING_JSON,
    #     :MEAN_JSON AS MEAN_JSON,
    #     :STD_JSON AS STD_JSON,
    #     :FEATURE_KEYS_JSON AS FEATURE_KEYS_JSON
    # FROM dual
    # ) s
    # ON (
    # t.CLIENT_ID = s.CLIENT_ID AND
    # t.MODEL_VERSION = s.MODEL_VERSION AND
    # t.BASELINE_START = s.BASELINE_START AND
    # t.BASELINE_END = s.BASELINE_END
    # )
    # WHEN MATCHED THEN UPDATE SET
    # t.FEATURE_SET_HASH = s.FEATURE_SET_HASH,
    # t.EMBEDDING_JSON = s.EMBEDDING_JSON,
    # t.MEAN_JSON = s.MEAN_JSON,
    # t.STD_JSON = s.STD_JSON,
    # t.FEATURE_KEYS_JSON = s.FEATURE_KEYS_JSON
    # WHEN NOT MATCHED THEN INSERT (
    # CLIENT_ID, BASELINE_START, BASELINE_END, MODEL_VERSION,
    # FEATURE_SET_HASH, EMBEDDING_JSON, MEAN_JSON, STD_JSON, FEATURE_KEYS_JSON
    # ) VALUES (
    # s.CLIENT_ID, s.BASELINE_START, s.BASELINE_END, s.MODEL_VERSION,
    # s.FEATURE_SET_HASH, s.EMBEDDING_JSON, s.MEAN_JSON, s.STD_JSON, s.FEATURE_KEYS_JSON
    # )
    # """

# TIll now we have developed a simple baseline embedding (centroid of raw features). 
# #In future, you can experiment with more complex models (e.g. autoencoders, contrastive learning) #
# and store additional metadata (e.g. feature means/stds for normalization) in the same table for use during monitoring.

    saved = executemany(merge_sql, upserts, batch_size=1000)
    print(f"Built+saved baselines for {len(per_client)} clients. Rows upserted: {saved}")

if __name__ == "__main__":
    main()
