# src/loaders.py
from __future__ import annotations
from typing import Iterable

from db import executemany

def _quote_ident(name: str) -> str:
    # Oracle identifiers: keep upper-case as-is; if you used mixed-case quoted names in DB, adjust.
    return name

def _build_merge_sql(
    table: str,
    key_cols: list[str],
    all_cols: list[str],
    updated_at_col: str | None = "UPDATED_AT",
) -> str:
    """
    Build a dynamic Oracle MERGE statement:
    - ON: key_cols
    - UPDATE: all non-key columns (+ optional UPDATED_AT)
    - INSERT: all columns (+ optional UPDATED_AT/CREATED_AT handled by DB defaults if present)
    """
    table = _quote_ident(table)
    key_cols_u = [c.upper() for c in key_cols]
    cols_u = [c.upper() for c in all_cols]

    # Ensure key columns exist in output columns
    missing_keys = [k for k in key_cols_u if k not in cols_u]
    if missing_keys:
        raise ValueError(f"Query result missing key columns: {missing_keys}")

    # Source select binds
    src_select = ",\n    ".join([f":{c} AS {c}" for c in cols_u])

    # ON clause
    on_clause = " AND ".join([f"t.{k} = s.{k}" for k in key_cols_u])

    # Update set: non-key columns only
    non_key_cols = [c for c in cols_u if c not in key_cols_u]

    set_lines = [f"t.{c} = s.{c}" for c in non_key_cols]
    if updated_at_col:
        set_lines.append(f"t.{updated_at_col} = SYSDATE")

    update_set = ",\n  ".join(set_lines)

    # Insert: all cols in result
    insert_cols = ", ".join(cols_u)
    insert_vals = ", ".join([f"s.{c}" for c in cols_u])

    sql = f"""
MERGE INTO {table} t
USING (
  SELECT
    {src_select}
  FROM dual
) s
ON ({on_clause})
WHEN MATCHED THEN UPDATE SET
  {update_set}
WHEN NOT MATCHED THEN INSERT ({insert_cols})
VALUES ({insert_vals})
"""
    return sql.strip()

def rows_to_dicts(columns: list[str], rows: list[tuple]) -> list[dict]:
    cols_u = [c.upper() for c in columns]
    out = []
    for r in rows:
        d = dict(zip(cols_u, r))
        out.append(d)
    return out

def upsert_query_result(
    table: str,
    key_cols: list[str],
    columns: list[str],
    rows: list[tuple],
    batch_size: int = 2000,
    updated_at_col: str | None = "UPDATED_AT",
) -> int:
    """
    Generic upsert into Oracle for a query result.
    Requires:
      - The table already exists
      - The table has at least the columns returned by the query
      - key_cols define the primary key / unique keys
    """
    if not rows:
        return 0

    cols_u = [c.upper() for c in columns]
    merge_sql = _build_merge_sql(
        table=table,
        key_cols=[c.upper() for c in key_cols],
        all_cols=cols_u,
        updated_at_col=updated_at_col,
    )
    bind_rows = rows_to_dicts(columns, rows)
    return executemany(merge_sql, bind_rows, batch_size=batch_size)
