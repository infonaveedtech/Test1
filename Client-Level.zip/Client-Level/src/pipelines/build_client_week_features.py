# from datetime import datetime, timedelta, timezone
# from pathlib import Path

# from db import fetchmany

# SQL_PATH = Path(__file__).resolve().parents[1] / "sql" / "client_week_profile_trades_orders.sql"

# def main():
#     # For POC: choose a single fixed week window (you can change easily)
#     # Example: last 7 days from "now"
#     # end_ts = datetime.now(timezone.utc)
#     # start_ts = end_ts - timedelta(days=7)
    
#     # from datetime import datetime, timezone

#     # Fixed historical range: Jan 2022
#     start_ts = datetime(2022, 1, 1, tzinfo=timezone.utc)
#     end_ts   = datetime(2022, 2, 1, tzinfo=timezone.utc)


#     sql = SQL_PATH.read_text(encoding="utf-8")

#     result = fetchmany(
#         sql,
#         params={
#             "start_ts": start_ts,
#             "end_ts": end_ts,
#         },
#         row_limit=50
#     )

#     print("COLUMNS:", result["columns"])
#     print("ROWS:")
#     for r in result["rows"]:
#         print(r)

# if __name__ == "__main__":
#     main()


from datetime import datetime, timezone
from pathlib import Path

from db import fetchmany
from loaders import upsert_query_result

SQL_PATH = Path(__file__).resolve().parents[1] / "sql" / "client_week_profile_trades_orders.sql"

TARGET_TABLE = "CLIENT_WEEK_FEATURES"
KEY_COLS = ["CLIENT_ID", "WEEK_START", "MARKET_ID"]

def main():
    # Fixed historical range: Jan 2022
    start_ts = datetime(2022, 1, 1, tzinfo=timezone.utc)
    end_ts   = datetime(2022, 2, 1, tzinfo=timezone.utc)

    sql = SQL_PATH.read_text(encoding="utf-8")

    # Optional: client filter for debugging
    # If you want this, add "AND t.client_id = :client_id" inside your SQL final WHERE
    # and pass params={"client_id": 123, ...}
    params = {"start_ts": start_ts, "end_ts": end_ts}

    result = fetchmany(sql, params=params, row_limit=50000)  # increase as needed

    print("Fetched rows:", len(result["rows"]))
    if result["rows"]:
        print("First row:", result["rows"][0])

    # UPSERT into Oracle table
    upserted = upsert_query_result(
        table=TARGET_TABLE,
        key_cols=KEY_COLS,
        columns=result["columns"],
        rows=result["rows"],
        batch_size=2000,
        updated_at_col="UPDATED_AT",   # if your table has it; else set None
    )

    print(f"Upserted {upserted} rows into {TARGET_TABLE}")

if __name__ == "__main__":
    main()
