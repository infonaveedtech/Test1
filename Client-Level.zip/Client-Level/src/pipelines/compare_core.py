# src/pipelines/compare_core.py
import json
import math

from .db import fetchall  # your helper that returns rows

FEATURE_KEYS = [
  # Trades (activity + direction)
  "TRADES_TOTAL",
  "TRADE_VOLUME_TOTAL",
  "TRADE_NOTIONAL_TOTAL",
  "TRADE_AVG_PRICE_SIMPLE",
  "TRADE_ACTIVE_DAYS",
  "TRADE_UNIQUE_SYMBOLS",
  "TRADES_BUY",
  "TRADES_SELL",
  "TRADE_VOLUME_BUY",
  "TRADE_VOLUME_SELL",

  # Orders (intent + friction)
  "ORDERS_TOTAL",
  "ORDERS_CANCEL",
  "ORDERS_REJECT",
  "ORDERS_FILL_LIKE",
  "ORDERS_SHORT",
  "ORDER_UNIQUE_SYMBOLS",

  # Ratios (behavioral signatures)
  "CANCEL_RATIO",
  "ORDER_TO_TRADE_RATIO",

  # Market/participation (optional but valuable)
  "CLIENT_VOLUME_SHARE_WEEK",
]


def load_baseline(conn, client_id: int):
    sql = """
    SELECT client_id, baseline_start, baseline_end, model_version, feature_set_hash,
           embedding_json, created_at
    FROM CLIENT_BASELINE_EMBEDDINGS
    WHERE client_id = :client_id
    ORDER BY created_at DESC
    FETCH FIRST 1 ROW ONLY
    """
    rows = fetchall(conn, sql, {"client_id": client_id})
    if not rows:
        return None

    r = rows[0]
    # payload = json.loads((r.get("EMBEDDING_JSON") or "").strip())
    
    raw = (r.get("EMBEDDING_JSON") or "").strip()
    payload = json.loads(raw)

    # Support both formats:
    # 1) payload dict: {"embedding": [...], "feature_cols": [...]}
    # 2) payload list:  [...]
    if isinstance(payload, list):
        embedding = payload
        # fallback feature cols: use your FEATURE_KEYS (must match embedding length)
        feature_cols = FEATURE_KEYS[:]  # ensure FEATURE_KEYS length == len(embedding)
        payload_obj = {
            "embedding": embedding,
            "feature_cols": feature_cols,
        }
    elif isinstance(payload, dict):
        embedding = payload.get("embedding")
        feature_cols = payload.get("feature_cols")
        if embedding is None:
            # maybe stored directly under another key; last resort:
            embedding = payload.get("EMBEDDING") or payload.get("vector")
        if feature_cols is None:
            feature_cols = FEATURE_KEYS[:]
        payload_obj = payload
    else:
        raise ValueError(f"Unsupported EMBEDDING_JSON type: {type(payload)}")


    return {
    "client_id": r["CLIENT_ID"],
    "baseline_start": r["BASELINE_START"],
    "baseline_end": r["BASELINE_END"],
    "model_version": r["MODEL_VERSION"],
    "feature_set_hash": r["FEATURE_SET_HASH"],
    "created_at": r["CREATED_AT"],
    "payload": payload_obj,
    "embedding": embedding,
    "feature_cols": [c.upper() for c in feature_cols],
}


# def build_embedding_from_rows(rows, feature_cols):
#     if not rows:
#         return [], {}

#     # window mean values (for display)
#     monitor_mean = {
#         k: sum(float(r.get(k, 0.0) or 0.0) for r in rows) / len(rows)
#         for k in feature_cols
#     }

#     vec = [monitor_mean[k] for k in feature_cols]

#     # L2 normalize
#     norm = math.sqrt(sum(v*v for v in vec))
#     if norm < 1e-12:
#         return [0.0 for _ in vec], monitor_mean

#     emb = [v / norm for v in vec]
#     return emb, monitor_mean

def build_embedding_from_rows(rows, feature_cols, weight_col="TRADE_NOTIONAL_TOTAL"):
    """
    Build monitor embedding the SAME way as baseline:
    - build X vectors from feature_cols
    - weights from TRADE_NOTIONAL_TOTAL (fallback to uniform if sum <= 0)
    - weighted centroid
    - L2 normalize
    Returns: (embedding_list, window_means_dict_for_UI)
    """
    if not rows:
        return [], {}

    # window mean values (for display only)
    monitor_mean = {
        k: sum(float(r.get(k, 0.0) or 0.0) for r in rows) / len(rows)
        for k in feature_cols
    }

    # Build weighted centroid
    weights = []
    X = []
    for r in rows:
        X.append([float(r.get(k, 0.0) or 0.0) for k in feature_cols])
        weights.append(float(r.get(weight_col, 0.0) or 0.0))

    wsum = sum(weights)
    if wsum <= 0:
        weights = [1.0] * len(weights)
        wsum = float(len(weights))

    centroid = [0.0] * len(feature_cols)
    for i in range(len(rows)):
        wi = weights[i] / wsum
        for j in range(len(feature_cols)):
            centroid[j] += X[i][j] * wi

    # L2 normalize
    norm = math.sqrt(sum(v*v for v in centroid))
    if norm < 1e-12:
        return [0.0 for _ in centroid], monitor_mean

    emb = [v / norm for v in centroid]
    return emb, monitor_mean



def cosine_sim(a, b):
    if not a or not b or len(a) != len(b):
        return 0.0
    dot = sum(x*y for x, y in zip(a, b))
    na = math.sqrt(sum(x*x for x in a)) or 1.0
    nb = math.sqrt(sum(y*y for y in b)) or 1.0
    return dot / (na * nb)

# def top_deviations(monitor_means: dict, baseline_mean: dict, baseline_std: dict, top_k=10):
#     items = []
#     for k in FEATURE_KEYS:
#         mu = float(baseline_mean.get(k, 0.0))
#         sd = float(baseline_std.get(k, 1.0)) or 1.0
#         mv = float(monitor_means.get(k, 0.0))
#         z = (mv - mu) / sd
#         items.append({"feature": k, "z": z, "monitor": mv, "baseline_mean": mu})
#     items.sort(key=lambda x: abs(x["z"]), reverse=True)
#     return items[:top_k]
def top_deviations(monitor_means: dict, baseline_means: dict, top_k=10):
    items = []
    for k, mv in monitor_means.items():
        bv = float(baseline_means.get(k, 0.0))
        diff = float(mv) - bv
        pct = (diff / bv * 100.0) if abs(bv) > 1e-12 else None
        items.append({"feature": k, "diff": diff, "pct_change": pct, "monitor": mv, "baseline": bv})
    items.sort(key=lambda x: abs(x["diff"]), reverse=True)
    return items[:top_k]
