import json
import math
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

from db import fetchmany, fetch_one_clob

SQL_PATH = Path(__file__).resolve().parents[1] / "sql" / "client_week_profile_trades_orders.sql"
MODEL_VERSION = "v0_feature_vector"

def cosine(a: np.ndarray, b: np.ndarray) -> float | None:
    na = float(np.linalg.norm(a))
    nb = float(np.linalg.norm(b))
    if na == 0.0 or nb == 0.0:
        return None
    return float(np.dot(a, b) / (na * nb))

def safe_float(x):
    return 0.0 if x is None else float(x)

def load_baseline(client_id: int, baseline_start: datetime, baseline_end: datetime) -> dict:
    sql = """
      SELECT EMBEDDING_JSON
      FROM CLIENT_BASELINE_EMBEDDINGS
      WHERE CLIENT_ID = :client_id
        AND MODEL_VERSION = :model_version
        AND BASELINE_START = :baseline_start
        AND BASELINE_END = :baseline_end
    """
    payload_str = fetch_one_clob(sql, {
        "client_id": client_id,
        "model_version": MODEL_VERSION,
        "baseline_start": baseline_start,
        "baseline_end": baseline_end,
    })
    if not payload_str:
        raise RuntimeError("Baseline not found for this client + baseline window.")
    return json.loads(payload_str)

def compute_embedding_from_sql(
    client_id: int,
    start_ts: datetime,
    end_ts: datetime,
    baseline_payload: dict,
):
    """
    Runs the live feature SQL for ONLY this client and time window,
    then builds a single embedding for the whole window.

    Note: SQL returns weekly rows (week_start, market_id). We aggregate them
    into one embedding via weighted mean.
    """
    sql = SQL_PATH.read_text(encoding="utf-8")
    res = fetchmany(
        sql,
        params={"start_ts": start_ts, "end_ts": end_ts, "client_id": client_id},
        row_limit=200000,
    )

    cols = [c.upper() for c in res["columns"]]
    idx = {c: i for i, c in enumerate(cols)}
    rows = res["rows"]

    if not rows:
        return None, None, None  # no activity in window

    embed_cols = [c.upper() for c in baseline_payload["feature_cols"]]
    mu = np.array(baseline_payload["baseline_mean"], dtype=float)
    sigma = np.array(baseline_payload["baseline_std"], dtype=float) + 1e-8

    X = []
    w = []

    for r in rows:
        # Safety: ensure correct client (in case SQL filter missing)
        if "CLIENT_ID" in idx and int(r[idx["CLIENT_ID"]]) != int(client_id):
            continue

        vec = [safe_float(r[idx[c]]) if c in idx else 0.0 for c in embed_cols]
        X.append(vec)

        # weight by trade notional if present
        if "TRADE_NOTIONAL_TOTAL" in idx:
            w.append(safe_float(r[idx["TRADE_NOTIONAL_TOTAL"]]))
        else:
            w.append(1.0)

    if not X:
        return None, None, None

    X = np.array(X, dtype=float)
    w = np.array(w, dtype=float)
    if w.sum() <= 0:
        w = np.ones(len(X), dtype=float)

    # Normalize using baseline stats
    Xn = (X - mu) / sigma

    # Aggregate to a single window embedding
    emb = np.average(Xn, axis=0, weights=w)

    # L2 normalize embedding
    n = float(np.linalg.norm(emb))
    if n > 0:
        emb = emb / n

    # Raw centroid for explainability
    raw_centroid = np.average(X, axis=0, weights=w)

    # Useful metadata (optional)
    client_name = r[idx["CLIENT_NAME"]] if "CLIENT_NAME" in idx else None

    return emb, raw_centroid, {"rows": len(rows), "client_name": client_name, "embed_cols": embed_cols}

def explain_top_deltas(raw_centroid: np.ndarray, baseline_payload: dict, embed_cols: list[str], top_k: int = 8):
    mu = np.array(baseline_payload["baseline_mean"], dtype=float)
    sigma = np.array(baseline_payload["baseline_std"], dtype=float) + 1e-8
    z = (raw_centroid - mu) / sigma
    order = np.argsort(np.abs(z))[::-1][:top_k]
    out = []
    for i in order:
        out.append((embed_cols[i], float(z[i]), float(raw_centroid[i]), float(mu[i])))
    return out

def main():
    # ---- pick client + baseline window (must match your built baselines) ----
    client_id = 1760981

    baseline_start = datetime(2022, 1, 3, tzinfo=timezone.utc)
    baseline_end   = datetime(2022, 1, 31, tzinfo=timezone.utc)

    # ---- pick monitor window (your choice: 4 weeks / 1 week etc.) ----
    monitor_start = datetime(2024, 1, 3, tzinfo=timezone.utc)
    monitor_end   = datetime(2024, 1, 31, tzinfo=timezone.utc)

    baseline = load_baseline(client_id, baseline_start, baseline_end)
    base_emb = np.array(baseline["embedding"], dtype=float)

    mon_emb, mon_raw, meta = compute_embedding_from_sql(client_id, monitor_start, monitor_end, baseline)
    if mon_emb is None:
        print("No monitor data found for this client in the chosen window (live SQL).")
        return

    sim = cosine(base_emb, mon_emb)

    print("Client:", client_id, "| Name:", meta.get("client_name"))
    print("Baseline:", baseline_start.date(), "→", baseline_end.date())
    print("Monitor :", monitor_start.date(), "→", monitor_end.date())
    print("Rows used:", meta.get("rows"))
    print("Cosine similarity:", sim)

    # Temporary flag threshold (we’ll calibrate later)
    threshold = 0.85
    flag = (sim is not None and sim < threshold)
    print("FLAG:", flag, f"(threshold={threshold})")

    deltas = explain_top_deltas(mon_raw, baseline, meta["embed_cols"], top_k=8)
    print("\nTop feature deviations (z, monitor_value, baseline_mean):")
    for name, z, mv, bm in deltas:
        print(f"- {name}: z={z:.2f}, monitor={mv:.4g}, base_mean={bm:.4g}")

if __name__ == "__main__":
    main()
