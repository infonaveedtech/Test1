# src/pipelines/monitor_window.py
from datetime import datetime, timedelta
from .db import fetchall  # or your existing fetch helper

# def fetch_trade_week_features(conn, client_id: int, start_ts: datetime, end_ts: datetime):
#     """
#     Returns weekly trade features for client in [start_ts, end_ts).
#     Must return [] when no rows.
#     """
#     sql = open("src/sql/client_week_trades_features_only.sql", "r", encoding="utf-8").read()
#     params = {"start_ts": start_ts, "end_ts": end_ts, "client_id": client_id}
#     return fetchall(conn, sql, params)

from .db import fetchmany  # or fetchall depending on your db helper
from pathlib import Path

SQL_DIR = Path(__file__).resolve().parents[1] / "sql"

def fetch_trade_week_features(conn, client_id: int, start_ts, end_ts):
    sql_path = SQL_DIR / "client_week_profile_trades_orders.sql"
    sql = sql_path.read_text(encoding="utf-8")

    # this SQL expects :start_ts, :end_ts, and optionally :client_id
    result = fetchmany(sql, {"start_ts": start_ts, "end_ts": end_ts, "client_id": client_id}, row_limit=50000)
    cols = result["columns"]
    rows = [dict(zip(cols, r)) for r in result["rows"]]
    return rows


def find_nearest_activity_week(conn, client_id: int, target_ts: datetime, search_days: int = 180):
    """
    Find nearest TRUNC(entry_datetime,'IW') week_start where the client has any trades.
    Searches within target_ts +/- search_days.
    Returns datetime (week_start) or None.
    """
    sql = """
    WITH activity_weeks AS (
      SELECT DISTINCT TRUNC(t.ENTRY_DATETIME,'IW') AS week_start
      FROM ATS.TRADES t
      WHERE t.BUYER_CLIENT_ID = :client_id
        AND t.ENTRY_DATETIME >= :search_from
        AND t.ENTRY_DATETIME <  :search_to
    )
    SELECT week_start
    FROM (
      SELECT week_start,
             ABS(week_start - TRUNC(:target_ts,'IW')) AS dist
      FROM activity_weeks
    )
    ORDER BY dist
    FETCH FIRST 1 ROW ONLY
    """
    search_from = target_ts - timedelta(days=search_days)
    search_to   = target_ts + timedelta(days=search_days)
    rows = fetchall(conn, sql, {
        "client_id": client_id,
        "target_ts": target_ts,
        "search_from": search_from,
        "search_to": search_to,
    })
    if not rows:
        return None
    return rows[0]["WEEK_START"]  # Oracle returns datetime/date

def get_monitor_rows_with_fallback(conn, client_id: int, start_ts: datetime, weeks: int = 4,
                                  search_days: int = 180):
    """
    Tries requested window. If empty, falls back to nearest activity week.
    Returns: (rows, used_start_ts, used_end_ts, fallback_used_bool)
    """
    end_ts = start_ts + timedelta(days=weeks * 7)
    rows = fetch_trade_week_features(conn, client_id, start_ts, end_ts)
    if rows:
        return rows, start_ts, end_ts, False

    nearest = find_nearest_activity_week(conn, client_id, start_ts, search_days=search_days)
    if nearest is None:
        return [], start_ts, end_ts, False  # caller decides how to handle

    used_start = nearest
    used_end = used_start + timedelta(days=weeks * 7)
    rows = fetch_trade_week_features(conn, client_id, used_start, used_end)
    return rows, used_start, used_end, True
