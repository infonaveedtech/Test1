# Client-Level Behavior Monitoring Pipeline

## Overview

This repository implements a **client-level behavior monitoring pipeline** for trading activity.
It builds **baseline behavioral embeddings** per client from historical data and compares them against **new monitoring windows** using **cosine similarity** to detect abnormal behavior.

The pipeline is designed to work on **weekly aggregated features** derived from:

* Trades (buyer + seller)
* Orders
* Market activity

It supports:

* Historical baseline construction
* Monitoring with fallback windows
* Interactive exploration via Streamlit

---

## Repository Structure (Updated)

All executable code lives under `src/`.

```
Client-Level/
│
├── README.md
├── requirements.txt
├── schema_card.md
│
└── src/
    ├── app.py                     # Streamlit UI
    ├── __init__.py
    │
    ├── pipelines/
    │   ├── __init__.py
    │   ├── db.py                  # Oracle connection + helpers
    │   ├── loaders.py             # Generic MERGE / upsert logic
    │   ├── build_client_week_features.py
    │   ├── build_baselines.py
    │   ├── compare_core.py        # Core embedding + similarity logic
    │   ├── monitor_window.py      # Monitoring window + fallback logic
    │   └── compare_client.py      # CLI comparison script (optional)
    │
    └── sql/
        ├── __init__.py
        ├── client_week_profile_trades_orders.sql
        ├── client_week_trades_features.sql
        ├── client_week_trades_features_only.sql
        └── client_week_trades_features_v2.sql
```

> **Note**
>
> * `.env` files and `__pycache__/` directories should **not** be committed.
> * All imports assume `src` is the package root.

---

## High-Level Pipeline Flow

1. **Weekly feature generation**
2. **Baseline embedding construction**
3. **Monitoring window embedding**
4. **Baseline vs monitor comparison**
5. **Visualization and investigation**

---

## 1. Weekly Feature Generation

### Script

```
src/pipelines/build_client_week_features.py
```

### SQL

```
src/sql/client_week_profile_trades_orders.sql
```

### Output Table

```
CLIENT_WEEK_FEATURES
```

### Description

This step aggregates **weekly client behavior per market**, including:

* Trade activity (buyer + seller)
* Order activity
* Buy/sell splits
* Market participation ratios
* Client metadata (name, market)

**Primary keys**

```
(CLIENT_ID, WEEK_START, MARKET_ID)
```

The script:

* Executes the SQL in batches
* Upserts results using Oracle `MERGE`
* Supports optional filtering by `CLIENT_ID`

> ⚠️ Important
> The SQL must be **key-driven**, not trade-driven, so that:
>
> * Clients with **orders but no trades** still appear
> * Monitoring windows don’t silently drop activity

---

## 2. Baseline Embedding Construction

### Script

```
src/pipelines/build_baselines.py
```

### Input

```
CLIENT_WEEK_FEATURES
```

### Output Table

```
CLIENT_BASELINE_EMBEDDINGS
```

### Description

For each client:

* Selects historical weekly feature rows over a baseline window
* Aggregates features across weeks
* Produces a **single normalized embedding vector**

**Current embedding approach**

* Mean aggregation across weeks
* Optional notional weighting
* L2 normalization
* Stored as JSON

**Stored JSON format**

```json
{
  "model_version": "v0_feature_vector",
  "feature_cols": ["TRADE_COUNT", "ORDER_COUNT", "..."],
  "feature_set_hash": "sha256(...)",
  "embedding": [0.013, -0.221, ...]
}
```

Each client may have multiple baselines over time; the most recent one is used by default.

---

## 3. Monitoring Window Feature Retrieval

### Module

```
src/pipelines/monitor_window.py
```

### SQL

```
src/sql/client_week_trades_features_only.sql
```

### Description

This module retrieves weekly feature rows for a **monitoring window**.

It supports:

* A user-defined date range
* Automatic **fallback** to the nearest active week if no data is found

**Fallback logic**

1. Try requested window
2. If empty:

   * Search for nearest week with activity
   * Retry feature extraction using that window

> ⚠️ Important
> Monitoring SQL must:
>
> * Include **buyer and seller activity**
> * Match the **feature set used by baseline embeddings**

---

## 4. Baseline vs Monitor Comparison

### Core Logic

```
src/pipelines/compare_core.py
```

### Steps

1. Load most recent baseline embedding for the client
2. Build a monitoring embedding from weekly rows
3. Normalize embeddings
4. Compute **cosine similarity**
5. Compute per-feature deviations

### Outputs

* Similarity score (0–1)
* Top deviating features
* Percent change vs baseline

---

## 5. Streamlit Application

### Entry Point

```
src/app.py
```

### Features

* Client selection
* Monitoring window selection
* Similarity threshold
* Fallback window controls
* Baseline vs monitor comparison
* Feature deviation inspection

Run with:

```bash
streamlit run src/app.py
```

---

## Environment Configuration

Create a local `.env` file (not committed):

```env
ORACLE_USER=...
ORACLE_PASSWORD=...
ORACLE_DSN=...
ORACLE_SCHEMA=...
```

---

## Known Design Constraints & Assumptions

* Weekly granularity (`TRUNC(date, 'IW')`)
* Oracle database backend
* Feature schema must remain consistent between:

  * Baseline build
  * Monitoring window
* Cosine similarity assumes normalized vectors

---

## Recommended Next Improvements

* Add **orders-only support** explicitly via key unions
* Align baseline and monitor feature SQL fully
* Store baseline **mean/std** for z-score normalization
* Persist monitoring results in a `CLIENT_MONITOR_RUNS` table
* Add feature versioning enforcement
* Add automated data quality checks

---
