"""
db/oracle.py — Oracle connection pool + safe SQL execution.

Features:
  - Shared connection pool for both:
      * business query execution
      * chatbot persistence store
  - Thin mode by default
  - Row serialization handles DATE, TIMESTAMP, DECIMAL, LOB, etc.
  - Hard row cap to prevent accidental full-table scans
  - Optional CURRENT_SCHEMA switch per session
"""
from __future__ import annotations

import logging
import threading
from datetime import date, datetime
from decimal import Decimal
from typing import Any, Dict, List, Tuple

logger = logging.getLogger(__name__)

_pool = None
_pool_lock = threading.Lock()


def _get_pool():
    """
    Shared Oracle pool used by:
      - db/oracle.py
      - db/oracle_store.py
    """
    global _pool
    if _pool is not None:
        return _pool

    with _pool_lock:
        if _pool is not None:
            return _pool

        try:
            import oracledb
        except ImportError:
            raise RuntimeError(
                "oracledb is not installed. Run: pip install oracledb"
            )

        from core.config import get_settings
        s = get_settings()

        if not s.ORACLE_DSN or not s.ORACLE_USER or not s.ORACLE_PASSWORD:
            raise RuntimeError(
                "Oracle credentials not configured. "
                "Set ORACLE_DSN, ORACLE_USER, ORACLE_PASSWORD in .env"
            )

        _pool = oracledb.create_pool(
            user=s.ORACLE_USER,
            password=s.ORACLE_PASSWORD,
            dsn=s.ORACLE_DSN,
            min=s.ORACLE_POOL_MIN,
            max=s.ORACLE_POOL_MAX,
            increment=s.ORACLE_POOL_INCREMENT,
        )
        logger.info(
            "[Oracle] Connection pool created (min=%d max=%d)",
            s.ORACLE_POOL_MIN,
            s.ORACLE_POOL_MAX,
        )
        return _pool


def _read_lob_if_needed(val: Any) -> Any:
    """
    Convert Oracle LOB values into plain Python strings.
    """
    if val is None:
        return None

    if hasattr(val, "read"):
        try:
            return val.read()
        except Exception:
            return str(val)

    return val


def _serialize(val: Any) -> Any:
    """
    Make a DB value JSON/Python serializable.
    """
    val = _read_lob_if_needed(val)

    if val is None:
        return None
    if isinstance(val, (datetime, date)):
        return val.isoformat()
    if isinstance(val, Decimal):
        return float(val)
    if isinstance(val, (int, float, str, bool)):
        return val
    return str(val)


def _clean_sql(sql: str) -> str:
    """
    Strip trailing semicolons because Oracle rejects them in execute().
    """
    return sql.strip().rstrip(";").strip()


def run_sql(
    sql: str,
    row_limit: int = 200,
    hard_cap: int = 5000,
) -> Dict[str, Any]:
    """
    Execute a SELECT query and return structured results.

    Returns:
        {
            "columns": [...],
            "rows": [[...], ...],
            "row_count": int,
            "row_limit": int,
            "truncated": bool,
        }

    Raises RuntimeError on execution failure.
    """
    from core.config import get_settings
    s = get_settings()

    if not s.ENABLE_SQL_EXECUTION:
        raise RuntimeError("SQL execution is disabled (ENABLE_SQL_EXECUTION=false).")

    effective_limit = min(row_limit, hard_cap)
    clean = _clean_sql(sql)
    lowered = clean.lower()

    if not (lowered.startswith("select") or lowered.startswith("with")):
        raise RuntimeError("Only SELECT queries are allowed.")

    pool = _get_pool()
    with pool.acquire() as conn:
        cur = conn.cursor()
        try:
            owner = s.ORACLE_OWNER
            if owner:
                cur.execute(f"ALTER SESSION SET CURRENT_SCHEMA = {owner}")

            cur.execute(clean)

            columns: List[str] = [d[0] for d in cur.description] if cur.description else []

            raw_rows: List[Tuple] = cur.fetchmany(effective_limit + 1)
            truncated = len(raw_rows) > effective_limit
            rows = raw_rows[:effective_limit]

            serialized = [[_serialize(v) for v in row] for row in rows]
        finally:
            cur.close()

    return {
        "columns": columns,
        "rows": serialized,
        "row_count": len(serialized),
        "row_limit": effective_limit,
        "truncated": truncated,
    }


def execute_query(
    sql: str,
    row_limit: int = 200,
    hard_cap: int = 5000,
) -> Dict[str, Any]:
    """
    Compatibility alias for callers that expect execute_query().
    """
    return run_sql(sql=sql, row_limit=row_limit, hard_cap=hard_cap)


def test_connection() -> bool:
    """
    Returns True if Oracle pool can acquire a connection.
    """
    try:
        pool = _get_pool()
        with pool.acquire() as conn:
            cur = conn.cursor()
            try:
                cur.execute("SELECT 1 FROM DUAL")
                cur.fetchone()
            finally:
                cur.close()
        return True
    except Exception as exc:
        logger.error("[Oracle] Connection test failed: %s", exc)
        return False


def close_pool() -> None:
    """
    Gracefully close the connection pool.
    """
    global _pool
    if _pool is not None:
        try:
            _pool.close()
        except Exception:
            pass
        _pool = None
        logger.info("[Oracle] Pool closed.")