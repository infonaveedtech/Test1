# """
# db/oracle_store.py — Oracle-backed persistence for sessions, messages, and runs.

# This mirrors the public API of db/sqlite_store.py so the rest of the app can
# switch over with minimal code changes.

# Oracle tables expected:
#   CHATBOT_SESSIONS
#   CHATBOT_MESSAGES
#   CHATBOT_RUNS
# """
# from __future__ import annotations

# import json
# import time
# import uuid
# from contextlib import contextmanager
# from typing import Any, Dict, Generator, List, Optional

# from core.config import get_settings
# from db.oracle import _get_pool


# # ---------------------------------------------------------------------------
# # Connection helpers
# # ---------------------------------------------------------------------------

# @contextmanager
# def _conn() -> Generator[Any, None, None]:
#     """
#     Acquire an Oracle pooled connection with commit/rollback handling.
#     Also sets CURRENT_SCHEMA if ORACLE_OWNER is configured.
#     """
#     s = get_settings()
#     pool = _get_pool()
#     conn = pool.acquire()
#     try:
#         if s.ORACLE_OWNER:
#             cur = conn.cursor()
#             try:
#                 cur.execute(f"ALTER SESSION SET CURRENT_SCHEMA = {s.ORACLE_OWNER}")
#             finally:
#                 cur.close()
#         yield conn
#         conn.commit()
#     except Exception:
#         conn.rollback()
#         raise
#     finally:
#         conn.close()


# def _read_lob_if_needed(value: Any) -> Any:
#     """
#     Convert Oracle LOBs into plain Python strings where needed.
#     """
#     if value is None:
#         return None

#     if hasattr(value, "read"):
#         try:
#             return value.read()
#         except Exception:
#             return str(value)

#     return value


# def _row_to_dict(cursor: Any, row: Any) -> Dict[str, Any]:
#     """
#     Convert a fetched Oracle row into a lowercase-key dict.
#     """
#     cols = [d[0].lower() for d in cursor.description]
#     values = [_read_lob_if_needed(v) for v in row]
#     return dict(zip(cols, values))


# def _fetchone_dict(cursor: Any) -> Optional[Dict[str, Any]]:
#     row = cursor.fetchone()
#     if row is None:
#         return None
#     return _row_to_dict(cursor, row)


# def _fetchall_dicts(cursor: Any) -> List[Dict[str, Any]]:
#     rows = cursor.fetchall()
#     return [_row_to_dict(cursor, r) for r in rows]


# def _json_dumps(value: Any) -> Optional[str]:
#     if value is None:
#         return None
#     return json.dumps(value)


# def _json_loads_if_possible(value: Any) -> Any:
#     if value is None:
#         return None
#     if not isinstance(value, str):
#         return value
#     try:
#         return json.loads(value)
#     except Exception:
#         return value


# def _to_bool_flag(value: Any) -> bool:
#     return value in (1, "1", True, "true", "TRUE", "Y", "y")


# def _deserialize_session_fields(d: Dict[str, Any]) -> Dict[str, Any]:
#     if not d:
#         return d

#     if d.get("meta"):
#         d["meta"] = _json_loads_if_possible(d["meta"])
#     else:
#         d["meta"] = {}

#     d["starred"] = _to_bool_flag(d.get("starred", 0))
#     return d


# def _deserialize_run_fields(d: Dict[str, Any]) -> Dict[str, Any]:
#     if not d:
#         return d

#     for f in ("plan_envelope", "db_columns", "db_rows", "answer_key_facts", "timing_ms"):
#         if d.get(f):
#             d[f] = _json_loads_if_possible(d[f])

#     return d


# # ---------------------------------------------------------------------------
# # Init / validation
# # ---------------------------------------------------------------------------

# def init_db() -> None:
#     """
#     Oracle tables are created manually, so this function only validates that
#     the required tables exist. Safe to call on app startup.
#     """
#     required = {"CHATBOT_SESSIONS", "CHATBOT_MESSAGES", "CHATBOT_RUNS"}

#     with _conn() as conn:
#         cur = conn.cursor()
#         try:
#             cur.execute(
#                 """
#                 SELECT table_name
#                 FROM user_tables
#                 WHERE table_name IN (
#                     'CHATBOT_SESSIONS',
#                     'CHATBOT_MESSAGES',
#                     'CHATBOT_RUNS'
#                 )
#                 """
#             )
#             found = {r[0] for r in cur.fetchall()}
#         finally:
#             cur.close()

#     missing = required - found
#     if missing:
#         raise RuntimeError(
#             f"Oracle chatbot tables missing: {', '.join(sorted(missing))}"
#         )


# # ---------------------------------------------------------------------------
# # Session CRUD
# # ---------------------------------------------------------------------------

# def create_session(title: str = "New Chat", meta: Dict = None) -> Dict[str, Any]:
#     sid = str(uuid.uuid4())
#     now = time.time()

#     with _conn() as conn:
#         cur = conn.cursor()
#         try:
#             cur.execute(
#                 """
#                 INSERT INTO CHATBOT_SESSIONS
#                     (SESSION_ID, TITLE, CREATED_AT, UPDATED_AT, META, STARRED)
#                 VALUES
#                     (:1, :2, :3, :4, :5, :6)
#                 """,
#                 [sid, title, now, now, _json_dumps(meta or {}), 0],
#             )
#         finally:
#             cur.close()

#     return get_session(sid)


# def get_session(session_id: str) -> Optional[Dict[str, Any]]:
#     with _conn() as conn:
#         cur = conn.cursor()
#         try:
#             cur.execute(
#                 """
#                 SELECT SESSION_ID, TITLE, CREATED_AT, UPDATED_AT, META, STARRED
#                 FROM CHATBOT_SESSIONS
#                 WHERE SESSION_ID = :1
#                 """,
#                 [session_id],
#             )
#             row = _fetchone_dict(cur)
#         finally:
#             cur.close()

#     if row is None:
#         return None

#     return _deserialize_session_fields(row)


# def list_sessions(limit: int = 50) -> List[Dict[str, Any]]:
#     with _conn() as conn:
#         cur = conn.cursor()
#         try:
#             cur.execute(
#                 """
#                 SELECT SESSION_ID, TITLE, CREATED_AT, UPDATED_AT, META, STARRED
#                 FROM CHATBOT_SESSIONS
#                 ORDER BY STARRED DESC, UPDATED_AT DESC
#                 FETCH FIRST :1 ROWS ONLY
#                 """,
#                 [limit],
#             )
#             rows = _fetchall_dicts(cur)
#         finally:
#             cur.close()

#     return [_deserialize_session_fields(row) for row in rows]


# def update_session_title(session_id: str, title: str) -> None:
#     now = time.time()

#     with _conn() as conn:
#         cur = conn.cursor()
#         try:
#             cur.execute(
#                 """
#                 UPDATE CHATBOT_SESSIONS
#                 SET TITLE = :1,
#                     UPDATED_AT = :2
#                 WHERE SESSION_ID = :3
#                 """,
#                 [title, now, session_id],
#             )
#         finally:
#             cur.close()


# def set_session_starred(session_id: str, starred: bool) -> None:
#     now = time.time()
#     starred_num = 1 if starred else 0

#     with _conn() as conn:
#         cur = conn.cursor()
#         try:
#             cur.execute(
#                 """
#                 UPDATE CHATBOT_SESSIONS
#                 SET STARRED = :1,
#                     UPDATED_AT = :2
#                 WHERE SESSION_ID = :3
#                 """,
#                 [starred_num, now, session_id],
#             )
#         finally:
#             cur.close()


# def toggle_session_starred(session_id: str) -> Optional[Dict[str, Any]]:
#     session = get_session(session_id)
#     if not session:
#         return None

#     set_session_starred(session_id, not session.get("starred", False))
#     return get_session(session_id)


# def delete_session(session_id: str) -> None:
#     """
#     We delete child rows first to avoid relying on ON DELETE CASCADE.
#     """
#     with _conn() as conn:
#         cur = conn.cursor()
#         try:
#             cur.execute(
#                 "DELETE FROM CHATBOT_RUNS WHERE SESSION_ID = :1",
#                 [session_id],
#             )
#             cur.execute(
#                 "DELETE FROM CHATBOT_MESSAGES WHERE SESSION_ID = :1",
#                 [session_id],
#             )
#             cur.execute(
#                 "DELETE FROM CHATBOT_SESSIONS WHERE SESSION_ID = :1",
#                 [session_id],
#             )
#         finally:
#             cur.close()


# # ---------------------------------------------------------------------------
# # Message CRUD
# # ---------------------------------------------------------------------------

# def add_message(
#     session_id: str,
#     role: str,
#     content: str,
#     meta: Dict = None,
# ) -> Dict[str, Any]:
#     mid = str(uuid.uuid4())
#     now = time.time()

#     with _conn() as conn:
#         cur = conn.cursor()
#         try:
#             cur.execute(
#                 """
#                 SELECT NVL(MAX(TURN_NO), 0) + 1
#                 FROM CHATBOT_MESSAGES
#                 WHERE SESSION_ID = :1
#                 """,
#                 [session_id],
#             )
#             row = cur.fetchone()
#             turn_no = int(row[0]) if row and row[0] is not None else 1

#             cur.execute(
#                 """
#                 INSERT INTO CHATBOT_MESSAGES
#                     (MESSAGE_ID, SESSION_ID, ROLE, CONTENT, TURN_NO, CREATED_AT, META)
#                 VALUES
#                     (:1, :2, :3, :4, :5, :6, :7)
#                 """,
#                 [mid, session_id, role, content, turn_no, now, _json_dumps(meta or {})],
#             )

#             cur.execute(
#                 """
#                 UPDATE CHATBOT_SESSIONS
#                 SET UPDATED_AT = :1
#                 WHERE SESSION_ID = :2
#                 """,
#                 [now, session_id],
#             )
#         finally:
#             cur.close()

#     return get_message(mid)


# def get_message(message_id: str) -> Optional[Dict[str, Any]]:
#     with _conn() as conn:
#         cur = conn.cursor()
#         try:
#             cur.execute(
#                 """
#                 SELECT
#                     MESSAGE_ID,
#                     SESSION_ID,
#                     ROLE,
#                     CONTENT,
#                     TURN_NO AS TURN,
#                     CREATED_AT,
#                     META
#                 FROM CHATBOT_MESSAGES
#                 WHERE MESSAGE_ID = :1
#                 """,
#                 [message_id],
#             )
#             row = _fetchone_dict(cur)
#         finally:
#             cur.close()

#     if row is None:
#         return None

#     if row.get("meta"):
#         row["meta"] = _json_loads_if_possible(row["meta"])
#     else:
#         row["meta"] = {}

#     return row


# def get_session_messages(session_id: str, limit: int = 50) -> List[Dict[str, Any]]:
#     with _conn() as conn:
#         cur = conn.cursor()
#         try:
#             cur.execute(
#                 """
#                 SELECT
#                     MESSAGE_ID,
#                     SESSION_ID,
#                     ROLE,
#                     CONTENT,
#                     TURN_NO AS TURN,
#                     CREATED_AT,
#                     META
#                 FROM CHATBOT_MESSAGES
#                 WHERE SESSION_ID = :1
#                 ORDER BY TURN_NO ASC
#                 FETCH FIRST :2 ROWS ONLY
#                 """,
#                 [session_id, limit],
#             )
#             rows = _fetchall_dicts(cur)
#         finally:
#             cur.close()

#     for row in rows:
#         if row.get("meta"):
#             row["meta"] = _json_loads_if_possible(row["meta"])
#         else:
#             row["meta"] = {}

#     return rows


# def get_history_for_llm(session_id: str, max_turns: int = 10) -> List[Dict[str, str]]:
#     """
#     Return the last N turns as OpenAI-style messages for injection into LLM prompts.
#     Only includes user and assistant messages (not system).
#     """
#     msgs = get_session_messages(session_id, limit=max_turns * 2)
#     result: List[Dict[str, str]] = []

#     for m in msgs:
#         if m["role"] in ("user", "assistant"):
#             result.append({"role": m["role"], "content": m["content"]})

#     return result[-max_turns * 2:]


# # ---------------------------------------------------------------------------
# # Run CRUD
# # ---------------------------------------------------------------------------

# def create_run(session_id: str, question: str, message_id: str = None) -> str:
#     run_id = str(uuid.uuid4())
#     now = time.time()

#     with _conn() as conn:
#         cur = conn.cursor()
#         try:
#             cur.execute(
#                 """
#                 INSERT INTO CHATBOT_RUNS (
#                     RUN_ID,
#                     SESSION_ID,
#                     MESSAGE_ID,
#                     QUESTION,
#                     SHOULD_RUN_PIPELINE,
#                     STATUS,
#                     CREATED_AT
#                 )
#                 VALUES (
#                     :1, :2, :3, :4, :5, :6, :7
#                 )
#                 """,
#                 [run_id, session_id, message_id, question, 0, "pending", now],
#             )
#         finally:
#             cur.close()

#     return run_id


# def update_run(run_id: str, **kwargs) -> None:
#     """
#     Flexible partial update. Accepted kwargs:
#       intent, should_run_pipeline, rephrased_query, plan_envelope (dict->json),
#       composed_sql, verified_sql, db_columns (list->json), db_rows (list->json),
#       db_row_count, answer_text, answer_summary, answer_key_facts (list->json),
#       status, error_message, timing_ms (dict->json), completed_at
#     """
#     json_fields = {
#         "plan_envelope",
#         "db_columns",
#         "db_rows",
#         "answer_key_facts",
#         "timing_ms",
#     }

#     column_map = {
#         "intent": "INTENT",
#         "should_run_pipeline": "SHOULD_RUN_PIPELINE",
#         "rephrased_query": "REPHRASED_QUERY",
#         "plan_envelope": "PLAN_ENVELOPE",
#         "composed_sql": "COMPOSED_SQL",
#         "verified_sql": "VERIFIED_SQL",
#         "db_columns": "DB_COLUMNS",
#         "db_rows": "DB_ROWS",
#         "db_row_count": "DB_ROW_COUNT",
#         "answer_text": "ANSWER_TEXT",
#         "answer_summary": "ANSWER_SUMMARY",
#         "answer_key_facts": "ANSWER_KEY_FACTS",
#         "status": "STATUS",
#         "error_message": "ERROR_MESSAGE",
#         "timing_ms": "TIMING_MS",
#         "completed_at": "COMPLETED_AT",
#     }

#     sets = []
#     vals = []

#     for key, value in kwargs.items():
#         if key not in column_map:
#             continue

#         if key in json_fields and value is not None:
#             value = json.dumps(value)

#         sets.append(f"{column_map[key]} = :{len(vals) + 1}")
#         vals.append(value)

#     if not sets:
#         return

#     vals.append(run_id)

#     sql = f"""
#         UPDATE CHATBOT_RUNS
#         SET {', '.join(sets)}
#         WHERE RUN_ID = :{len(vals)}
#     """

#     with _conn() as conn:
#         cur = conn.cursor()
#         try:
#             cur.execute(sql, vals)
#         finally:
#             cur.close()


# def get_run(run_id: str) -> Optional[Dict[str, Any]]:
#     with _conn() as conn:
#         cur = conn.cursor()
#         try:
#             cur.execute(
#                 """
#                 SELECT
#                     RUN_ID,
#                     SESSION_ID,
#                     MESSAGE_ID,
#                     QUESTION,
#                     INTENT,
#                     SHOULD_RUN_PIPELINE,
#                     REPHRASED_QUERY,
#                     PLAN_ENVELOPE,
#                     COMPOSED_SQL,
#                     VERIFIED_SQL,
#                     DB_COLUMNS,
#                     DB_ROWS,
#                     DB_ROW_COUNT,
#                     ANSWER_TEXT,
#                     ANSWER_SUMMARY,
#                     ANSWER_KEY_FACTS,
#                     STATUS,
#                     ERROR_MESSAGE,
#                     TIMING_MS,
#                     CREATED_AT,
#                     COMPLETED_AT
#                 FROM CHATBOT_RUNS
#                 WHERE RUN_ID = :1
#                 """,
#                 [run_id],
#             )
#             row = _fetchone_dict(cur)
#         finally:
#             cur.close()

#     if row is None:
#         return None

#     return _deserialize_run_fields(row)


# def list_runs(session_id: str, limit: int = 20) -> List[Dict[str, Any]]:
#     with _conn() as conn:
#         cur = conn.cursor()
#         try:
#             cur.execute(
#                 """
#                 SELECT RUN_ID
#                 FROM CHATBOT_RUNS
#                 WHERE SESSION_ID = :1
#                 ORDER BY CREATED_AT DESC
#                 FETCH FIRST :2 ROWS ONLY
#                 """,
#                 [session_id, limit],
#             )
#             rows = cur.fetchall()
#         finally:
#             cur.close()

#     run_ids = [r[0] for r in rows]
#     return [get_run(run_id) for run_id in run_ids]

"""
db/oracle_store.py — Oracle-backed persistence for sessions, messages, and runs.

This mirrors the public API of db/sqlite_store.py so the rest of the app can
switch over with minimal code changes.

Oracle tables expected:
  CHATBOT_SESSIONS
  CHATBOT_MESSAGES
  CHATBOT_RUNS
"""
from __future__ import annotations

import json
import time
import uuid
from contextlib import contextmanager
from typing import Any, Dict, Generator, List, Optional

from core.config import get_settings
from db.oracle import _get_pool


# ---------------------------------------------------------------------------
# Connection helpers
# ---------------------------------------------------------------------------

@contextmanager
def _conn() -> Generator[Any, None, None]:
    """
    Acquire an Oracle pooled connection with commit/rollback handling.
    Also sets CURRENT_SCHEMA if ORACLE_OWNER is configured.
    """
    s = get_settings()
    pool = _get_pool()
    conn = pool.acquire()
    try:
        if s.ORACLE_OWNER:
            cur = conn.cursor()
            try:
                cur.execute(f"ALTER SESSION SET CURRENT_SCHEMA = {s.ORACLE_OWNER}")
            finally:
                cur.close()
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def _read_lob_if_needed(value: Any) -> Any:
    if value is None:
        return None

    if hasattr(value, "read"):
        try:
            return value.read()
        except Exception:
            return str(value)

    return value


def _row_to_dict(cursor: Any, row: Any) -> Dict[str, Any]:
    cols = [d[0].lower() for d in cursor.description]
    values = [_read_lob_if_needed(v) for v in row]
    return dict(zip(cols, values))


def _fetchone_dict(cursor: Any) -> Optional[Dict[str, Any]]:
    row = cursor.fetchone()
    if row is None:
        return None
    return _row_to_dict(cursor, row)


def _fetchall_dicts(cursor: Any) -> List[Dict[str, Any]]:
    rows = cursor.fetchall()
    return [_row_to_dict(cursor, r) for r in rows]


def _json_dumps(value: Any) -> Optional[str]:
    if value is None:
        return None
    return json.dumps(value)


def _json_loads_if_possible(value: Any) -> Any:
    if value is None:
        return None
    if not isinstance(value, str):
        return value
    try:
        return json.loads(value)
    except Exception:
        return value


def _to_bool_flag(value: Any) -> bool:
    return value in (1, "1", True, "true", "TRUE", "Y", "y")


def _deserialize_session_fields(d: Dict[str, Any]) -> Dict[str, Any]:
    if not d:
        return d

    if d.get("meta"):
        d["meta"] = _json_loads_if_possible(d["meta"])
    else:
        d["meta"] = {}

    d["starred"] = _to_bool_flag(d.get("starred", 0))
    return d


def _deserialize_run_fields(d: Dict[str, Any]) -> Dict[str, Any]:
    if not d:
        return d

    for f in ("plan_envelope", "db_columns", "db_rows", "answer_key_facts", "timing_ms"):
        if d.get(f):
            d[f] = _json_loads_if_possible(d[f])

    d["should_run_pipeline"] = _to_bool_flag(d.get("should_run_pipeline", 0))
    return d


def _deserialize_message_fields(d: Dict[str, Any]) -> Dict[str, Any]:
    if not d:
        return d

    if d.get("meta"):
        d["meta"] = _json_loads_if_possible(d["meta"])
    else:
        d["meta"] = {}

    return d


# ---------------------------------------------------------------------------
# Init / validation
# ---------------------------------------------------------------------------

def init_db() -> None:
    required = {"CHATBOT_SESSIONS", "CHATBOT_MESSAGES", "CHATBOT_RUNS"}

    with _conn() as conn:
        cur = conn.cursor()
        try:
            cur.execute(
                """
                SELECT table_name
                FROM user_tables
                WHERE table_name IN (
                    'CHATBOT_SESSIONS',
                    'CHATBOT_MESSAGES',
                    'CHATBOT_RUNS'
                )
                """
            )
            found = {r[0] for r in cur.fetchall()}
        finally:
            cur.close()

    missing = required - found
    if missing:
        raise RuntimeError(
            f"Oracle chatbot tables missing: {', '.join(sorted(missing))}"
        )


# ---------------------------------------------------------------------------
# Session CRUD
# ---------------------------------------------------------------------------

def create_session(user_id: str, title: str = "New Chat", meta: Dict = None) -> Dict[str, Any]:
    sid = str(uuid.uuid4())
    now = time.time()

    with _conn() as conn:
        cur = conn.cursor()
        try:
            cur.execute(
                """
                INSERT INTO CHATBOT_SESSIONS
                    (SESSION_ID, USER_ID, TITLE, CREATED_AT, UPDATED_AT, META, STARRED)
                VALUES
                    (:1, :2, :3, :4, :5, :6, :7)
                """,
                [sid, user_id, title, now, now, _json_dumps(meta or {}), 0],
            )
        finally:
            cur.close()

    return get_session(sid, user_id)


def get_session(session_id: str, user_id: str) -> Optional[Dict[str, Any]]:
    with _conn() as conn:
        cur = conn.cursor()
        try:
            cur.execute(
                """
                SELECT SESSION_ID, USER_ID, TITLE, CREATED_AT, UPDATED_AT, META, STARRED
                FROM CHATBOT_SESSIONS
                WHERE SESSION_ID = :1
                  AND USER_ID = :2
                """,
                [session_id, user_id],
            )
            row = _fetchone_dict(cur)
        finally:
            cur.close()

    if row is None:
        return None

    return _deserialize_session_fields(row)


def list_sessions(user_id: str, limit: int = 50) -> List[Dict[str, Any]]:
    with _conn() as conn:
        cur = conn.cursor()
        try:
            cur.execute(
                """
                SELECT SESSION_ID, USER_ID, TITLE, CREATED_AT, UPDATED_AT, META, STARRED
                FROM CHATBOT_SESSIONS
                WHERE USER_ID = :1
                ORDER BY STARRED DESC, UPDATED_AT DESC
                FETCH FIRST :2 ROWS ONLY
                """,
                [user_id, limit],
            )
            rows = _fetchall_dicts(cur)
        finally:
            cur.close()

    return [_deserialize_session_fields(row) for row in rows]


def update_session_title(session_id: str, user_id: str, title: str) -> None:
    now = time.time()

    with _conn() as conn:
        cur = conn.cursor()
        try:
            cur.execute(
                """
                UPDATE CHATBOT_SESSIONS
                SET TITLE = :1,
                    UPDATED_AT = :2
                WHERE SESSION_ID = :3
                  AND USER_ID = :4
                """,
                [title, now, session_id, user_id],
            )
        finally:
            cur.close()


def set_session_starred(session_id: str, user_id: str, starred: bool) -> None:
    now = time.time()
    starred_num = 1 if starred else 0

    with _conn() as conn:
        cur = conn.cursor()
        try:
            cur.execute(
                """
                UPDATE CHATBOT_SESSIONS
                SET STARRED = :1,
                    UPDATED_AT = :2
                WHERE SESSION_ID = :3
                  AND USER_ID = :4
                """,
                [starred_num, now, session_id, user_id],
            )
        finally:
            cur.close()


def toggle_session_starred(session_id: str, user_id: str) -> Optional[Dict[str, Any]]:
    session = get_session(session_id, user_id)
    if not session:
        return None

    set_session_starred(session_id, user_id, not session.get("starred", False))
    return get_session(session_id, user_id)


def delete_session(session_id: str, user_id: str) -> None:
    if not get_session(session_id, user_id):
        return

    with _conn() as conn:
        cur = conn.cursor()
        try:
            cur.execute(
                "DELETE FROM CHATBOT_RUNS WHERE SESSION_ID = :1",
                [session_id],
            )
            cur.execute(
                "DELETE FROM CHATBOT_MESSAGES WHERE SESSION_ID = :1",
                [session_id],
            )
            cur.execute(
                """
                DELETE FROM CHATBOT_SESSIONS
                WHERE SESSION_ID = :1
                  AND USER_ID = :2
                """,
                [session_id, user_id],
            )
        finally:
            cur.close()


# ---------------------------------------------------------------------------
# Message CRUD
# ---------------------------------------------------------------------------

def add_message(
    session_id: str,
    role: str,
    content: str,
    meta: Dict = None,
) -> Dict[str, Any]:
    mid = str(uuid.uuid4())
    now = time.time()

    with _conn() as conn:
        cur = conn.cursor()
        try:
            cur.execute(
                """
                SELECT NVL(MAX(TURN_NO), 0) + 1
                FROM CHATBOT_MESSAGES
                WHERE SESSION_ID = :1
                """,
                [session_id],
            )
            row = cur.fetchone()
            turn_no = int(row[0]) if row and row[0] is not None else 1

            cur.execute(
                """
                INSERT INTO CHATBOT_MESSAGES
                    (MESSAGE_ID, SESSION_ID, ROLE, CONTENT, TURN_NO, CREATED_AT, META)
                VALUES
                    (:1, :2, :3, :4, :5, :6, :7)
                """,
                [mid, session_id, role, content, turn_no, now, _json_dumps(meta or {})],
            )

            cur.execute(
                """
                UPDATE CHATBOT_SESSIONS
                SET UPDATED_AT = :1
                WHERE SESSION_ID = :2
                """,
                [now, session_id],
            )
        finally:
            cur.close()

    return get_message(mid)


def get_message(message_id: str) -> Optional[Dict[str, Any]]:
    with _conn() as conn:
        cur = conn.cursor()
        try:
            cur.execute(
                """
                SELECT
                    MESSAGE_ID,
                    SESSION_ID,
                    ROLE,
                    CONTENT,
                    TURN_NO AS TURN,
                    CREATED_AT,
                    META
                FROM CHATBOT_MESSAGES
                WHERE MESSAGE_ID = :1
                """,
                [message_id],
            )
            row = _fetchone_dict(cur)
        finally:
            cur.close()

    if row is None:
        return None

    return _deserialize_message_fields(row)


def get_session_messages(session_id: str, user_id: str, limit: int = 50) -> List[Dict[str, Any]]:
    with _conn() as conn:
        cur = conn.cursor()
        try:
            cur.execute(
                """
                SELECT
                    m.MESSAGE_ID,
                    m.SESSION_ID,
                    m.ROLE,
                    m.CONTENT,
                    m.TURN_NO AS TURN,
                    m.CREATED_AT,
                    m.META
                FROM CHATBOT_MESSAGES m
                JOIN CHATBOT_SESSIONS s
                  ON s.SESSION_ID = m.SESSION_ID
                WHERE m.SESSION_ID = :1
                  AND s.USER_ID = :2
                ORDER BY m.TURN_NO ASC
                FETCH FIRST :3 ROWS ONLY
                """,
                [session_id, user_id, limit],
            )
            rows = _fetchall_dicts(cur)
        finally:
            cur.close()

    return [_deserialize_message_fields(row) for row in rows]


def get_history_for_llm(session_id: str, user_id: str, max_turns: int = 10) -> List[Dict[str, str]]:
    msgs = get_session_messages(session_id, user_id=user_id, limit=max_turns * 2)
    result: List[Dict[str, str]] = []

    for m in msgs:
        if m["role"] in ("user", "assistant"):
            result.append({"role": m["role"], "content": m["content"]})

    return result[-max_turns * 2:]


# ---------------------------------------------------------------------------
# Run CRUD
# ---------------------------------------------------------------------------

def create_run(session_id: str, question: str, message_id: str = None) -> str:
    run_id = str(uuid.uuid4())
    now = time.time()

    with _conn() as conn:
        cur = conn.cursor()
        try:
            cur.execute(
                """
                INSERT INTO CHATBOT_RUNS (
                    RUN_ID,
                    SESSION_ID,
                    MESSAGE_ID,
                    QUESTION,
                    SHOULD_RUN_PIPELINE,
                    STATUS,
                    CREATED_AT
                )
                VALUES (
                    :1, :2, :3, :4, :5, :6, :7
                )
                """,
                [run_id, session_id, message_id, question, 0, "pending", now],
            )
        finally:
            cur.close()

    return run_id


def update_run(run_id: str, **kwargs) -> None:
    json_fields = {
        "plan_envelope",
        "db_columns",
        "db_rows",
        "answer_key_facts",
        "timing_ms",
    }

    column_map = {
        "intent": "INTENT",
        "should_run_pipeline": "SHOULD_RUN_PIPELINE",
        "rephrased_query": "REPHRASED_QUERY",
        "plan_envelope": "PLAN_ENVELOPE",
        "composed_sql": "COMPOSED_SQL",
        "verified_sql": "VERIFIED_SQL",
        "db_columns": "DB_COLUMNS",
        "db_rows": "DB_ROWS",
        "db_row_count": "DB_ROW_COUNT",
        "answer_text": "ANSWER_TEXT",
        "answer_summary": "ANSWER_SUMMARY",
        "answer_key_facts": "ANSWER_KEY_FACTS",
        "status": "STATUS",
        "error_message": "ERROR_MESSAGE",
        "timing_ms": "TIMING_MS",
        "completed_at": "COMPLETED_AT",
    }

    sets = []
    vals = []

    for key, value in kwargs.items():
        if key not in column_map:
            continue

        if key in json_fields and value is not None:
            value = json.dumps(value)

        sets.append(f"{column_map[key]} = :{len(vals) + 1}")
        vals.append(value)

    if not sets:
        return

    vals.append(run_id)

    sql = f"""
        UPDATE CHATBOT_RUNS
        SET {', '.join(sets)}
        WHERE RUN_ID = :{len(vals)}
    """

    with _conn() as conn:
        cur = conn.cursor()
        try:
            cur.execute(sql, vals)
        finally:
            cur.close()


def get_run(run_id: str, user_id: str) -> Optional[Dict[str, Any]]:
    with _conn() as conn:
        cur = conn.cursor()
        try:
            cur.execute(
                """
                SELECT
                    r.RUN_ID,
                    r.SESSION_ID,
                    r.MESSAGE_ID,
                    r.QUESTION,
                    r.INTENT,
                    r.SHOULD_RUN_PIPELINE,
                    r.REPHRASED_QUERY,
                    r.PLAN_ENVELOPE,
                    r.COMPOSED_SQL,
                    r.VERIFIED_SQL,
                    r.DB_COLUMNS,
                    r.DB_ROWS,
                    r.DB_ROW_COUNT,
                    r.ANSWER_TEXT,
                    r.ANSWER_SUMMARY,
                    r.ANSWER_KEY_FACTS,
                    r.STATUS,
                    r.ERROR_MESSAGE,
                    r.TIMING_MS,
                    r.CREATED_AT,
                    r.COMPLETED_AT
                FROM CHATBOT_RUNS r
                JOIN CHATBOT_SESSIONS s
                  ON s.SESSION_ID = r.SESSION_ID
                WHERE r.RUN_ID = :1
                  AND s.USER_ID = :2
                """,
                [run_id, user_id],
            )
            row = _fetchone_dict(cur)
        finally:
            cur.close()

    if row is None:
        return None

    return _deserialize_run_fields(row)


def list_runs(session_id: str, user_id: str, limit: int = 20) -> List[Dict[str, Any]]:
    if not get_session(session_id, user_id):
        return []

    with _conn() as conn:
        cur = conn.cursor()
        try:
            cur.execute(
                """
                SELECT r.RUN_ID
                FROM CHATBOT_RUNS r
                JOIN CHATBOT_SESSIONS s
                  ON s.SESSION_ID = r.SESSION_ID
                WHERE r.SESSION_ID = :1
                  AND s.USER_ID = :2
                ORDER BY r.CREATED_AT DESC
                FETCH FIRST :3 ROWS ONLY
                """,
                [session_id, user_id, limit],
            )
            rows = cur.fetchall()
        finally:
            cur.close()

    run_ids = [r[0] for r in rows]
    return [run for run in (get_run(run_id, user_id) for run_id in run_ids) if run is not None]