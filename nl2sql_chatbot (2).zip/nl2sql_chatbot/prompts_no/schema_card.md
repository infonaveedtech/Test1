# ATS Schema Card
# ─────────────────────────────────────────────────────────────────────────────
# This file is injected into Agent-1 (Planner) and Agent-3 (Verifier) prompts.
# Keep it accurate. Add all tables with their actual column names and types.
# ─────────────────────────────────────────────────────────────────────────────

## ATS.SYMBOL_DAILY_INDICATORS
Primary key: SYMBOL_ID + STATS_DATE
Date column: STATS_DATE (DATE) — use TRUNC(STATS_DATE, 'DD'/'MM'/'YYYY')
Columns:
  SYMBOL_ID          NUMBER        FK → ATS.SYMBOLS.SYMBOL_ID
  STATS_DATE         DATE          trading day (no intraday)
  OPEN_PRICE         NUMBER(18,4)
  HIGH_PRICE         NUMBER(18,4)
  LOW_PRICE          NUMBER(18,4)
  CLOSE_PRICE        NUMBER(18,4)
  VOLUME             NUMBER(18,0)
  TURNOVER_VALUE     NUMBER(22,4)  total traded value (price × volume)
  TRADE_COUNT        NUMBER(10,0)

## ATS.SYMBOL_INDICATORS
Primary key: SYMBOL_ID + ENTRY_DATETIME + EXCHANGE_ID
Date column: ENTRY_DATETIME (TIMESTAMP)
Columns:
  SYMBOL_ID          NUMBER        FK → ATS.SYMBOLS.SYMBOL_ID
  EXCHANGE_ID        NUMBER        FK → ATS.EXCHANGES.EXCHANGE_ID
  ENTRY_DATETIME     TIMESTAMP
  OPEN               NUMBER(18,4)
  HIGH               NUMBER(18,4)
  LOW                NUMBER(18,4)
  CLOSE              NUMBER(18,4)
  VOLUME             NUMBER(18,0)
  TURNOVER           NUMBER(22,4)

## ATS.SYMBOLS
Primary key: SYMBOL_ID
Columns:
  SYMBOL_ID          NUMBER        PK
  SYMBOL             VARCHAR2(20)  ticker code
  SYMBOL_NAME        VARCHAR2(200) full company name
  SECTOR             VARCHAR2(100)
  IS_ACTIVE          CHAR(1)       'Y' / 'N'

## ATS.EXCHANGES
Primary key: EXCHANGE_ID
Columns:
  EXCHANGE_ID        NUMBER        PK
  EXCHANGE_NAME      VARCHAR2(100)
  EXCHANGE_CODE      VARCHAR2(20)
  COUNTRY            VARCHAR2(50)
  IS_ACTIVE          CHAR(1)

## ATS.BEST_MKT
Primary key: SYMBOL_ID + EXCHANGE_ID + ENTRY_DATETIME
Date column: ENTRY_DATETIME (TIMESTAMP)
Columns:
  SYMBOL_ID          NUMBER        FK → ATS.SYMBOLS.SYMBOL_ID
  EXCHANGE_ID        NUMBER        FK → ATS.EXCHANGES.EXCHANGE_ID
  ENTRY_DATETIME     TIMESTAMP
  BID_PRICE          NUMBER(18,4)
  OFFER_PRICE        NUMBER(18,4)
  BID_SIZE           NUMBER(18,0)
  OFFER_SIZE         NUMBER(18,0)

# ─────────────────────────────────────────────────────────────────────────────
# CANONICAL JOINS (copy these exactly into SQL — do not invent new join paths)
# ─────────────────────────────────────────────────────────────────────────────
# ATS.SYMBOL_DAILY_INDICATORS.SYMBOL_ID = ATS.SYMBOLS.SYMBOL_ID
# ATS.SYMBOL_INDICATORS.SYMBOL_ID = ATS.SYMBOLS.SYMBOL_ID
# ATS.SYMBOL_INDICATORS.EXCHANGE_ID = ATS.EXCHANGES.EXCHANGE_ID
# ATS.BEST_MKT.SYMBOL_ID = ATS.SYMBOLS.SYMBOL_ID
# ATS.BEST_MKT.EXCHANGE_ID = ATS.EXCHANGES.EXCHANGE_ID

# ─────────────────────────────────────────────────────────────────────────────
# BUSINESS RULES
# ─────────────────────────────────────────────────────────────────────────────
# 1. Always use FETCH FIRST N ROWS ONLY — never ROWNUM or LIMIT
# 2. Default time scope when user says "recent": last 30 days (SYSDATE - 30)
# 3. "Last month" = ADD_MONTHS(TRUNC(SYSDATE,'MM'), -1) to TRUNC(SYSDATE,'MM')
# 4. Turnover = sum of TURNOVER_VALUE (SYMBOL_DAILY_INDICATORS) or TURNOVER (SYMBOL_INDICATORS)
# 5. Spread = OFFER_PRICE - BID_PRICE (from BEST_MKT)
# 6. Only query active symbols unless user asks for inactive: IS_ACTIVE = 'Y'
