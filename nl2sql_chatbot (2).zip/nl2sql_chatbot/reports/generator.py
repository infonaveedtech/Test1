"""
reports/generator.py — PDF and DOCX report generation from run results.
Uses reportlab for PDF, python-docx for DOCX.
"""
from __future__ import annotations

import io
import logging
from datetime import datetime
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


# ── Shared helpers ────────────────────────────────────────────────────────────

def _format_timestamp() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _truncate_rows(rows: List[List], max_rows: int = 100) -> List[List]:
    return rows[:max_rows]


# ── PDF ───────────────────────────────────────────────────────────────────────

def build_pdf(
    run: Dict[str, Any],
    title: str = "Analytics Report",
    generated_by: str = "NL2SQL Chatbot",
    show_sql: bool = False,
) -> bytes:
    """
    Generate a professional PDF report from a run result.
    Returns raw bytes.
    """
    try:
        from reportlab.lib import colors
        from reportlab.lib.pagesizes import A4, landscape
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib.units import cm, mm
        from reportlab.platypus import (
            SimpleDocTemplate, Paragraph, Spacer, Table,
            TableStyle, HRFlowable, PageBreak,
        )
        from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_RIGHT
    except ImportError:
        raise RuntimeError("reportlab is not installed. Run: pip install reportlab")

    buf = io.BytesIO()

    # Choose landscape if many columns
    columns = run.get("db_columns") or []
    page_size = landscape(A4) if len(columns) > 6 else A4
    doc = SimpleDocTemplate(
        buf,
        pagesize=page_size,
        rightMargin=1.5 * cm,
        leftMargin=1.5 * cm,
        topMargin=2 * cm,
        bottomMargin=2 * cm,
    )

    styles = getSampleStyleSheet()
    BRAND = colors.HexColor("#1A237E")
    ACCENT = colors.HexColor("#3949AB")
    LIGHT = colors.HexColor("#E8EAF6")
    GREY = colors.HexColor("#757575")

    style_h1 = ParagraphStyle("H1", parent=styles["Heading1"],
                               textColor=BRAND, fontSize=18, spaceAfter=6)
    style_h2 = ParagraphStyle("H2", parent=styles["Heading2"],
                               textColor=ACCENT, fontSize=13, spaceAfter=4)
    style_body = ParagraphStyle("Body", parent=styles["Normal"],
                                 fontSize=9.5, leading=14, spaceAfter=4)
    style_meta = ParagraphStyle("Meta", parent=styles["Normal"],
                                 fontSize=8, textColor=GREY)
    style_fact = ParagraphStyle("Fact", parent=styles["Normal"],
                                 fontSize=10, leading=15, leftIndent=12,
                                 bulletIndent=4, spaceAfter=2)
    style_sql = ParagraphStyle("SQL", parent=styles["Code"],
                                fontSize=7.5, leading=11, backColor=colors.HexColor("#F5F5F5"),
                                leftIndent=8, spaceAfter=4)

    story = []

    # ── Header ──
    story.append(Paragraph(title, style_h1))
    story.append(Paragraph(
        f"Generated: {_format_timestamp()} &nbsp;&nbsp;|&nbsp;&nbsp; By: {generated_by}",
        style_meta,
    ))
    story.append(HRFlowable(width="100%", thickness=2, color=BRAND, spaceAfter=12))

    # ── Question ──
    story.append(Paragraph("Question", style_h2))
    story.append(Paragraph(run.get("question", ""), style_body))
    story.append(Spacer(1, 6))

    # ── Summary answer ──
    if run.get("answer_summary"):
        story.append(Paragraph("Summary", style_h2))
        story.append(Paragraph(run["answer_summary"], style_body))
        story.append(Spacer(1, 4))

    # ── Full answer ──
    if run.get("answer_text"):
        story.append(Paragraph("Analysis", style_h2))
        story.append(Paragraph(run["answer_text"].replace("\n", "<br/>"), style_body))
        story.append(Spacer(1, 6))

    # ── Key facts ──
    key_facts = run.get("answer_key_facts") or []
    if key_facts:
        story.append(Paragraph("Key Findings", style_h2))
        for fact in key_facts:
            story.append(Paragraph(f"• {fact}", style_fact))
        story.append(Spacer(1, 6))

    # ── Data table ──
    rows_data = run.get("db_rows") or []
    if columns and rows_data:
        story.append(Paragraph("Data", style_h2))
        row_count = run.get("db_row_count", len(rows_data))
        truncated_note = f" (showing first {len(rows_data[:100])} of {row_count})" if row_count > 100 else ""
        story.append(Paragraph(f"{row_count} rows returned{truncated_note}", style_meta))
        story.append(Spacer(1, 4))

        display_rows = _truncate_rows(rows_data, 100)
        table_data = [columns] + [
            [str(v) if v is not None else "" for v in row]
            for row in display_rows
        ]

        col_width = (page_size[0] - 3 * cm) / max(len(columns), 1)
        col_widths = [min(col_width, 5 * cm)] * len(columns)

        tbl = Table(table_data, colWidths=col_widths, repeatRows=1)
        tbl.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), BRAND),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE", (0, 0), (-1, 0), 8),
            ("FONTSIZE", (0, 1), (-1, -1), 7.5),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, LIGHT]),
            ("GRID", (0, 0), (-1, -1), 0.3, GREY),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("TOPPADDING", (0, 0), (-1, -1), 3),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
            ("LEFTPADDING", (0, 0), (-1, -1), 4),
            ("RIGHTPADDING", (0, 0), (-1, -1), 4),
            ("WORDWRAP", (0, 0), (-1, -1), True),
        ]))
        story.append(tbl)
        story.append(Spacer(1, 10))

    # ── SQL (optional) ──
    if show_sql and run.get("verified_sql"):
        story.append(Paragraph("SQL Query", style_h2))
        sql_lines = run["verified_sql"].replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        for line in sql_lines.split("\n"):
            story.append(Paragraph(line or "&nbsp;", style_sql))
        story.append(Spacer(1, 6))

    # ── Timing ──
    timing = run.get("timing_ms") or {}
    if timing:
        total_ms = timing.get("total", 0)
        story.append(HRFlowable(width="100%", thickness=0.5, color=GREY, spaceAfter=4))
        story.append(Paragraph(
            f"Total processing time: {total_ms:.0f} ms | Run ID: {run.get('run_id', '')}",
            style_meta,
        ))

    doc.build(story)
    return buf.getvalue()


# ── DOCX ──────────────────────────────────────────────────────────────────────

def build_docx(
    run: Dict[str, Any],
    title: str = "Analytics Report",
    generated_by: str = "NL2SQL Chatbot",
    show_sql: bool = False,
) -> bytes:
    """
    Generate a professional DOCX report from a run result.
    Returns raw bytes.
    """
    try:
        from docx import Document
        from docx.shared import Pt, Cm, RGBColor
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        from docx.oxml.ns import qn
        from docx.oxml import OxmlElement
    except ImportError:
        raise RuntimeError("python-docx is not installed. Run: pip install python-docx")

    doc = Document()

    BRAND = RGBColor(0x1A, 0x23, 0x7E)
    ACCENT = RGBColor(0x39, 0x49, 0xAB)
    GREY = RGBColor(0x75, 0x75, 0x75)

    # Page margins
    for section in doc.sections:
        section.top_margin = Cm(2)
        section.bottom_margin = Cm(2)
        section.left_margin = Cm(2)
        section.right_margin = Cm(2)

    def _heading(text, level=1, color=BRAND):
        h = doc.add_heading(text, level=level)
        for run_obj in h.runs:
            run_obj.font.color.rgb = color
        return h

    def _body(text):
        p = doc.add_paragraph(text)
        p.style.font.size = Pt(10)
        return p

    def _meta(text):
        p = doc.add_paragraph(text)
        for run_obj in p.runs:
            run_obj.font.size = Pt(8)
            run_obj.font.color.rgb = GREY
        return p

    # ── Title block ──
    _heading(title, level=1)
    _meta(f"Generated: {_format_timestamp()}  |  By: {generated_by}")
    doc.add_paragraph()

    # ── Question ──
    _heading("Question", level=2, color=ACCENT)
    _body(run.get("question", ""))

    # ── Summary ──
    if run.get("answer_summary"):
        _heading("Summary", level=2, color=ACCENT)
        _body(run["answer_summary"])

    # ── Analysis ──
    if run.get("answer_text"):
        _heading("Analysis", level=2, color=ACCENT)
        _body(run["answer_text"])

    # ── Key facts ──
    key_facts = run.get("answer_key_facts") or []
    if key_facts:
        _heading("Key Findings", level=2, color=ACCENT)
        for fact in key_facts:
            p = doc.add_paragraph(style="List Bullet")
            p.add_run(fact).font.size = Pt(10)

    # ── Data table ──
    columns = run.get("db_columns") or []
    rows_data = run.get("db_rows") or []
    if columns and rows_data:
        _heading("Data", level=2, color=ACCENT)
        row_count = run.get("db_row_count", len(rows_data))
        _meta(f"{row_count} rows returned")

        display_rows = _truncate_rows(rows_data, 200)
        tbl = doc.add_table(rows=1 + len(display_rows), cols=len(columns))
        tbl.style = "Table Grid"

        # Header row
        hdr = tbl.rows[0]
        for i, col in enumerate(columns):
            cell = hdr.cells[i]
            cell.text = str(col)
            run_obj = cell.paragraphs[0].runs[0]
            run_obj.bold = True
            run_obj.font.size = Pt(8)
            run_obj.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
            # Cell shading
            tc = cell._tc
            tcPr = tc.get_or_add_tcPr()
            shd = OxmlElement("w:shd")
            shd.set(qn("w:val"), "clear")
            shd.set(qn("w:color"), "auto")
            shd.set(qn("w:fill"), "1A237E")
            tcPr.append(shd)

        # Data rows
        for r_idx, row in enumerate(display_rows):
            tbl_row = tbl.rows[r_idx + 1]
            fill = "E8EAF6" if r_idx % 2 == 1 else "FFFFFF"
            for c_idx, val in enumerate(row):
                cell = tbl_row.cells[c_idx]
                cell.text = str(val) if val is not None else ""
                cell.paragraphs[0].runs[0].font.size = Pt(8)
                tc = cell._tc
                tcPr = tc.get_or_add_tcPr()
                shd = OxmlElement("w:shd")
                shd.set(qn("w:val"), "clear")
                shd.set(qn("w:color"), "auto")
                shd.set(qn("w:fill"), fill)
                tcPr.append(shd)

    # ── SQL (optional) ──
    if show_sql and run.get("verified_sql"):
        _heading("SQL Query", level=2, color=ACCENT)
        p = doc.add_paragraph()
        run_obj = p.add_run(run["verified_sql"])
        run_obj.font.name = "Courier New"
        run_obj.font.size = Pt(8)

    # ── Footer meta ──
    doc.add_paragraph()
    _meta(f"Run ID: {run.get('run_id', '')}  |  Timing: {(run.get('timing_ms') or {}).get('total', 0):.0f} ms")

    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue()
