# """
# pipeline/orchestrator.py — Main Pipeline Orchestrator

# Coordinates Agent-0 through Agent-4, DB execution, and session management.
# Handles all cases:
#   - Direct DB pipeline (most queries)
#   - Clarification flow
#   - Small talk / meta questions
#   - Follow-up queries with context
#   - Error recovery
# """
# from __future__ import annotations

# import logging
# import time
# from typing import Any, Dict, List, Optional

# from core.config import get_settings
# from core.exceptions import (
#     ClarificationRequired,
#     UnsafeQueryError,
#     PlannerError,
#     ComposerError,
#     VerifierError,
# )

# import agents.agent0_intent as agent0
# import agents.agent1_planner as agent1
# import agents.agent2_composer as agent2
# import agents.agent3_verifier as agent3
# import agents.agent4_responder as agent4

# from db import sqlite_store as store
# from db import oracle
# from rag.retriever import retrieve_context

# logger = logging.getLogger(__name__)


# # ── Result dataclass-like dict ────────────────────────────────────────────────

# def _make_result(
#     *,
#     run_id: str,
#     session_id: str,
#     status: str,                    # "success" | "clarification" | "direct" | "error"
#     message: str,                   # primary text to show user
#     summary: str = "",
#     key_facts: List[str] = None,
#     follow_ups: List[str] = None,
#     clarification_questions: List[str] = None,
#     data: Optional[Dict] = None,    # {columns, rows, row_count, truncated}
#     composed_sql: str = "",
#     verified_sql: str = "",
#     plan_envelope: Optional[Dict] = None,
#     intent: str = "",
#     timing: Dict[str, float] = None,
#     error: str = "",
# ) -> Dict[str, Any]:
#     return {
#         "run_id": run_id,
#         "session_id": session_id,
#         "status": status,
#         "message": message,
#         "summary": summary,
#         "key_facts": key_facts or [],
#         "follow_up_suggestions": follow_ups or [],
#         "clarification_questions": clarification_questions or [],
#         "data": data,
#         "composed_sql": composed_sql,
#         "verified_sql": verified_sql,
#         "plan_envelope": plan_envelope,
#         "intent": intent,
#         "timing_ms": timing or {},
#         "error": error,
#     }


# # ── Timer helper ───────────────────────────────────────────────────────────────

# class _Timer:
#     def __init__(self):
#         self._start = time.perf_counter()
#         self._marks: Dict[str, float] = {}

#     def mark(self, label: str):
#         self._marks[label] = round((time.perf_counter() - self._start) * 1000, 1)

#     def total(self) -> float:
#         return round((time.perf_counter() - self._start) * 1000, 1)

#     def all(self) -> Dict[str, float]:
#         d = dict(self._marks)
#         d["total"] = self.total()
#         return d


# # ── Orchestrator ───────────────────────────────────────────────────────────────

# def run_pipeline(
#     session_id: str,
#     user_message: str,
#     *,
#     clarifications_for_pending: List[str] = None,  # answers to prior clarification questions
#     row_limit: int = None,
#     debug: bool = False,
# ) -> Dict[str, Any]:
#     """
#     Main entry point. Process one user message in the context of session_id.

#     Args:
#         session_id: Existing session ID (must already exist in DB).
#         user_message: The raw user input.
#         clarifications_for_pending: If the user was answering clarification questions,
#                                     pass those answers here.
#         row_limit: Override default row limit.
#         debug: Enable extra logging.

#     Returns:
#         Result dict (see _make_result).
#     """
#     s = get_settings()
#     t = _Timer()

#     # ── 1. Persist user message ──────────────────────────────────
#     user_msg_obj = store.add_message(session_id, "user", user_message)
#     run_id = store.create_run(session_id, user_message, message_id=user_msg_obj["message_id"])

#     # ── 2. Load conversation history ─────────────────────────────
#     history = store.get_history_for_llm(session_id, max_turns=10)
#     # Remove the just-added user message so it doesn't appear twice in history
#     history = [m for m in history if not (m.get("content") == user_message and m.get("role") == "user")]

#     eff_row_limit = row_limit or s.ORACLE_DEFAULT_ROW_LIMIT

#     # ── 3. Auto-title session from first user message ─────────────
#     session = store.get_session(session_id)
#     if session and session["title"] == "New Chat":
#         short_title = user_message[:60].strip()
#         store.update_session_title(session_id, short_title)

#     # Declare intent/pipeline variables before try so except blocks can safely reference them
#     intent: str = ""
#     composed_sql: str = ""
#     verified_sql: str = ""
#     envelope: dict = {}

#     try:
#         # ── 4. Agent-0: Intent classification ──────────────────────
#         logger.info("[Pipeline] Agent-0 starting for run=%s", run_id)
#         try:
#             intent_obj = agent0.run(user_message, conversation_history=history)
#         except ClarificationRequired as e:
#             t.mark("agent0")
#             logger.info("[Pipeline] Clarification required: %s", e.questions)
#             assistant_msg = _build_clarification_message(
#                 e.assistant_message, e.questions
#             )
#             store.add_message(session_id, "assistant", assistant_msg)
#             store.update_run(
#                 run_id,
#                 intent="clarification",
#                 status="clarification",
#                 timing_ms=t.all(),
#                 completed_at=time.time(),
#             )
#             return _make_result(
#                 run_id=run_id,
#                 session_id=session_id,
#                 status="clarification",
#                 message=assistant_msg,
#                 clarification_questions=e.questions,
#                 intent="clarification",
#                 timing=t.all(),
#             )
#         except UnsafeQueryError as e:
#             t.mark("agent0")
#             msg = f"I can't process this request: {e.reason}"
#             store.add_message(session_id, "assistant", msg)
#             store.update_run(run_id, intent="unsafe", status="error", error_message=str(e),
#                              timing_ms=t.all(), completed_at=time.time())
#             return _make_result(
#                 run_id=run_id, session_id=session_id,
#                 status="error", message=msg, intent="unsafe", timing=t.all(), error=str(e),
#             )

#         t.mark("agent0")
#         intent = intent_obj.get("intent", "sql_query")
#         rephrased = intent_obj.get("rephrased_query", user_message)

#         store.update_run(
#             run_id,
#             intent=intent,
#             should_run_pipeline=1 if intent_obj.get("should_run_pipeline") else 0,
#             rephrased_query=rephrased,
#         )

#         # ── 5. Non-pipeline intents (small talk, meta, etc.) ────────
#         if not intent_obj.get("should_run_pipeline"):
#             reply = intent_obj.get("assistant_reply") or _handle_non_pipeline(intent, history)
#             store.add_message(session_id, "assistant", reply)
#             store.update_run(run_id, status="direct", timing_ms=t.all(), completed_at=time.time())
#             return _make_result(
#                 run_id=run_id, session_id=session_id,
#                 status="direct", message=reply, intent=intent, timing=t.all(),
#             )

#         # ── 6. RAG Retrieval ────────────────────────────────────────
#         logger.info("[Pipeline] RAG retrieval for: '%s'", rephrased[:80])
#         rag_ctx = retrieve_context(rephrased)
#         t.mark("rag")

#         # ── 7. Agent-1: Planner ─────────────────────────────────────
#         logger.info("[Pipeline] Agent-1 (Planner) starting…")
#         envelope = agent1.run(
#             rephrased_query=rephrased,
#             rag_context=rag_ctx,
#             conversation_history=history,
#             clarifications=clarifications_for_pending,
#         )
#         t.mark("agent1")
#         store.update_run(run_id, plan_envelope=envelope)

#         # ── 8. Agent-2: Composer ────────────────────────────────────
#         logger.info("[Pipeline] Agent-2 (Composer) starting…")
#         composed_sql = agent2.run(rephrased_query=rephrased, envelope=envelope)
#         t.mark("agent2")
#         store.update_run(run_id, composed_sql=composed_sql)

#         # ── 9. Agent-3: Verifier ────────────────────────────────────
#         logger.info("[Pipeline] Agent-3 (Verifier) starting…")
#         verified_sql, rationale = agent3.run(
#             original_sql=composed_sql, envelope=envelope
#         )
#         t.mark("agent3")
#         store.update_run(run_id, verified_sql=verified_sql)

#         # ── 10. DB Execution ─────────────────────────────────────────
#         if not s.ENABLE_SQL_EXECUTION:
#             logger.info("[Pipeline] DB execution disabled — returning SQL only.")
#             assistant_msg = (
#                 f"Here is the SQL I would run:\n```sql\n{verified_sql}\n```\n"
#                 "(DB execution is currently disabled)"
#             )
#             store.add_message(session_id, "assistant", assistant_msg)
#             store.update_run(run_id, status="success", timing_ms=t.all(), completed_at=time.time())
#             return _make_result(
#                 run_id=run_id, session_id=session_id,
#                 status="success", message=assistant_msg,
#                 verified_sql=verified_sql, composed_sql=composed_sql,
#                 plan_envelope=envelope, intent=intent, timing=t.all(),
#             )

#         logger.info("[Pipeline] Executing SQL…")
#         try:
#             db_result = oracle.run_sql(verified_sql, row_limit=eff_row_limit)
#         except Exception as exc:
#             logger.error("[Pipeline] DB execution failed: %s", exc)
#             err_msg = f"The SQL executed but returned an error: {exc}"
#             store.add_message(session_id, "assistant", err_msg)
#             store.update_run(run_id, status="error", error_message=str(exc),
#                              timing_ms=t.all(), completed_at=time.time())
#             return _make_result(
#                 run_id=run_id, session_id=session_id,
#                 status="error", message=err_msg, intent=intent,
#                 verified_sql=verified_sql, composed_sql=composed_sql,
#                 plan_envelope=envelope, timing=t.all(), error=str(exc),
#             )

#         t.mark("db")
#         store.update_run(
#             run_id,
#             db_columns=db_result.get("columns", []),
#             db_rows=db_result.get("rows", []),
#             db_row_count=db_result.get("row_count", 0),
#         )

#         # ── 11. Agent-4: Responder ───────────────────────────────────
#         logger.info("[Pipeline] Agent-4 (Responder) starting…")
#         response = agent4.run(
#             question=rephrased,
#             db_result=db_result,
#             verified_sql=verified_sql,
#             conversation_history=history,
#         )
#         t.mark("agent4")

#         # ── 12. Persist & return ─────────────────────────────────────
#         assistant_text = response.get("answer", "")
#         store.add_message(
#             session_id, "assistant", assistant_text,
#             meta={"summary": response.get("summary"), "run_id": run_id},
#         )

#         store.update_run(
#             run_id,
#             answer_text=assistant_text,
#             answer_summary=response.get("summary", ""),
#             answer_key_facts=response.get("key_facts", []),
#             status="success",
#             timing_ms=t.all(),
#             completed_at=time.time(),
#         )

#         logger.info(
#             "[Pipeline] Done run=%s total=%.0fms", run_id, t.total()
#         )

#         return _make_result(
#             run_id=run_id,
#             session_id=session_id,
#             status="success",
#             message=assistant_text,
#             summary=response.get("summary", ""),
#             key_facts=response.get("key_facts", []),
#             follow_ups=response.get("follow_up_suggestions", []),
#             data=db_result,
#             composed_sql=composed_sql,
#             verified_sql=verified_sql,
#             plan_envelope=envelope,
#             intent=intent,
#             timing=t.all(),
#         )

#     except (PlannerError, ComposerError, VerifierError) as exc:
#         logger.error("[Pipeline] Agent error: %s", exc)
#         err_msg = f"I encountered an issue processing your query: {exc}"
#         store.add_message(session_id, "assistant", err_msg)
#         store.update_run(run_id, status="error", error_message=str(exc),
#                          timing_ms=t.all(), completed_at=time.time())
#         return _make_result(
#             run_id=run_id, session_id=session_id,
#             status="error", message=err_msg, intent=intent,
#             timing=t.all(), error=str(exc),
#         )

#     except Exception as exc:
#         logger.exception("[Pipeline] Unexpected error for run=%s: %s", run_id, exc)
#         err_msg = "An unexpected error occurred. Please try again."
#         try:
#             store.add_message(session_id, "assistant", err_msg)
#             store.update_run(run_id, status="error", error_message=str(exc),
#                              timing_ms=t.all(), completed_at=time.time())
#         except Exception:
#             pass
#         return _make_result(
#             run_id=run_id, session_id=session_id,
#             status="error", message=err_msg, timing=t.all(), error=str(exc),
#         )


# def _build_clarification_message(assistant_msg: str, questions: List[str]) -> str:
#     """Format a user-friendly clarification message."""
#     if assistant_msg:
#         msg = assistant_msg + "\n\n"
#     else:
#         msg = "I need a bit more information to answer your question accurately:\n\n"
#     for i, q in enumerate(questions, 1):
#         msg += f"{i}. {q}\n"
#     return msg.strip()


# def _handle_non_pipeline(intent: str, history: List[Dict]) -> str:
#     """Generate a simple reply for non-DB intents without calling the LLM."""
#     if intent == "small_talk":
#         return (
#             "I'm your financial markets data assistant. "
#             "You can ask me things like:\n"
#             "- \"Show me the top 10 symbols by turnover this month\"\n"
#             "- \"What's the month-over-month volume trend for the last 6 months?\"\n"
#             "- \"Which exchange has the tightest spreads today?\""
#         )
#     if intent == "meta_question":
#         return (
#             "I have access to a financial markets Oracle database (ATS schema) with:\n"
#             "- **Symbol data**: prices, volumes, turnover, spreads\n"
#             "- **Exchange data**: exchange names, market segments\n"
#             "- **Time-series**: daily and intraday indicators\n\n"
#             "I can generate SQL queries, execute them, and summarize the results. "
#             "I can also export results to PDF or DOCX.\n\n"
#             "Try asking: *\"What were the top 5 exchanges by volume last week?\"*"
#         )
#     return "I'm not sure how to help with that. Try asking about your trading data!"


"""
pipeline/orchestrator.py — Main Pipeline Orchestrator

Coordinates Agent-0 through Agent-4, DB execution, and session management.
Handles all cases:
  - Direct DB pipeline (most queries)
  - Clarification flow
  - Small talk / meta questions
  - Follow-up queries with context
  - Error recovery
"""
from __future__ import annotations

import logging
import time
from typing import Any, Dict, List, Optional

from core.config import get_settings
from core.exceptions import (
    ClarificationRequired,
    UnsafeQueryError,
    PlannerError,
    ComposerError,
    VerifierError,
)

import agents.agent0_intent as agent0
import agents.agent1_planner as agent1
import agents.agent2_composer as agent2
import agents.agent3_verifier as agent3
import agents.agent4_responder as agent4

from db import sqlite_store as store
from db import oracle
from rag.retriever import retrieve_context

logger = logging.getLogger(__name__)


# ── Result dataclass-like dict ────────────────────────────────────────────────

def _make_result(
    *,
    run_id: str,
    session_id: str,
    status: str,                    # "success" | "clarification" | "direct" | "error"
    message: str,                   # primary text to show user
    summary: str = "",
    key_facts: List[str] = None,
    follow_ups: List[str] = None,
    clarification_questions: List[str] = None,
    data: Optional[Dict] = None,    # {columns, rows, row_count, truncated}
    composed_sql: str = "",
    verified_sql: str = "",
    plan_envelope: Optional[Dict] = None,
    intent: str = "",
    timing: Dict[str, float] = None,
    error: str = "",
) -> Dict[str, Any]:
    return {
        "run_id": run_id,
        "session_id": session_id,
        "status": status,
        "message": message,
        "summary": summary,
        "key_facts": key_facts or [],
        "follow_up_suggestions": follow_ups or [],
        "clarification_questions": clarification_questions or [],
        "data": data,
        "composed_sql": composed_sql,
        "verified_sql": verified_sql,
        "plan_envelope": plan_envelope,
        "intent": intent,
        "timing_ms": timing or {},
        "error": error,
    }


# ── Timer helper ───────────────────────────────────────────────────────────────

class _Timer:
    def __init__(self):
        self._start = time.perf_counter()
        self._marks: Dict[str, float] = {}

    def mark(self, label: str):
        self._marks[label] = round((time.perf_counter() - self._start) * 1000, 1)

    def total(self) -> float:
        return round((time.perf_counter() - self._start) * 1000, 1)

    def all(self) -> Dict[str, float]:
        d = dict(self._marks)
        d["total"] = self.total()
        return d


# ── Orchestrator ───────────────────────────────────────────────────────────────

def run_pipeline(
    session_id: str,
    user_message: str,
    *,
    clarifications_for_pending: List[str] = None,  # answers to prior clarification questions
    row_limit: int = None,
    debug: bool = False,
) -> Dict[str, Any]:
    """
    Main entry point. Process one user message in the context of session_id.

    Args:
        session_id: Existing session ID (must already exist in DB).
        user_message: The raw user input.
        clarifications_for_pending: If the user was answering clarification questions,
                                    pass those answers here.
        row_limit: Override default row limit.
        debug: Enable extra logging.

    Returns:
        Result dict (see _make_result).
    """
    s = get_settings()
    t = _Timer()

    # ── 1. Persist user message ──────────────────────────────────
    user_msg_obj = store.add_message(session_id, "user", user_message)
    run_id = store.create_run(session_id, user_message, message_id=user_msg_obj["message_id"])

    # ── 2. Load conversation history ─────────────────────────────
    history = store.get_history_for_llm(session_id, max_turns=10)
    # Remove the just-added user message so it doesn't appear twice in history
    history = [m for m in history if not (m.get("content") == user_message and m.get("role") == "user")]

    eff_row_limit = row_limit or s.ORACLE_DEFAULT_ROW_LIMIT

    # ── 3. Auto-title session from first user message ─────────────
    session = store.get_session(session_id)
    if session and session["title"] == "New Chat":
        short_title = user_message[:60].strip()
        store.update_session_title(session_id, short_title)

    # Declare intent/pipeline variables before try so except blocks can safely reference them
    intent: str = ""
    composed_sql: str = ""
    verified_sql: str = ""
    envelope: dict = {}

    try:
        # ── 4. Agent-0: Intent classification ──────────────────────
        logger.info("[Pipeline] Agent-0 starting for run=%s", run_id)
        try:
            intent_obj = agent0.run(user_message, conversation_history=history)
        except ClarificationRequired as e:
            t.mark("agent0")
            logger.info("[Pipeline] Clarification required: %s", e.questions)
            assistant_msg = _build_clarification_message(
                e.assistant_message, e.questions
            )
            store.add_message(session_id, "assistant", assistant_msg)
            store.update_run(
                run_id,
                intent="clarification",
                status="clarification",
                timing_ms=t.all(),
                completed_at=time.time(),
            )
            return _make_result(
                run_id=run_id,
                session_id=session_id,
                status="clarification",
                message=assistant_msg,
                clarification_questions=e.questions,
                intent="clarification",
                timing=t.all(),
            )
        except UnsafeQueryError as e:
            t.mark("agent0")
            msg = f"I can't process this request: {e.reason}"
            store.add_message(session_id, "assistant", msg)
            store.update_run(run_id, intent="unsafe", status="error", error_message=str(e),
                             timing_ms=t.all(), completed_at=time.time())
            return _make_result(
                run_id=run_id, session_id=session_id,
                status="error", message=msg, intent="unsafe", timing=t.all(), error=str(e),
            )

        t.mark("agent0")
        intent = intent_obj.get("intent", "sql_query")
        rephrased = intent_obj.get("rephrased_query", user_message)

        store.update_run(
            run_id,
            intent=intent,
            should_run_pipeline=1 if intent_obj.get("should_run_pipeline") else 0,
            rephrased_query=rephrased,
        )

        # ── 5. Non-pipeline intents (small talk, meta, etc.) ────────
        if not intent_obj.get("should_run_pipeline"):
            reply = _handle_non_pipeline(intent, history, user_message)
            store.add_message(session_id, "assistant", reply)
            store.update_run(run_id, status="direct", timing_ms=t.all(), completed_at=time.time())
            return _make_result(
                run_id=run_id, session_id=session_id,
                status="direct", message=reply, intent=intent, timing=t.all(),
            )

        # ── 6. RAG Retrieval ────────────────────────────────────────
        logger.info("[Pipeline] RAG retrieval for: '%s'", rephrased[:80])
        rag_ctx = retrieve_context(rephrased)
        t.mark("rag")

        # ── 7. Agent-1: Planner ─────────────────────────────────────
        logger.info("[Pipeline] Agent-1 (Planner) starting…")
        envelope = agent1.run(
            rephrased_query=rephrased,
            rag_context=rag_ctx,
            conversation_history=history,
            clarifications=clarifications_for_pending,
        )
        t.mark("agent1")
        store.update_run(run_id, plan_envelope=envelope)

        # ── 8. Agent-2: Composer ────────────────────────────────────
        logger.info("[Pipeline] Agent-2 (Composer) starting…")
        composed_sql = agent2.run(rephrased_query=rephrased, envelope=envelope)
        t.mark("agent2")
        store.update_run(run_id, composed_sql=composed_sql)

        # ── 9. Agent-3: Verifier ────────────────────────────────────
        logger.info("[Pipeline] Agent-3 (Verifier) starting…")
        verified_sql, rationale = agent3.run(
            original_sql=composed_sql, envelope=envelope
        )
        t.mark("agent3")
        store.update_run(run_id, verified_sql=verified_sql)

        # ── 10. DB Execution ─────────────────────────────────────────
        if not s.ENABLE_SQL_EXECUTION:
            logger.info("[Pipeline] DB execution disabled — returning SQL only.")
            assistant_msg = (
                f"Here is the SQL I would run:\n```sql\n{verified_sql}\n```\n"
                "(DB execution is currently disabled)"
            )
            store.add_message(session_id, "assistant", assistant_msg)
            store.update_run(run_id, status="success", timing_ms=t.all(), completed_at=time.time())
            return _make_result(
                run_id=run_id, session_id=session_id,
                status="success", message=assistant_msg,
                verified_sql=verified_sql, composed_sql=composed_sql,
                plan_envelope=envelope, intent=intent, timing=t.all(),
            )

        logger.info("[Pipeline] Executing SQL…")
        try:
            db_result = oracle.run_sql(verified_sql, row_limit=eff_row_limit)
        except Exception as exc:
            logger.error("[Pipeline] DB execution failed: %s", exc)
            err_msg = f"The SQL executed but returned an error: {exc}"
            store.add_message(session_id, "assistant", err_msg)
            store.update_run(run_id, status="error", error_message=str(exc),
                             timing_ms=t.all(), completed_at=time.time())
            return _make_result(
                run_id=run_id, session_id=session_id,
                status="error", message=err_msg, intent=intent,
                verified_sql=verified_sql, composed_sql=composed_sql,
                plan_envelope=envelope, timing=t.all(), error=str(exc),
            )

        t.mark("db")
        store.update_run(
            run_id,
            db_columns=db_result.get("columns", []),
            db_rows=db_result.get("rows", []),
            db_row_count=db_result.get("row_count", 0),
        )

        # ── 11. Agent-4: Responder ───────────────────────────────────
        logger.info("[Pipeline] Agent-4 (Responder) starting…")
        response = agent4.run(
            question=rephrased,
            db_result=db_result,
            verified_sql=verified_sql,
            conversation_history=history,
        )
        t.mark("agent4")

        # ── 12. Persist & return ─────────────────────────────────────
        assistant_text = response.get("answer", "")
        store.add_message(
            session_id, "assistant", assistant_text,
            meta={"summary": response.get("summary"), "run_id": run_id},
        )

        store.update_run(
            run_id,
            answer_text=assistant_text,
            answer_summary=response.get("summary", ""),
            answer_key_facts=response.get("key_facts", []),
            status="success",
            timing_ms=t.all(),
            completed_at=time.time(),
        )

        logger.info(
            "[Pipeline] Done run=%s total=%.0fms", run_id, t.total()
        )

        return _make_result(
            run_id=run_id,
            session_id=session_id,
            status="success",
            message=assistant_text,
            summary=response.get("summary", ""),
            key_facts=response.get("key_facts", []),
            follow_ups=response.get("follow_up_suggestions", []),
            data=db_result,
            composed_sql=composed_sql,
            verified_sql=verified_sql,
            plan_envelope=envelope,
            intent=intent,
            timing=t.all(),
        )

    except (PlannerError, ComposerError, VerifierError) as exc:
        logger.error("[Pipeline] Agent error: %s", exc)
        err_msg = f"I encountered an issue processing your query: {exc}"
        store.add_message(session_id, "assistant", err_msg)
        store.update_run(run_id, status="error", error_message=str(exc),
                         timing_ms=t.all(), completed_at=time.time())
        return _make_result(
            run_id=run_id, session_id=session_id,
            status="error", message=err_msg, intent=intent,
            timing=t.all(), error=str(exc),
        )

    except Exception as exc:
        logger.exception("[Pipeline] Unexpected error for run=%s: %s", run_id, exc)
        err_msg = "An unexpected error occurred. Please try again."
        try:
            store.add_message(session_id, "assistant", err_msg)
            store.update_run(run_id, status="error", error_message=str(exc),
                             timing_ms=t.all(), completed_at=time.time())
        except Exception:
            pass
        return _make_result(
            run_id=run_id, session_id=session_id,
            status="error", message=err_msg, timing=t.all(), error=str(exc),
        )


def _build_clarification_message(assistant_msg: str, questions: List[str]) -> str:
    """Format a user-friendly clarification message."""
    if assistant_msg:
        msg = assistant_msg + "\n\n"
    else:
        msg = "I need a bit more information to answer your question accurately:\n\n"
    for i, q in enumerate(questions, 1):
        msg += f"{i}. {q}\n"
    return msg.strip()


def _handle_non_pipeline(intent: str, history: List[Dict], user_message: str) -> str:
    """
    For non-DB intents (small talk, meta questions, conversation recall):
    make a real LLM call with the full conversation history so the bot
    can answer contextually — e.g. "what did we discuss?" gets a real answer.
    """
    from core.ollama import get_client

    s = get_settings()
    client = get_client()

    system = (
        "You are ATS Intelligence, a financial markets analytics assistant. "
        "You are connected to a live Oracle trading database (ATS schema) covering "
        "symbols, turnover, volume, spreads, bid-offer quotes, and exchange data. "
        "You can run SQL queries on demand and summarize results.\n\n"
        "When the user asks about the conversation history, summarize it accurately "
        "from the chat messages provided. "
        "When the user asks about your capabilities, be specific about what data you have. "
        "Be concise and conversational — 2 to 4 sentences. "
        "Never mention SQL, databases, or technical internals."
    )

    messages: List[Dict] = [{"role": "system", "content": system}]
    if history:
        messages.extend(history[-12:])
    messages.append({"role": "user", "content": user_message})

    try:
        return client.chat(
            messages,
            model=s.model_for(0),
            num_ctx=s.ctx_for(0),
            temperature=0.3,
            num_predict=300,
        )
    except Exception as exc:
        logger.warning("[Pipeline] Non-pipeline LLM call failed: %s", exc)
        return (
            "I'm your financial markets analytics assistant. "
            "Ask me about symbols, turnover, spreads, exchange activity, "
            "or any other trading data you need."
        )
