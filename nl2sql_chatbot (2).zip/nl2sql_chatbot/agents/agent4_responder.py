"""
agents/agent4_responder.py — Natural Language Responder

Takes the database results + original question and produces a
human-friendly answer with summary, key insights, and table context.

Output contract (JSON):
{
  "answer": "Full natural language paragraph answer",
  "summary": "One sentence TL;DR",
  "key_facts": ["fact1", "fact2", ...],
  "follow_up_suggestions": ["You could also ask...", ...],
  "data_notes": "Any caveats about the data (row limit hit, nulls, etc.)"
}
"""
from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

from core.config import get_settings
from core.ollama import get_client

logger = logging.getLogger(__name__)

_SYSTEM_PROMPT = """You are Agent-4, the Response Synthesizer for a financial markets analytics chatbot.

You receive:
- The user's original question
- The database query results (columns + rows preview)
- The SQL that was executed (for context)

Your job is to produce a helpful, accurate, data-grounded natural language answer.

RULES:
1. Ground every claim in the actual data — don't invent numbers
2. Be concise but complete
3. Highlight the most important findings first
4. Note any data limitations (row limit hit, NULLs present, date range, etc.)
5. Suggest 2-3 natural follow-up questions the user might want to ask
6. Use financial/market terminology appropriately

OUTPUT: Return ONLY a valid JSON object:
{
  "answer": "Full answer paragraph(s)...",
  "summary": "One sentence TL;DR",
  "key_facts": ["Most important finding", "Second finding", ...],
  "follow_up_suggestions": ["Which exchange had the highest...?", ...],
  "data_notes": "e.g., Results capped at 200 rows. NULL values present in CLOSE_PRICE."
}

No prose outside the JSON. No markdown fences."""


def _load_system_prompt() -> str:
    s = get_settings()
    p = s.prompts_path / "system_agent4_responder.md"
    if p.exists():
        return p.read_text(encoding="utf-8", errors="ignore")
    return _SYSTEM_PROMPT


def _format_preview(db_result: Dict[str, Any], max_rows: int = 30) -> str:
    """Format db result as a compact table string for the LLM."""
    columns = db_result.get("columns", [])
    rows = db_result.get("rows", [])[:max_rows]
    truncated = db_result.get("truncated", False)
    row_count = db_result.get("row_count", len(rows))

    if not columns:
        return "(no data returned)"

    # Header
    header = " | ".join(str(c) for c in columns)
    sep = "-" * len(header)
    lines = [header, sep]

    for row in rows:
        lines.append(" | ".join(str(v) if v is not None else "NULL" for v in row))

    summary = f"\n({row_count} rows returned"
    if truncated:
        summary += f", result was capped — more rows exist"
    summary += ")"
    lines.append(summary)

    return "\n".join(lines)


def _fallback_response(question: str, db_result: Dict[str, Any]) -> Dict[str, Any]:
    """Use when LLM fails — generate a minimal but correct response."""
    row_count = db_result.get("row_count", 0)
    cols = db_result.get("columns", [])
    return {
        "answer": f"The query returned {row_count} rows with columns: {', '.join(cols)}.",
        "summary": f"{row_count} records retrieved.",
        "key_facts": [f"Query returned {row_count} rows."],
        "follow_up_suggestions": [
            "Can you show more details?",
            "Can you filter by a specific time range?",
        ],
        "data_notes": "AI response synthesis unavailable; raw data shown above.",
    }


def run(
    question: str,
    db_result: Dict[str, Any],
    verified_sql: str = "",
    conversation_history: List[Dict[str, str]] = None,
) -> Dict[str, Any]:
    """
    Run Agent-4 (Responder).

    Args:
        question: Original user question.
        db_result: Result dict from oracle.run_sql().
        verified_sql: The SQL that was executed (for context).
        conversation_history: Prior turns for contextual answers.

    Returns:
        Response dict with answer, summary, key_facts, etc.
    """
    s = get_settings()
    client = get_client()

    table_preview = _format_preview(db_result)

    payload = {
        "question": question,
        "sql_executed": verified_sql[:1000] if verified_sql else "(not provided)",
        "result_preview": table_preview,
        "row_count": db_result.get("row_count", 0),
        "truncated": db_result.get("truncated", False),
        "row_limit": db_result.get("row_limit", 200),
    }

    messages: List[Dict[str, str]] = [
        {"role": "system", "content": _load_system_prompt()},
    ]

    if conversation_history:
        # Brief history for contextual follow-up answers
        for m in (conversation_history or [])[-4:]:
            messages.append({"role": m["role"], "content": m["content"][:300]})

    messages.append({
        "role": "user",
        "content": json.dumps(payload, ensure_ascii=False),
    })

    obj = client.chat_json(
        messages,
        model=s.model_for(4),
        num_ctx=s.ctx_for(4),
        temperature=0.2,
        num_predict=1024,
    )

    if obj is None:
        logger.warning("[Agent4] JSON parse failed; using fallback response.")
        return _fallback_response(question, db_result)

    obj.setdefault("answer", "Data retrieved successfully.")
    obj.setdefault("summary", "")
    obj.setdefault("key_facts", [])
    obj.setdefault("follow_up_suggestions", [])
    obj.setdefault("data_notes", "")

    logger.info("[Agent4] Response: summary='%s'", obj["summary"][:80])
    return obj
