"""
agents/agent3_verifier.py — SQL Verifier & Refiner

Takes the composed SQL + planning envelope and performs:
  - Syntax review (Oracle-specific)
  - Semantic cross-checks (table/column names vs schema)
  - Logical sanity (joins, filters, aggregations)
  - Non-disclosure column checks
  - Business rule enforcement

Outputs either the original SQL (if clean) or a corrected version.
"""
from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from core.config import get_settings
from core.exceptions import VerifierError
from core.ollama import get_client

logger = logging.getLogger(__name__)

_FENCE_RE = re.compile(r"```(?:sql)?\s*(.*?)\s*```", re.DOTALL | re.IGNORECASE)
_SELECT_RE = re.compile(
    r"(?is)(?:with\s+.+?|select\s+.+?)(?:;|\Z)",
    re.DOTALL,
)

_SYSTEM_PROMPT = """You are Agent-3, the SQL Verifier and Refiner for an Oracle financial markets database.

You receive:
- ORIGINAL_SQL: the SQL written by the SQL Composer
- PLANNING_ENVELOPE: the plan it should implement
- SCHEMA_BLOCKS: relevant schema sections showing real column names

Your job:
1. SYNTAX CHECK — Verify Oracle SQL syntax is correct (no LIMIT, no MySQL-isms, no trailing semicolons in CTEs)
2. SEMANTIC CHECK — Verify all table and column names actually exist in SCHEMA_BLOCKS
3. LOGICAL CHECK — Verify joins are correct, aggregations match grouping, time filters are correct
4. SAFETY CHECK — Confirm no DML, DDL, or system queries
5. BUSINESS RULES — Ensure envelope constraints (row_limit, grain, filters) are implemented

If the SQL is correct, return it UNCHANGED.
If corrections are needed, return the CORRECTED SQL with a brief rationale.

IMPORTANT:
- Output format: JSON with two fields:
  { "sql": "<the final SQL>", "rationale": "<what you changed and why, or 'No changes needed'>" }
- The sql field must contain a complete, executable Oracle SELECT statement ending with ;
- Never output prose outside the JSON object"""


def _load_system_prompt() -> str:
    s = get_settings()
    p = s.prompts_path / "system_agent3_verifier.md"
    if p.exists():
        return p.read_text(encoding="utf-8", errors="ignore")
    return _SYSTEM_PROMPT


def _extract_schema_blocks(tables: List[str], schema_text: str) -> str:
    """
    Extract only the schema sections relevant to the tables in the plan.
    This keeps the verifier prompt lean.
    """
    if not tables:
        return schema_text[:4000]  # fallback: first 4k chars

    blocks = []
    # Split schema by ## headers
    sections = re.split(r"(^## [^\n]+)", schema_text, flags=re.MULTILINE)
    active = False
    active_text = []
    header = ""

    for part in sections:
        if part.startswith("## "):
            if active and active_text:
                blocks.append(header + "\n" + "".join(active_text))
            header = part
            # Check if this table is in our list
            active = any(t.upper() in part.upper() for t in tables)
            active_text = []
        else:
            if active:
                active_text.append(part)

    if active and active_text:
        blocks.append(header + "\n" + "".join(active_text))

    return "\n\n".join(blocks) if blocks else schema_text[:4000]


def _extract_result(text: str, fallback_sql: str) -> Tuple[str, str]:
    """
    Parse JSON output from verifier → (sql, rationale).
    Falls back to the original SQL if parsing fails.
    """
    from core.ollama import extract_json

    obj = extract_json(text)
    if obj and "sql" in obj:
        return obj["sql"].strip(), obj.get("rationale", "")

    # Try to grab SQL from code fences as last resort
    m = _FENCE_RE.search(text)
    if m:
        return m.group(1).strip(), "Extracted from code fence."

    logger.warning("[Agent3] Could not parse verifier output; returning original SQL.")
    return fallback_sql, "Verifier output could not be parsed; original SQL returned."


def run(
    original_sql: str,
    envelope: Dict[str, Any],
) -> Tuple[str, str]:
    """
    Run Agent-3 (Verifier).

    Args:
        original_sql: SQL from Agent-2.
        envelope: Planning envelope from Agent-1.

    Returns:
        Tuple of (final_sql, rationale).

    Raises:
        VerifierError if the output is clearly not SQL.
    """
    s = get_settings()
    client = get_client()

    import json

    schema_txt = _extract_schema_blocks(
        envelope.get("tables", []), s.schema_card_text
    )
    envelope_str = json.dumps(envelope, indent=2, ensure_ascii=False)

    user_content = (
        f"ORIGINAL_SQL:\n```sql\n{original_sql}\n```\n\n"
        f"PLANNING_ENVELOPE:\n{envelope_str}\n\n"
        f"SCHEMA_BLOCKS:\n{schema_txt}\n\n"
        "Review the SQL. Return JSON: {\"sql\": \"...\", \"rationale\": \"...\"}"
    )

    messages = [
        {"role": "system", "content": _load_system_prompt()},
        {"role": "user", "content": user_content},
    ]

    raw = client.chat(
        messages,
        model=s.model_for(3),
        num_ctx=s.ctx_for(3),
        temperature=0.0,
        num_predict=4096,
    )

    final_sql, rationale = _extract_result(raw, original_sql)

    # Sanity: must contain SELECT or WITH
    upper = final_sql.upper().strip()
    if not (upper.startswith("SELECT") or upper.startswith("WITH")):
        logger.error(
            "[Agent3] Output doesn't look like SQL; reverting to original.\nGot: %s",
            final_sql[:200],
        )
        return original_sql, "Verifier produced invalid output; original SQL used."

    # Ensure trailing semicolon
    if not final_sql.rstrip().endswith(";"):
        final_sql = final_sql.rstrip() + ";"

    logger.info("[Agent3] Verified SQL (%d chars). Rationale: %s", len(final_sql), rationale[:100])
    return final_sql, rationale
