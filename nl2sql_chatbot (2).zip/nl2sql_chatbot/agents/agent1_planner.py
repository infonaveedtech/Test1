"""
agents/agent1_planner.py — RAG-Aware Query Planner

Takes the user's rephrased query + RAG context + conversation history
and produces a planning envelope that tells Agent-2 exactly what to build.

Output contract (JSON):
{
  "tables": ["ATS.TABLE1", ...],
  "required_joins_verbatim": ["ATS.T1.COL = ATS.T2.COL", ...],
  "filters": {"column": "condition", ...},
  "metrics": ["turnover", "volume", ...],
  "grouping": ["column1", ...],
  "sorting": [{"col": "...", "dir": "DESC"}],
  "grain": "none" | "day" | "month" | "year",
  "date_key": "TABLE.COLUMN",
  "time_scope": "...",
  "row_limit": 200,
  "business_rules": ["..."],
  "clarifications_applied": ["..."],
  "retrieval_citations": {"fewshots": [...], "glossary": [...]}
}
"""
from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from core.config import get_settings
from core.exceptions import PlannerError
from core.ollama import get_client
from rag.retriever import render_fewshots, render_glossary

logger = logging.getLogger(__name__)

_ALLOWED_GRAINS = {"none", "day", "month", "year"}

_SYSTEM_PROMPT = """You are Agent-1, the Query Planner for a financial markets NL→SQL pipeline.

Your job is to analyze the user query and produce a PLANNING ENVELOPE (JSON) that tells the SQL composer exactly what to build.

You are given:
- The user's rephrased query
- The database schema card (ATS owner, Oracle dialect)
- Retrieved few-shot examples (similar past queries + their SQL)
- Retrieved glossary items (business rules, canonical joins, date semantics)
- Conversation history (for follow-up query context)

PLANNING RULES:
1. Always use fully qualified table names: ATS.TABLE_NAME
2. Always use fully qualified column references in joins: ATS.T1.COL = ATS.T2.COL
3. Prefer TRUNC(date_col, 'DD'/'MM'/'YYYY') for date bucketing
4. Use FETCH FIRST N ROWS ONLY (Oracle 12c+) instead of ROWNUM
5. Use NULLIF to protect division operations
6. If a metric is ambiguous (e.g., "volume"), clarify in business_rules which column you mean
7. For time scopes: use SYSDATE arithmetic (e.g., SYSDATE-30, ADD_MONTHS(TRUNC(SYSDATE,'MM'),-6))
8. Set row_limit based on query nature (summary=50, detail=200, time-series=500)
9. If conversation history shows a prior query, use it to resolve pronouns (e.g., "those symbols")

Return ONLY a valid JSON object matching the schema above. No prose, no code fences."""


def _load_system_prompt() -> str:
    s = get_settings()
    p = s.prompts_path / "system_agent1_planner.md"
    if p.exists():
        return p.read_text(encoding="utf-8", errors="ignore")
    return _SYSTEM_PROMPT


def _clip(text: str, max_chars: int) -> str:
    if len(text) <= max_chars:
        return text
    return text[:max_chars] + "\n...[TRUNCATED]..."


def _validate_envelope(env: Dict[str, Any]) -> Tuple[bool, List[str], Dict[str, Any]]:
    """Light validation + safe auto-fixes. Returns (ok, warnings, fixed_env)."""
    warnings = []
    fixed = dict(env)

    # row_limit
    if not isinstance(fixed.get("row_limit"), int) or fixed["row_limit"] <= 0:
        fixed["row_limit"] = 200
        warnings.append("row_limit set to 200 (was missing or invalid).")

    # grain
    grain = str(fixed.get("grain", "none")).lower()
    if grain not in _ALLOWED_GRAINS:
        warnings.append(f"grain '{grain}' unknown; reset to 'none'.")
        fixed["grain"] = "none"
    else:
        fixed["grain"] = grain

    # required fields
    for field in ("tables", "required_joins_verbatim", "metrics"):
        if not fixed.get(field):
            warnings.append(f"'{field}' is empty or missing.")

    ok = bool(fixed.get("tables") and fixed.get("date_key"))
    return ok, warnings, fixed


def run(
    rephrased_query: str,
    rag_context: Dict[str, Any],
    conversation_history: List[Dict[str, str]] = None,
    clarifications: List[str] = None,
) -> Dict[str, Any]:
    """
    Run Agent-1 (Planner).

    Args:
        rephrased_query: Cleaned query from Agent-0.
        rag_context: Dict with 'fewshots' and 'glossary' from RAG retriever.
        conversation_history: Prior [{"role", "content"}] turns.
        clarifications: Any answers to clarification questions.

    Returns:
        Validated planning envelope dict.

    Raises:
        PlannerError if no valid JSON envelope could be produced.
    """
    s = get_settings()
    client = get_client()

    schema_txt = _clip(s.schema_card_text, 16000)
    fewshots_txt = render_fewshots(rag_context.get("fewshots", []))
    glossary_txt = render_glossary(rag_context.get("glossary", []))

    # Conversation context block
    history_block = ""
    if conversation_history:
        history_block = "\n\n<CONVERSATION_HISTORY>\n"
        for m in conversation_history[-6:]:
            history_block += f"{m['role'].upper()}: {m['content'][:500]}\n"
        history_block += "</CONVERSATION_HISTORY>"

    clarification_block = ""
    if clarifications:
        clarification_block = (
            "\n\n<CLARIFICATIONS_PROVIDED>\n"
            + "\n".join(f"- {c}" for c in clarifications)
            + "\n</CLARIFICATIONS_PROVIDED>"
        )

    user_content = (
        f"User Query:\n{rephrased_query.strip()}"
        + clarification_block
        + history_block
        + f"\n\n<SCHEMA_CARD>\n{schema_txt}\n</SCHEMA_CARD>"
        + f"\n\n<RETRIEVED_FEWSHOTS>\n{fewshots_txt}\n</RETRIEVED_FEWSHOTS>"
        + f"\n\n<RETRIEVED_GLOSSARY>\n{glossary_txt}\n</RETRIEVED_GLOSSARY>"
        + "\n\nReturn ONLY the JSON planning envelope."
    )

    messages = [
        {"role": "system", "content": _load_system_prompt()},
        {"role": "user", "content": user_content},
    ]

    obj = client.chat_json(
        messages,
        model=s.model_for(1),
        num_ctx=s.ctx_for(1),
        temperature=0.1,
        num_predict=2048,
    )

    if obj is None:
        raise PlannerError("Agent-1 failed to produce a valid JSON planning envelope.")

    ok, warnings, fixed = _validate_envelope(obj)

    if warnings:
        logger.warning("[Agent1] Validation warnings: %s", warnings)

    # Attach citation info
    if "retrieval_citations" not in fixed:
        fixed["retrieval_citations"] = {
            "fewshots": [d.get("id") for d in rag_context.get("fewshots", []) if d.get("id")],
            "glossary": [d.get("id") for d in rag_context.get("glossary", []) if d.get("id")],
        }

    fixed["_validation_ok"] = ok
    fixed["_validation_warnings"] = warnings

    logger.info(
        "[Agent1] Planned: tables=%s grain=%s row_limit=%d ok=%s",
        fixed.get("tables"),
        fixed.get("grain"),
        fixed.get("row_limit", 0),
        ok,
    )

    return fixed
