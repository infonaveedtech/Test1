"""
agents/agent2_composer.py — SQL Composer

Takes the planning envelope from Agent-1 and generates the raw Oracle SQL.
Outputs a single SQL statement as a string.
"""
from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Any, Dict, List, Optional

from core.config import get_settings
from core.exceptions import ComposerError
from core.ollama import get_client

logger = logging.getLogger(__name__)

# Match SELECT ... ; or WITH ... ; statements (case-insensitive)
_SQL_RE = re.compile(
    r"(?is)(?:^|\n)((?:with\s+.+?|select\s+.+?)\s*;?)\s*$",
    re.DOTALL | re.MULTILINE,
)
_FENCE_RE = re.compile(r"```(?:sql)?\s*(.*?)\s*```", re.DOTALL | re.IGNORECASE)

_SYSTEM_PROMPT = """You are Agent-2, the SQL Composer for an Oracle financial markets database.

You receive a planning envelope (JSON) produced by the Query Planner and must write one correct, complete Oracle SQL SELECT statement.

STRICT RULES:
1. Output ONLY ONE SQL statement. No explanations, no alternatives, no markdown.
2. Always use owner-qualified names: ATS.TABLE_NAME, ATS.T1.COL = ATS.T2.COL
3. Oracle dialect ONLY:
   - FETCH FIRST N ROWS ONLY (not LIMIT)
   - TRUNC(date, 'MM'/'DD'/'YYYY') for date bucketing
   - NVL(), NVL2(), NULLIF() — not COALESCE for Oracle best practice
   - ADD_MONTHS(), LAST_DAY(), TRUNC(SYSDATE) for date arithmetic
   - PERCENTILE_CONT, LISTAGG, KEEP (DENSE_RANK...) for advanced analytics
4. End the statement with a semicolon.
5. Use FETCH FIRST {row_limit} ROWS ONLY at the end, based on envelope.row_limit.
6. Never output DROP, INSERT, UPDATE, DELETE, CREATE, GRANT, or DDL.
7. Use WITH (CTE) for multi-step logic.
8. Apply all filters, joins, groupings, and sort orders from the envelope exactly.
9. Protect all divisions with NULLIF(denominator, 0).

The output must be a single executable Oracle SQL statement."""


def _load_system_prompt() -> str:
    s = get_settings()
    p = s.prompts_path / "system_agent2_composer.md"
    if p.exists():
        return p.read_text(encoding="utf-8", errors="ignore")
    return _SYSTEM_PROMPT


def _extract_sql(text: str) -> Optional[str]:
    """
    Pull the SQL statement from model output.
    Handles: raw SQL, ```sql ... ```, or mixed prose.
    """
    text = text.strip()

    # Try fenced code block first
    m = _FENCE_RE.search(text)
    if m:
        return m.group(1).strip().rstrip(";") + ";"

    # Try regex match for SELECT/WITH block
    m = _SQL_RE.search(text)
    if m:
        sql = m.group(1).strip()
        if not sql.endswith(";"):
            sql += ";"
        return sql

    # Last resort: if text looks like SQL, return it cleaned
    upper = text.upper()
    if upper.startswith("SELECT") or upper.startswith("WITH"):
        return text.rstrip(";") + ";"

    return None


def run(
    rephrased_query: str,
    envelope: Dict[str, Any],
) -> str:
    """
    Run Agent-2 (Composer).

    Args:
        rephrased_query: The normalized user query.
        envelope: Planning envelope from Agent-1.

    Returns:
        Oracle SQL string (with trailing semicolon).

    Raises:
        ComposerError if no valid SQL could be extracted.
    """
    s = get_settings()
    client = get_client()

    import json
    envelope_str = json.dumps(envelope, indent=2, ensure_ascii=False)

    user_content = (
        f"Original user query:\n{rephrased_query}\n\n"
        f"Planning envelope:\n{envelope_str}\n\n"
        "Write the Oracle SQL SELECT statement that fulfills this plan. "
        "Output ONLY the SQL, nothing else."
    )

    messages = [
        {"role": "system", "content": _load_system_prompt()},
        {"role": "user", "content": user_content},
    ]

    raw = client.chat(
        messages,
        model=s.model_for(2),
        num_ctx=s.ctx_for(2),
        temperature=0.1,
        num_predict=4096,
    )

    sql = _extract_sql(raw)
    if not sql:
        logger.error("[Agent2] Could not extract SQL from output:\n%s", raw[:500])
        raise ComposerError(
            f"Agent-2 failed to produce extractable SQL. Raw output (first 300 chars): {raw[:300]}"
        )

    logger.info("[Agent2] Composed SQL (%d chars)", len(sql))
    logger.debug("[Agent2] SQL:\n%s", sql)
    return sql
