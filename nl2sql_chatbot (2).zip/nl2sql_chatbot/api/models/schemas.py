"""
api/models/schemas.py — All Pydantic request/response models.
"""
from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional
from pydantic import BaseModel, Field


# ── Sessions ──────────────────────────────────────────────────────────────────

class CreateSessionRequest(BaseModel):
    title: str = Field("New Chat", description="Optional display title for the session.")


class SessionResponse(BaseModel):
    session_id: str
    title: str
    created_at: float
    updated_at: float


class SessionListResponse(BaseModel):
    sessions: List[SessionResponse]
    total: int


# ── Chat ──────────────────────────────────────────────────────────────────────

class ChatRequest(BaseModel):
    session_id: str = Field(..., description="Session to send this message to.")
    message: str = Field(..., min_length=1, description="User's natural language message.")
    clarifications: Optional[List[str]] = Field(
        None, description="Answers to previous clarification questions."
    )
    row_limit: int = Field(200, ge=1, le=5000)


class DataResult(BaseModel):
    columns: List[str]
    rows: List[List[Any]]
    row_count: int
    row_limit: int
    truncated: bool


class ChatResponse(BaseModel):
    run_id: str
    session_id: str
    status: Literal["success", "clarification", "direct", "error"]
    message: str = Field(..., description="Primary response text to display in chat.")
    summary: str = ""
    key_facts: List[str] = []
    follow_up_suggestions: List[str] = []
    clarification_questions: List[str] = []
    data: Optional[DataResult] = None
    composed_sql: str = ""
    verified_sql: str = ""
    intent: str = ""
    timing_ms: Dict[str, float] = {}
    error: str = ""


# ── Runs ──────────────────────────────────────────────────────────────────────

class RunDetailResponse(BaseModel):
    run_id: str
    session_id: str
    question: str
    intent: Optional[str]
    rephrased_query: Optional[str]
    plan_envelope: Optional[Dict[str, Any]]
    composed_sql: Optional[str]
    verified_sql: Optional[str]
    db_columns: Optional[List[str]]
    db_rows: Optional[List[List[Any]]]
    db_row_count: Optional[int]
    answer_text: Optional[str]
    answer_summary: Optional[str]
    answer_key_facts: Optional[List[str]]
    status: str
    error_message: Optional[str]
    timing_ms: Optional[Dict[str, Any]]
    created_at: float
    completed_at: Optional[float]


class RunListResponse(BaseModel):
    runs: List[RunDetailResponse]
    total: int


# ── Export ────────────────────────────────────────────────────────────────────

class ExportRequest(BaseModel):
    run_id: str
    format: Literal["pdf", "docx"] = "pdf"
    title: str = "Analytics Report"
    generated_by: str = "NL2SQL Chatbot"
    show_sql: bool = False


class ExportResponse(BaseModel):
    run_id: str
    format: str
    filename: str
    mime: str
    file_base64: str


# ── Health ────────────────────────────────────────────────────────────────────

class HealthResponse(BaseModel):
    status: str
    ollama: bool
    oracle: bool
    rag_fewshots: bool
    rag_glossary: bool
    version: str = "2.0.0"
