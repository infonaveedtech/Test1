from fastapi import APIRouter, HTTPException
from api.models.schemas import ChatRequest, ChatResponse, DataResult
from db import sqlite_store as store
from pipeline.orchestrator import run_pipeline

router = APIRouter()


@router.post("", response_model=ChatResponse)
def chat(body: ChatRequest):
    """
    Send a message to the chatbot within a session.
    This is the main endpoint — runs the full Agent-0→4 pipeline.
    """
    # Validate session exists
    session = store.get_session(body.session_id)
    if not session:
        raise HTTPException(status_code=404, detail=f"Session '{body.session_id}' not found. Create one first via POST /v1/sessions.")

    result = run_pipeline(
        session_id=body.session_id,
        user_message=body.message,
        clarifications_for_pending=body.clarifications,
        row_limit=body.row_limit,
    )

    # Map data dict to DataResult model
    data_model = None
    if result.get("data"):
        d = result["data"]
        data_model = DataResult(
            columns=d.get("columns", []),
            rows=d.get("rows", []),
            row_count=d.get("row_count", 0),
            row_limit=d.get("row_limit", 200),
            truncated=d.get("truncated", False),
        )

    return ChatResponse(
        run_id=result["run_id"],
        session_id=result["session_id"],
        status=result["status"],
        message=result["message"],
        summary=result.get("summary", ""),
        key_facts=result.get("key_facts", []),
        follow_up_suggestions=result.get("follow_up_suggestions", []),
        clarification_questions=result.get("clarification_questions", []),
        data=data_model,
        composed_sql=result.get("composed_sql", ""),
        verified_sql=result.get("verified_sql", ""),
        intent=result.get("intent", ""),
        timing_ms=result.get("timing_ms", {}),
        error=result.get("error", ""),
    )
