"""
core/config.py — Centralized configuration loaded once at startup.
All settings come from environment variables (or .env file).
"""
from __future__ import annotations
import os
from pathlib import Path
from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # ── LLM (Ollama — chat only) ────────────────────────────────
    LLM_HOST: str = "http://localhost:11434"
    LLM_MODEL: str = "qwen3-coder:30b"

    # Per-agent model overrides (fall back to LLM_MODEL if empty)
    MODEL_AGENT0: str = ""
    MODEL_AGENT1: str = ""
    MODEL_AGENT2: str = ""
    MODEL_AGENT3: str = ""
    MODEL_AGENT4: str = ""

    # Context window sizes per agent
    CTX_AGENT0: int = 2048
    CTX_AGENT1: int = 22000
    CTX_AGENT2: int = 32768
    CTX_AGENT3: int = 22000
    CTX_AGENT4: int = 8192

    # ── Oracle ──────────────────────────────────────────────────
    ORACLE_DSN: str = ""
    ORACLE_USER: str = ""
    ORACLE_PASSWORD: str = ""
    ORACLE_OWNER: str = "ATS"
    ORACLE_POOL_MIN: int = 1
    ORACLE_POOL_MAX: int = 5
    ORACLE_POOL_INCREMENT: int = 1
    ORACLE_DEFAULT_ROW_LIMIT: int = 200

    # ── SQLite (session + history persistence) ──────────────────
    SQLITE_PATH: str = "data/chatbot.db"

    # ── FAISS / RAG ─────────────────────────────────────────────
    FAISS_FEWSHOTS_DIR: str = "data/faiss/fewshots"
    FAISS_GLOSSARY_DIR: str = "data/faiss/glossary"
    FEWSHOTS_JSONL: str = "data/docs/fewshots.docs.jsonl"
    GLOSSARY_JSONL: str = "data/docs/glossary.docs.jsonl"

    # sentence-transformers model — same one used in the original project
    # Downloaded automatically from HuggingFace on first run (~33 MB)
    EMBEDDING_MODEL: str = "BAAI/bge-small-en-v1.5"

    TOP_K_FEWSHOTS: int = 3
    TOP_K_GLOSSARY: int = 3

    # ── Schema / Prompts ────────────────────────────────────────
    SCHEMA_CARD_PATH: str = "prompts/schema_card.md"
    PROMPTS_DIR: str = "prompts"

    # ── API ─────────────────────────────────────────────────────
    API_HOST: str = "0.0.0.0"
    API_PORT: int = 8000
    API_RELOAD: bool = True
    CORS_ORIGINS: str = "*"

    # ── JWT (optional auth) ─────────────────────────────────────
    JWT_SECRET_KEY: str = "dev-secret-change-in-production"
    JWT_ALG: str = "HS256"
    JWT_EXPIRE_MINUTES: int = 1440

    # ── Reports ─────────────────────────────────────────────────
    REPORTS_DIR: str = "data/reports"

    # ── Feature flags ───────────────────────────────────────────
    ENABLE_SQL_EXECUTION: bool = True
    ENABLE_RAG: bool = True
    DEBUG_AGENTS: bool = False

    def model_for(self, agent_num: int) -> str:
        """Return the model name for the given agent (0-4)."""
        overrides = {
            0: self.MODEL_AGENT0,
            1: self.MODEL_AGENT1,
            2: self.MODEL_AGENT2,
            3: self.MODEL_AGENT3,
            4: self.MODEL_AGENT4,
        }
        return overrides.get(agent_num) or self.LLM_MODEL

    def ctx_for(self, agent_num: int) -> int:
        ctxs = {
            0: self.CTX_AGENT0,
            1: self.CTX_AGENT1,
            2: self.CTX_AGENT2,
            3: self.CTX_AGENT3,
            4: self.CTX_AGENT4,
        }
        return ctxs.get(agent_num, 8192)

    @property
    def prompts_path(self) -> Path:
        return Path(self.PROMPTS_DIR)

    @property
    def schema_card_text(self) -> str:
        p = Path(self.SCHEMA_CARD_PATH)
        if p.exists():
            return p.read_text(encoding="utf-8", errors="ignore")
        return "[SCHEMA CARD NOT FOUND — place schema_card.md in prompts/]"


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()
